import re
from fuzzywuzzy import fuzz,process
from selenium import webdriver
import pandas as pd 
import datetime
from datetime import date
from bs4 import BeautifulSoup
import time
import sqlite3
import random
from random import randint
from time import sleep
import requests

sleep(randint(1,60))

#Tutorial here: https://www.scrapingbee.com/blog/selenium-python/
from selenium import webdriver
#This will launch Chrome in headfull mode (like a regular Chrome, which is controlled by your Python code). 
#You should see a message stating that the browser is controlled by an automated software.
DRIVER_PATH = '/Users/ralph/Biotech/chromedriver'
#     driver = webdriver.Chrome(executable_path=DRIVER_PATH)

#     In order to run Chrome in headless mode (without any graphical user interface), 
#     to run it on a server for example, add the code below and replace driver above with the one below:
from selenium.webdriver.chrome.options import Options
options = Options()
options.headless = True
#     options.add_argument("--window-size=1920,1200")
driver = webdriver.Chrome(options=options, executable_path=DRIVER_PATH)

#Tutorial here:
driver.get("https://www.accessdata.fda.gov/scripts/opdlisting/oopd/listResult.cfm")

driver.find_element_by_xpath("//*[@id= 'Sort_order']/option[3]").click()
driver.find_element_by_xpath("//*[@id= 'user_provided']/form/p/input").click()
driver.get("https://www.accessdata.fda.gov/scripts/opdlisting/oopd/listResult.cfm")

soup = BeautifulSoup(driver.page_source, features="lxml")
# driver.get("https://www.biopharmcatalyst.com/calendars/fda-calendar")
# time.sleep(5)

# soup = BeautifulSoup(driver.page_source)
# #Always quit at the end of scraping
driver.quit()

table = soup.find_all('table')
ODD_list = pd.read_html(str(table))[3]
ODD_df = pd.DataFrame(ODD_list)
# print('https://www.accessdata.fda.gov/scripts/opdlisting/oopd/listResult.cfm')
# return (ODD_df)
ODD_df= ODD_df.drop(['#'], axis=1)
ODD_df['Sponsor']=''
ODD_df['URL']=''
ODD_df['Designation Date'] = ODD_df['Designation Date'].astype('datetime64[ns]')
table_tag = soup.findAll('table')[2]
rows = table_tag.find_all('tr')
for index,row in zip(ODD_df.index.to_list(),rows[1:]):

    cells = row.find_all('td')
    s1 = cells[1].a['href']
    s2 = re.findall(r"\((.*)\)" ,s1)[0]
    s2
    if len(cells) > 3:
# #         if '2020' in cells[3].text:
        try:
            doc_link = 'https://www.accessdata.fda.gov/scripts/opdlisting/oopd/detailedIndex.cfm?cfgridkey=' + s2
            ODD_df.loc[index,'URL']=doc_link
        except:
            continue
        try:
            res_drug = requests.get(doc_link)
            soup_drug = BeautifulSoup(res_drug.text, 'html.parser')
            drug_table_soup = soup_drug.find_all('td')[6]
            sponsor = drug_table_soup.contents[0].strip() 
            ODD_df.loc[index,'Sponsor']=sponsor
        except:
            continue

try:
    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
    df_companies = pd.read_sql_query("select symbol,Company,[My Notes Date],[Revisit Date],[My Notes],[Score (1-10)],[Last Updated],[Mkt. Cap],Price from biotech;", conn)
    df_companies
except sqlite3.Error as error:
    print("Failed to access the BiotechDatabase file", error)  
finally:
    if (conn):
        conn.close() 
df_companies = df_companies[df_companies.Company.notnull()]

df_test = ODD_df.copy()
df_test = df_test[df_test['Sponsor'].notnull()]
df_test.insert(0,'symbol','')


#Establishing redundant words to remove from the company names
remove_words = ['as','biosciences','biotech','co','corp','corpor','inc', 'ltd', 'therapeutics','pharmaceuticals','corporation','biopharma',
                'biotechnologies','biotherapeutics','holdings','pharma','plc','sciences','incorpor', 'i', 'technologies',
                'technologies','diagnostics','pharmaceutical','holdngs','hldgs','incorporated','biotechnology', 'medical',
                'bioscience','llc','international', 'american', 'healthcare'
               ]
pat = r'\b(?:{})\b'.format('|'.join(remove_words))
pat


#Cleaning the company names for better fuzzy analysis/scoring
df_companies['new'] = df_companies['Company'].str.replace('[^\w\s]','')
df_companies['new'] = df_companies['new'].str.lower() 
df_companies['new'] = df_companies['new'].str.replace(pat, '')
df_companies['new'] = df_companies['new'].apply(str.strip)

df_test['new'] = df_test['Sponsor'].str.replace('[^\w\s]','')
df_test['new'] = df_test['new'].str.lower() 
df_test['new'] = df_test['new'].str.replace(pat, '')
df_test['new'] = df_test['new'].apply(str.strip)

#Creating lists out of the company names
companies = df_companies['new'].tolist()
companies = sorted(list(set(companies)))
sponsors = df_test['new'].tolist()
sponsors = sorted(list(set(sponsors)))


#Creating a list of lists while only keeping the highest matching score for each sponsor company
matched = []
for sponsor in sponsors:
    row_matched = []
    for company in companies:
        
#         matched_token=fuzz.partial_ratio(sponsor,company)
        matched_token=fuzz.token_sort_ratio(sponsor,company)
        
        if matched_token> 86:  
            row_matched.append([sponsor,company,matched_token]) 
        else:
            pass
        row_matched.sort(key=lambda k: (-k[2]))
    try:
        matched.append(row_matched[0])
    except IndexError:
        pass
    

for triplet in matched:
    try:
        symbol = df_companies['symbol'].loc[df_companies['new'] == triplet[0]].item()
        df_test.loc[df_test['new'] == triplet[1],'symbol'] = symbol

    except:
        pass
#     df_test['symbol'][df_test['new'].loc[triplet[1]]]=df_companies['symbol'][df_companies['new'].loc[triplet[0]]]
    
    # filter = df_test["symbol"] != ""
    # df_CT = df_test[filter]
ODD_df = df_test.drop(['new'], axis=1)    
ODD_df = ODD_df[['Generic Name','symbol','Sponsor','Orphan Designation',
'Designation Date', 'Designation Status', 'URL']]

ODD_df                   
# ODD_df['URL'] = ODD_df['URL'].apply(lambda x: '<a href="{0}" target="_blank">{0}</a>'.format(x))
# display(HTML(ODD_df.to_html(escape=False)))

try:
    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
    ODD_df.to_sql('temp_ODD', conn, if_exists='replace', index=False)

    cur = conn.cursor()
    cur.executescript('''
                    INSERT OR IGNORE INTO ODD
                    SELECT * FROM temp_ODD;
                    SELECT * FROM ODD
                    ORDER BY [Designation Date] DESC;
                    ''')
    conn.commit()
    cur.close()
except sqlite3.Error as error:
    print("Failed to connect to the ODD table", error)  
finally:
    if (conn):
        conn.close()

