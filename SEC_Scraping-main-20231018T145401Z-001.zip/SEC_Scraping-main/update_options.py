import datetime
today = datetime.datetime.now()
import time
from selenium import webdriver
from bs4 import BeautifulSoup
import requests
import pandas as pd
import sqlite3
import random
from random import randint
from time import sleep

sleep(randint(1,60))

DRIVER_PATH = '/Users/ralph/Biotech/chromedriver'
#This will launch Chrome in headfull mode (like a regular Chrome, which is controlled by your Python code). 
#You should see a message stating that the browser is controlled by an automated software.
# driver = webdriver.Chrome(executable_path=DRIVER_PATH)

#In order to run Chrome in headless mode (without any graphical user interface), 
#to run it on a server for example, add the code below and replace driver above with the one below:
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
options = Options()
options.headless = True
# options.add_argument("--window-size=1920,1200")
driver = webdriver.Chrome(options=options, executable_path=DRIVER_PATH)

#Tutorial here:
driver.get("https://www.barchart.com/options/unusual-activity/stocks?page=1") #for all insider activities

time.sleep(3)


soup = BeautifulSoup(driver.page_source, 'lxml')
#Always quit at the end of scraping
driver.quit()

table = soup.find_all('table')
options_all_df = pd.read_html(str(table))[0] 
#Removing the last row that has the same items as the header
options_all_df = options_all_df[options_all_df.Symbol != 'Symbol']
#Adding date columns type
options_all_df['Exp Date'] = options_all_df['Exp Date'].astype('datetime64[ns]')
options_all_df['Last Trade'] = options_all_df['Last Trade'].astype('datetime64[ns]')
#Adding float columns type
options_all_df['Price'] = options_all_df['Price'].apply(pd.to_numeric, errors='ignore', downcast='float').apply(lambda x: round(x, 2))
options_all_df['Strike'] = options_all_df['Strike'].apply(pd.to_numeric, errors='ignore', downcast='float').apply(lambda x: round(x, 2))
options_all_df['Bid'] = options_all_df['Bid'].apply(pd.to_numeric, errors='ignore', downcast='float').apply(lambda x: round(x, 2))
options_all_df['Bid'] = options_all_df['Bid'].apply(pd.to_numeric, errors='ignore', downcast='float').apply(lambda x: round(x, 2))
options_all_df['Ask'] = options_all_df['Ask'].apply(pd.to_numeric, errors='ignore', downcast='float').apply(lambda x: round(x, 2))
options_all_df['Midpoint'] = options_all_df['Midpoint'].apply(pd.to_numeric, errors='ignore', downcast='float').apply(lambda x: round(x, 2))
options_all_df['Last'] = options_all_df['Last'].apply(pd.to_numeric, errors='ignore', downcast='float').apply(lambda x: round(x, 2))
options_all_df['Vol/OI'] = options_all_df['Vol/OI'].apply(pd.to_numeric, errors='ignore', downcast='float').apply(lambda x: round(x, 2))
#Adding integer columns type
options_all_df['DTE'] = options_all_df['DTE'].fillna(0).astype(int)
options_all_df['Volume'] = options_all_df['Volume'].fillna(0).astype(int)
options_all_df['Open Int'] = options_all_df['Open Int'].fillna(0).astype(int)
#Removing Links column
options_all_df = options_all_df.drop(['Links'], axis=1)
options_all_df

#Making a list of the new options symbols
symbols_options=options_all_df.Symbol.tolist()

#Getting the biotech database and the symbol list
try:
    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
    symbols_df = pd.read_sql_query("select symbol from biotech;", conn) 
    symbols_db = symbols_df['symbol'].tolist()
except sqlite3.Error as error:
    print("Failed to access the BiotechDatabase file", error)  
finally:
    if (conn):
        conn.close()
        
#Isolating the biotech options symbols dataframe showing on barchart.com
biotech_options = sorted(list(set(symbols_db).intersection(symbols_options)))
biotech_options_new_df= options_all_df[options_all_df['Symbol'].isin(biotech_options)].copy()
biotech_options_new_df = biotech_options_new_df.sort_values(['Last Trade'], ascending = False)
biotech_options_new_df = biotech_options_new_df.reset_index(drop=True)

try:
    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
    biotech_options_new_df.to_sql('temp_options_bio', conn, if_exists='replace', index=False)
    options_all_df.to_sql('temp_options_all', conn, if_exists='replace', index=False)

    cur = conn.cursor()
    cur.executescript('''
                    INSERT OR IGNORE INTO options_all
                    SELECT * FROM temp_options_all;
                    SELECT * FROM options_all
                    ORDER BY [Last Trade] DESC;
                    INSERT OR IGNORE INTO options_bio
                    SELECT * FROM temp_options_bio;
                    SELECT * FROM options_bio
                    ORDER BY [Last Trade] DESC;
                    ''')
    conn.commit()
    cur.close()
except sqlite3.Error as error:
    print("Failed to connect to the options tables", error)  
finally:
    if (conn):
        conn.close()