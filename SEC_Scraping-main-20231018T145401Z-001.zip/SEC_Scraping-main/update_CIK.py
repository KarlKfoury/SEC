import sqlite3
import pandas as pd
import re, requests
from iPython import display 

def getCIKs(TICKERS):
    URL = 'http://www.sec.gov/cgi-bin/browse-edgar?CIK={}&Find=Search&owner=exclude&action=getcompany'
    CIK_RE = re.compile(r'.*CIK=(\d{10}).*')    
    cik_dict = {}
    for ticker in TICKERS:
        f = requests.get(URL.format(ticker), stream = True)
        results = CIK_RE.findall(f.text)
        if len(results):
            results[0] = int(re.sub('\.[0]*', '.', results[0]))
            cik_dict[str(ticker).upper()] = str(results[0])
    f = open('cik_dict', 'w')   
    global df_CIK
    df_CIK = pd.DataFrame.from_dict(cik_dict, orient = 'index')
    display(df_CIK)
    f.close()

try:
    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
    TICKERS = pd.read_sql_query("select symbol from biotech where biotech.CIK is null;", conn)['symbol'].tolist()
except sqlite3.Error as error:
    print("Failed to select from biotech", error)  
finally:
    if (conn):
        conn.close() 
        
if not TICKERS:
    print("All CIK values are up-to-date")
else:
    getCIKs(TICKERS)
    available_CIK_list = df_CIK.index.to_list()
    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")   
        cur = conn.cursor()

        for i in available_CIK_list:
            values = (i,df_CIK[0].loc[i])
            cur.execute("""
            INSERT INTO biotech(symbol,CIK) VALUES(?,?)
            ON CONFLICT(symbol) DO UPDATE SET CIK=excluded.CIK""",
            values 
            )
        conn.commit()
        cur.close()
        print("The following symbols were added to the biotech database:")
        print(available_CIK_list)
    except sqlite3.Error as error:
        print("Failed to add new symbols", error)    
    finally:
        if (conn):
            conn.close()  