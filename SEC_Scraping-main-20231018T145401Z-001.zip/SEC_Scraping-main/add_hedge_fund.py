import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import matplotlib.pyplot as plt
import sqlite3
import datetime
import requests
import sys

# Avoro:                          0001633313
# Baker Brothers CIK number:      0001263508
# BVF                             0001056807
# Casdin:                         0001534261
# Opalaye CIK number:             0001595855
# Orbimed CIK number:             0001055951
# Perceptive Advisors CIK number: 0001224962
# Point72:                        0001603466 Needs a different coding
# RA Capital CIK number:          0001346824
# Renaissance Technologies:       0001037389
# Soros Capital Management:       0001748240



#VARIABLES TO INPUT
cik = '0001056807'
fund_table_name = 'hf_bvf' #i.e. hf_orbimed

n=8 #number of 13f reports to pull
type = '13f'

#String for Creating the new hedge fund table
stringcreate='''CREATE TABLE IF NOT EXISTS '''+ fund_table_name +''' (
    SYMBOL TEXT,
    NAME_OF_ISSUER TEXT, 
    VALUE INTEGER, 
    SHARES INTEGER, 
    DATE DATE, 
    TITLE_OF_CLASS TEXT, 
    CUSIP TEXT)'''

#String for Creating the unique index for the table so rows do not get dupliated
stringindex = '''CREATE UNIQUE INDEX '''+ '''index_'''+ fund_table_name+ ''' ON '''+fund_table_name+''' (
    SYMBOL,
    NAME_OF_ISSUER,
    VALUE,
    SHARES,
    DATE,
    TITLE_OF_CLASS,
    CUSIP
);'''

#Creating the table
try:
    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
    cur = conn.cursor()
    cur.execute(stringcreate)
    cur.execute(stringindex)
    conn.commit()
    cur.close()
except sqlite3.Error as error:
    print("Failed to connect to create table", error)  
finally:
    if (conn):
        conn.close()

# Obtain HTML for search page
base_url = "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={}&count=100&type={}"#"&dateb={}"
edgar_resp = requests.get(base_url.format(cik,type))
edgar_str = edgar_resp.text

# Find the document link
doc_link = ''
soup = BeautifulSoup(edgar_str, 'html.parser')
table_tag = soup.find('table', class_='tableFile2')
rows = table_tag.find_all('tr')

#Table of all recent listings
table = soup.find_all('table')
filings_df = pd.read_html(str(table))[2]
filings_df['URL']=''

for index,row in zip(filings_df.index.to_list(),rows[1:]):

    cells = row.find_all('td')
    s1 = cells[1].a['href']
    s2 = s1.rsplit('/', 1)[0]

    if len(cells) > 3:
# #         if '2020' in cells[3].text:

        try:
            doc_link = 'https://www.sec.gov'+s2+'/xslForm13F_X01/infotable.xml'
            filings_df.loc[index,'URL']=doc_link
            time.sleep(1)
        except:
            continue
# filings_df = filings_df.groupby('Filings').head(2).reset_index(drop=True)
# filings_df['URL'] = filings_df['URL'].apply(lambda x: '<a href="{0}" target="_blank">{0}</a>'.format(x))
filings_df = filings_df[~filings_df.Description.str.contains("Amend")]
filings_df = filings_df.head(n)
filings_df = filings_df.reset_index(drop=True)


def scrape_13f(date,url):
#     date = '2020-08-17'
#     url = 'https://www.sec.gov/Archives/edgar/data/1224962/000101297520000701/xslForm13F_X01/infotable.xml'
    #     html = open("13f/"+file).read()
    res = requests.get(url)
    soup = BeautifulSoup(res.text, 'lxml')
    rows = soup.find_all('tr')[11:]
    positions = []
    for row in rows:
        dic = {}
        position = row.find_all('td')
        dic["NAME_OF_ISSUER"] = position[0].text
        dic["TITLE_OF_CLASS"] = position[1].text
        dic["CUSIP"] = position[2].text
        dic["VALUE"] = int(position[3].text.replace(',', ''))*1000
        dic["SHARES"] = int(position[4].text.replace(',', ''))
        dic["DATE"] = date.strip(".html")
        dic['OPTIONS'] = position[6].text
        positions.append(dic)

    holdings_df = pd.DataFrame(positions)
    holdings_df_options=holdings_df[holdings_df['OPTIONS'] != '\xa0']
    holdings_df=holdings_df[holdings_df['OPTIONS'] == '\xa0']
    del holdings_df['OPTIONS']

    cusip_nums = holdings_df['CUSIP'].to_list()
    ticker_dic = {c:"" for c in cusip_nums}
    for c in list(ticker_dic.keys()):
        url = "http://quotes.fidelity.com/mmnet/SymLookup.phtml?reqforlookup=REQUESTFORLOOKUP&productid=mmnet&isLoggedIn=mmnet&rows=50&for=stock&by=cusip&criteria="+c+"&submit=Search"
        html = requests.get(url).text
        soup = BeautifulSoup(html, 'lxml')
        ticker_elem = soup.find('tr', attrs={"bgcolor":"#666666"})
        ticker = ""
        try:
            ticker = ticker_elem.next_sibling.next_sibling.find('a').text
            ticker_dic[c] = ticker
        except:
            pass

        time.sleep(1)
        
    positions = []    
    for row in rows:
        dic = {}
        position = row.find_all('td')
        dic["SYMBOL"] = ticker_dic[position[2].text]
        dic["NAME_OF_ISSUER"] = position[0].text
        dic["TITLE_OF_CLASS"] = position[1].text
        dic["CUSIP"] = position[2].text
        dic["VALUE"] = int(position[3].text.replace(',', ''))*1000
        dic["SHARES"] = int(position[4].text.replace(',', ''))
        dic["DATE"] = date.strip(".html")
        positions.append(dic) 
    

    holdings_df = pd.DataFrame(positions)
    
    holdings_df['SHARES'] = holdings_df['SHARES'].fillna(0).astype(int)
    holdings_df['VALUE'] = holdings_df['VALUE'].fillna(0).astype(int)
    holdings_df = holdings_df.sort_values(by="VALUE", ascending=False)
    holdings_df['DATE'] = holdings_df['DATE'].astype('datetime64[ns]')
    holdings_df= holdings_df[['SYMBOL','NAME_OF_ISSUER','VALUE','SHARES','DATE','TITLE_OF_CLASS','CUSIP']]
    
    temp = 'temp_'+fund_table_name
    script = '''
                INSERT OR IGNORE INTO '''+ fund_table_name+''' 
                SELECT * FROM '''+ '''temp_'''+fund_table_name+''';
                SELECT * FROM '''+fund_table_name+''' 
                ORDER BY [DATE] DESC;
                        '''
    
    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
        holdings_df.to_sql(temp, conn, if_exists='replace', index=False)

        cur = conn.cursor()
        cur.executescript(script)
        conn.commit()
        cur.close()
    except sqlite3.Error as error:
        print("Failed to connect to the fund table", error)  
    finally:
        if (conn):
            conn.close()

for date, url in zip(filings_df['Filing Date'], filings_df.URL):
    scrape_13f(date,url)
    