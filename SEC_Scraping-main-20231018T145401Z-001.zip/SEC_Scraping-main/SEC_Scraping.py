from flask import Flask
from flask_socketio import SocketIO
from flask_cors import CORS
from feedParserUpdate import FeedParser

import pymongo
import sys
import time

timestr = time.strftime("%Y%m%d")

#importing the module 
import logging 

try:

    #now we will Create and configure logger 
    logging.basicConfig(filename="SEC_Scraping" + timestr  + ".log", 
                        level=logging.DEBUG,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', 
                        datefmt='%d/%m/%Y %I:%M:%S %p',
                        filemode='a+') 

    #Let us Create an object 
    logger=logging.getLogger() 

    #Now we are going to Set the threshold of logger to DEBUG 
    logger.setLevel(logging.DEBUG) 

    myclient = pymongo.MongoClient("mongodb://localhost:27017/")
    mydb = myclient["subscriptions"]
    mycol = mydb["subscribed_users"]

    sub_users = myclient["sub_users"]
    sub_users_auth = sub_users["sub_users_auth"]

    subscriptions = []
    __author__ = 'slynn'

    clients = 0

    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'secret!'
    # app.config['DEBUG'] = True
    app.config['CORS_HEADERS'] = 'Content-Type'
    cors = CORS(app, resources={r"/api/*": {"origins": "*"}})

    # turn the flask app into a socketio app

    socketio = SocketIO(app, async_mode=None, logger=True,
                        engineio_logger=True, cors_allowed_origins="*")

    VAPID_PRIVATE_KEY = "tDc0qjRC4DLqqKoRpWlEdM8YDivuvC9OrKagnC97tIk"
    VAPID_PUBLIC_KEY = "BDbSrhMxREV7Ryotl2_otvuPqaegMv6ZyzAK5CId93GdFqLxCUHrEyITgy-C_HB2_9dISYJaNMpjxEOyWWzmjy4"
    VAPID_CLAIMS = {
        "sub": "mailto:marounantoun97@gmail.com"
    }

    feedParser = FeedParser(
        'https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&CIK=&type=SC%2013&company=&&owner=include&start=0&count=100&output=atom',
        set())

    feedParserForm4 = FeedParser(
        'https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&CIK=&type=4&company=&dateb=&owner=only&start=0&count=100&output=atom',
        set())


    def ack():
        print('message was received!')


    @socketio.on('message', namespace='/test')
    def sendFeed():
        global clients
        while not clients <= 0:

            feedParserForm4.updateCurrentPosts()
            forms4 = feedParserForm4.createDataframeForm4()

            print("len(forms4): " + str(len(forms4)))
            logger.debug("len(forms4): " + str(len(forms4))) 

            if not forms4.empty:
                print("emitting 4 event")
                logger.debug("emitting 4 event") 
                for index, row in forms4.iterrows():
                    print(row["Sales Averages"])
                    if type(row["Sales Averages"]) != float:
                        for elt in row["Sales Averages"]:
                            if type(elt) != str:
                                notif = row['Ticker'] + ' ' + row['Reporting Person'] + ' has filed Form ' + row['Form'] + \
                                        ' reporting ' + \
                                        str(int(elt["Sales Average"])) + ' in ' + \
                                        row['Target']
                                try:
                                    socketio.emit('newnumber',
                                                {'number': notif, 'link': row['HTML_Form_Link'], 'ticker': row['Ticker'],
                                                'reporting_person': row['Reporting Person'],
                                                'sales_average': str(elt["Sales Average"]),
                                                'target': row['Target'], 'date': elt['Issue Date'], 'form': row['Form'],
                                                'time': row['Issue Time'], 'form_link': row['Form_Link']},
                                                namespace='/test', callback=ack)
                                except:
                                    print("Unexpected error in form 4 notifications:", sys.exc_info()[0])
                                    logger.error("Unexpected error in form 4 notifications:" + str(sys.exc_info()[0])) 
                                    
                                    raise
                            else:
                                notif = row['Ticker'] + " " + row['Reporting Person'] + ' has filed Form ' + row['Form'] + \
                                        ' reporting ' + " ownership in" + \
                                        row['Target']
                                try:
                                    socketio.emit('newnumber',
                                                {'number': notif, 'link': row['HTML_Form_Link'], 'ticker': row['Ticker'],
                                                'reporting_person': row['Reporting Person'],
                                                'target': row['Target'], 'date': row['Issue Date'], 'form': row['Form'],
                                                'time': row['Issue Time'], 'form_link': row['Form_Link']},
                                                namespace='/test', callback=ack)
                                except:
                                    print("Unexpected error in form 4 notifications:", sys.exc_info()[0])
                                    logger.error("Unexpected error in form 4 notifications:" + str(sys.exc_info()[0]))
                                    raise
                    else:
                        notif = row['Ticker'] + " " + row['Reporting Person'] + ' has filed Form ' + row['Form'] + \
                                ' reporting ' + " ownership in" + \
                                row['Target']
                        try:
                            socketio.emit('newnumber',
                                        {'number': notif, 'link': row['HTML_Form_Link'], 'ticker': row['Ticker'],
                                        'reporting_person': row['Reporting Person'],
                                        'target': row['Target'], 'date': row['Issue Date'], 'form': row['Form'],
                                        'time': row['Issue Time'], 'form_link': row['Form_Link']}, namespace='/test',
                                        callback=ack)
                        except:
                            logger.error("Unexpected error in form 4 notifications:" + str(sys.exc_info()[0]))
                            print("Unexpected error in form 4 notifications:", sys.exc_info()[0])
                            raise

                        
            feedParser.updateCurrentPosts()
            forms13G, forms13D = feedParser.createDataframe()

            print("len(forms13G): " + str(len(forms13G)))
            print("len(forms13D): " + str(len(forms13D)))
            logger.debug("len(forms13G): " + str(len(forms13G)))
            logger.debug("len(forms13D): " + str(len(forms13D)))

            

            if not forms13G.empty:
                print("emitting 13G event")
                logger.debug("emitting 13G event")
                for index, row in forms13G.iterrows():
                    notif = row['Ticker'] + " " + row['Name of Reporting Person'] + " has filed Form SC 13G reporting " + \
                            row['Shares Amount'] + " ownership in" + \
                            row['Target']
                    # print(notif)
                    try:
                        socketio.emit('newnumber', {'number': notif, 'link': row['HTML_Form_Link'], 'ticker': row['Ticker'],
                                                    'lead_investor': row['Name of Reporting Person'],
                                                    'shares_amount': row['Shares Amount'], 'target': row['Target'],
                                                    'date': row['Issue Date'], 'time': str(row['Issue Time']),
                                                    'form': row['Form'], 'form_link': row['Form_Link']}, namespace='/test',
                                    callback=ack)
                    except:
                        print("Unexpected error in form 13G notifications:", sys.exc_info()[0])
                        logger.error("Unexpected error in form 4 notifications:" + str(sys.exc_info()[0]))
                        raise

            if not forms13D.empty:
                print("emitting 13D event")
                logger.debug("emitting 13D event")
                for index, row in forms13D.iterrows():
                    notif = row['Ticker'] + " " + row['Name of Reporting Person'] + " has filed Form SC 13D reporting " + \
                            row['Shares Amount'] + " ownership in" + \
                            row['Target']
                    # print(notif)
                    try:
                        socketio.emit('newnumber', {'number': notif, 'link': row['HTML_Form_Link'], 'ticker': row['Ticker'],
                                                    'lead_investor': row['Name of Reporting Person'],
                                                    'shares_amount': row['Shares Amount'], 'target': row['Target'],
                                                    'date': row['Issue Date'], 'time': str(row['Issue Time']),
                                                    'form': row['Form'], 'form_link': row['Form_Link']}, namespace='/test',
                                    callback=ack)
                    except:
                        print("Unexpected error in form 13D notifications:", sys.exc_info()[0])
                        logger.error("Unexpected error in form 4 notifications:" + str(sys.exc_info()[0]))
                        raise
            
            socketio.sleep(120)


    @socketio.on('connect', namespace='/test')
    def test_connect():
        global clients
        clients += 1
        logger.debug('Client connected')

        print('Client connected')


    @socketio.on('disconnect', namespace='/test')
    def test_disconnect():
        global clients
        clients = clients - 1
        logger.debug("Client disconnected")

        print('Client disconnected')
except:
    print("Unexpected error:", sys.exc_info()[0])
    logger.error("Unexpected error:" + str(sys.exc_info()[0]))
    raise


if __name__ == '__main__':
    import signal


    def signal_handler(sig, frame):
        print('You pressed Ctrl+C!')
        sys.exit(0)


    signal.signal(signal.SIGINT, signal_handler)
    print('Press Ctrl+C')
    # Configuration to run on server
    # socketio.run(app, host='0.0.0.0', port=5000)

    # Configuration to run locally
    # socketio.run(app, host='192.168.15.115', port=5000)
    socketio.run(app, host='127.0.0.1', port=5000)
