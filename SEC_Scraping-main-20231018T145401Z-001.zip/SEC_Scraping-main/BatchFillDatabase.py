#!/usr/bin/env python3
# Import libraries
import pandas as pd
from yahooquery import Ticker
from multiprocessing import Pool
import logging
import time
import pymongo
import datetime

# user created classes
import utils

from bs4 import BeautifulSoup
from datetime import date
import matplotlib.pyplot as plt
import textwrap
import numpy as np
import requests
import sys
from IPython.display import HTML
import contextlib
import pandas.io.formats.format as pf

from IPython.display import display
import json

import numpy as np



def tickerhelp():
    print('''
    Stock's Company related:
    summary(''): Company summary 
    web(''): Company website
    sp(''), sps('') (for short version):  Summary profile
    salaries(''): Executive Salaries
    news(''): Recent news (yahoo)
    links(''): Helpful links
    
    Stock related:
    exchange(''):Stock exchange, along with date it started trading
    trend(''): Stock trend
    pctchange(''): Stock % change
    pc(''), pcs('') (for short version): Stock price
    ks(''), kss_new('') kss_old('') (for short version): Key statistics
    validate(''): Validate a ticker

    
    Stock Financials:
    bs('') , bss('') (for short version): Balance sheet
    fs('') , fss('') (for short version): Financial statement
    cf(''), cfs('') (for short version): Cash flows
    cash(''): time to 0$ cash based on cash burn
    dilution(''): Dilution SEC filings

    Stock Ownership:
    mhs(''): Major holders (from Yahoo)
    insiders(''): Insider activity (Buyers/sellers for the past 12 months)
    biotech_hf(''): Biotech hedge funds positionning (Perceptive, Baker Brothers...) from the latest 13F SEC filings
    institutions(''): Institutional Ownnership
    
    Drug related:
    pipeline (''): pulls the drug pipeline of a particular stock
    catalyst(''): pulls the drug catalysts of a particular stock
    search():asks for a word to look up in all the pipeline data
    catalystsall(): generates the whole dataframe of catalysts from the CSV file
    catalysts_update():updates the whole dataframe of catalysts and saves it to the CSV file
    pipeline_update():updates the pipeline of drugs of all companies with their news links, phase of study, and status
    clinical_trials('drug'): looks up a drug in clinicaltrials.gov and results a dataframe of all studies
    
    Database:
    database(): calls in df_bio, my main database
    add('symbol'): adds symbol to database along with report data
    clean(): cleans database from invalid tickers
    remove(''): removes a particular ticker from the database
    update(): update all tickers 
    add_list(): adds the items in symbol (separated by ',') to database
    add_new_from_list(): compares database list to symbol list and only adds itmes not in database
    add_later():adds tickers not yet on the market (IPO...) to add_later_list.pkl
    add_add_later_list():Calls the add_later_list and checks if its tickers are already in the database, if not it tries to add them then updates the list named add_later_list.pkl accordingly
    summary_search(): asks for a word to look up in all the database summaries
    ct_search(): searches for a word in the ClinicalTrials.Gov database
    
    Insider activity in the database:
    insiders_buy(): displays the most recent insider buyin activity of stocks in the database
    insiders_all(): displays the most recent insider activity of stocks in the database     
    
    Feeds:
    news(): News feed
    journals(): new publications in medical journals
    ''')

""" This method will be called first to fill the database with every Company and Ther Ticker and CIK and Sector and Industry"""



def percentageChange(ticker_symbol, ticker):
    print("percentageChange name for : " + ticker_symbol)

    try:
        mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
        allCompaniesDB= mongo_client["allCompaniesDB"]
        print(mongo_client.list_database_names())
        dblist = mongo_client.list_database_names()
        if "allCompaniesDB" in dblist:
            print("The database exists.")
        collist = allCompaniesDB.list_collection_names()
        if "allCompaniesCollection" in collist:
            print("The collection exists.")
            # allCompaniesDB.allCompaniesCollection.drop()

        allCompaniesCollection = allCompaniesDB["allCompaniesCollection"]
        symbol = ticker_symbol.upper()
        # ticker = Ticker(symbol, asynchronous=True)
        df_pc1 = pd.DataFrame.from_dict(ticker.price, orient='index')
        df_1m = ticker.history(period='1mo')
        df_3m = ticker.history(period='3mo')
        df_1y = ticker.history(period='1y')

        Close1Mo = float(df_1m.head(1)['close'])
        Close3Mo = float(df_3m.head(1)['close'])
        Close1Y = float(df_1y.head(1)['close'])
        PriceToday = float(df_pc1['regularMarketPrice'])

        oneMonthPercentageChange = round(((PriceToday - Close1Mo) / Close1Mo) * 100, 2)
        threeMonthPercentageChange = round ( ( (PriceToday- Close3Mo) / Close3Mo)  * 100, 2)
        oneYearPercentageChange =  round(((PriceToday - Close1Y) / Close1Y ) * 100 , 2)






        myquery = { "Ticker": symbol }
        newvalues = { "$set": { "One month percentage change": oneMonthPercentageChange , "Three month percentage change" : threeMonthPercentageChange, "One year percentage change" : oneYearPercentageChange} }

        allCompaniesDB.allCompaniesCollection.update_one(myquery, newvalues)

    except (pymongo.errors.AutoReconnect, pymongo.errors.ConnectionFailure) as err:
        print("AutoReconnect error: " + str(err))
        logger.error("AutoReconnect error: " + str(err))
    except pymongo.errors.DuplicateKeyError as err:
        print("DuplicateKeyError error: " + str(err))
        logger.error("DuplicateKeyError error: " + str(err))
    except pymongo.errors.OperationFailure as err:
        print("OperationFailure error : " + str(err))
        logger.error("OperationFailure error : " + str(err))
    except Exception as err:
        print("Exception error : " + str(err))
        logger.error("Exception error : " + str(err))

def fillTicker(ticker):
    try:
        mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
        allCompaniesDB= mongo_client["allCompaniesDB"]
        print(mongo_client.list_database_names())
        dblist = mongo_client.list_database_names()
        if "allCompaniesDB" in dblist:
            print("The database exists.")
        collist = allCompaniesDB.list_collection_names()
        if "allCompaniesCollection" in collist:
            print("The collection exists.")
            # allCompaniesDB.allCompaniesCollection.drop()

        allCompaniesCollection = allCompaniesDB["allCompaniesCollection"]
        ticker_upper = ticker.upper()
        print("Fill ticker:  " + ticker)
        sector, industry = utils.getSectorIndustrybyTicker(
                ticker_upper)

        record = {"Ticker" : ticker_upper , 'Sector': sector, 'Industry': industry}

        allCompaniesDB.allCompaniesCollection.replace_one({"Ticker" : ticker_upper} , record, upsert=True)
    except (pymongo.errors.AutoReconnect, pymongo.errors.ConnectionFailure) as err:
        print("AutoReconnect error: " + str(err))
        logger.error("AutoReconnect error: " + str(err))
    except pymongo.errors.DuplicateKeyError as err:
        print("DuplicateKeyError error: " + str(err))
        logger.error("DuplicateKeyError error: " + str(err))
    except pymongo.errors.OperationFailure as err:
        print("OperationFailure error : " + str(err))
        logger.error("OperationFailure error : " + str(err))
    except Exception as err:
        print("Exception error : " + str(err))
        logger.error("Exception error : " + str(err))

def fillCIK(ticker, CIK):
    mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
    allCompaniesDB= mongo_client["allCompaniesDB"]
    print(mongo_client.list_database_names())
    dblist = mongo_client.list_database_names()
    if "allCompaniesDB" in dblist:
        print("The database exists.")
    collist = allCompaniesDB.list_collection_names()
    if "allCompaniesCollection" in collist:
        print("The collection exists.")
        # allCompaniesDB.allCompaniesCollection.drop()

    allCompaniesCollection = allCompaniesDB["allCompaniesCollection"]
    print("Fill CIK:  " + ticker)
    ticker_upper = ticker.upper()
    myquery = { "Ticker": ticker_upper }
    newvalues = { "$set": {'CIK': CIK} }

    allCompaniesDB.allCompaniesCollection.update_one(myquery, newvalues)



def exchangeName(ticker_symbol, ticker):
    print("exchange name for : " + ticker_symbol)
    try:
        mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
        allCompaniesDB= mongo_client["allCompaniesDB"]
        print(mongo_client.list_database_names())
        dblist = mongo_client.list_database_names()
        if "allCompaniesDB" in dblist:
            print("The database exists.")
        collist = allCompaniesDB.list_collection_names()
        if "allCompaniesCollection" in collist:
            print("The collection exists.")
            # allCompaniesDB.allCompaniesCollection.drop()

        allCompaniesCollection = allCompaniesDB["allCompaniesCollection"]
        symbol = ticker_symbol.upper()
        ticker = Ticker(symbol, asynchronous=True)
        exchange = ticker.quote_type[symbol]['exchange']
        firstTradeDateEpochUtc = ticker.quote_type[symbol]['firstTradeDateEpochUtc']
        longName = ticker.quote_type[symbol]['longName']
        exchangeName: str = ticker.price[symbol]["exchangeName"]
        regularMarketPrice = ticker.price[symbol]['regularMarketPrice']
        currency = ticker.price[symbol]['currency']
        myquery = { "Ticker": symbol }
        newvalues = { "$set": { "Exchange": exchange , "First Traded" : firstTradeDateEpochUtc, "Long Name" : longName, "Exchange Name" : exchangeName, 'regularMarketPrice': regularMarketPrice, 'currency':currency} }

        allCompaniesDB.allCompaniesCollection.update_one(myquery, newvalues)

    except (pymongo.errors.AutoReconnect, pymongo.errors.ConnectionFailure) as err:
        print("AutoReconnect error: " + str(err))
        logger.error("AutoReconnect error: " + str(err))
    except pymongo.errors.DuplicateKeyError as err:
        print("DuplicateKeyError error: " + str(err))
        logger.error("DuplicateKeyError error: " + str(err))
    except pymongo.errors.OperationFailure as err:
        print("OperationFailure error : " + str(err))
        logger.error("OperationFailure error : " + str(err))
    except Exception as err:
        print("Exception error : " + str(err))
        logger.error("Exception error : " + str(err))

def websiteCountry(symbol,ticker):
    try:
        mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
        allCompaniesDB= mongo_client["allCompaniesDB"]
        print(mongo_client.list_database_names())
        dblist = mongo_client.list_database_names()
        if "allCompaniesDB" in dblist:
            print("The database exists.")
        collist = allCompaniesDB.list_collection_names()
        if "allCompaniesCollection" in collist:
            print("The collection exists.")
            # allCompaniesDB.allCompaniesCollection.drop()

        allCompaniesCollection = allCompaniesDB["allCompaniesCollection"]
        symbol = symbol.upper()
        # ticker = Ticker(symbol, asynchronous=True)
        country = ticker.summary_profile[symbol]['country']
        website = ticker.summary_profile[symbol]['website']
        longBusinessSummary =  ticker.summary_profile[symbol]['longBusinessSummary']
        phone =  ticker.summary_profile[symbol]['phone']
        myquery = { "Ticker": symbol }
        newvalues = { "$set": { "Country": country , "Website" : website, "Business Summary" : longBusinessSummary, "Phone" : phone} }
        allCompaniesDB.allCompaniesCollection.update_one(myquery, newvalues)
    except (pymongo.errors.AutoReconnect, pymongo.errors.ConnectionFailure) as err:
        print("AutoReconnect error: " + str(err))
        logger.error("AutoReconnect error: " + str(err))
    except pymongo.errors.DuplicateKeyError as err:
        print("DuplicateKeyError error: " + str(err))
        logger.error("DuplicateKeyError error: " + str(err))
    except pymongo.errors.OperationFailure as err:
        print("OperationFailure error : " + str(err))
        logger.error("OperationFailure error : " + str(err))
    except Exception as err:
        print("Exception error : " + str(err))
        logger.error("Exception error : " + str(err))

def priceMarketCap(symbol, ticker):
    try:
        mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
        allCompaniesDB= mongo_client["allCompaniesDB"]
        print(mongo_client.list_database_names())
        dblist = mongo_client.list_database_names()
        if "allCompaniesDB" in dblist:
            print("The database exists.")
        collist = allCompaniesDB.list_collection_names()
        if "allCompaniesCollection" in collist:
            print("The collection exists.")
            # allCompaniesDB.allCompaniesCollection.drop()

        allCompaniesCollection = allCompaniesDB["allCompaniesCollection"]
        symbol = symbol.upper()
        marketCap = ticker.price[symbol]['marketCap']
        regularMarketPrice = ticker.price[symbol]['regularMarketPrice']
        regularMarketChangePercent = round(ticker.price[symbol]['regularMarketChangePercent'] * 100, 2)
        regularMarketVolume = ticker.price[symbol]['regularMarketVolume']
        myquery = { "Ticker": symbol }
        newvalues = { "$set": { "Market Cap": marketCap , "Regular Market Price" : regularMarketPrice, "Regular Market Price Change Percentage" : regularMarketChangePercent, "Regular Market Volume" : regularMarketVolume} }
        allCompaniesDB.allCompaniesCollection.update_one(myquery, newvalues)
    except (pymongo.errors.AutoReconnect, pymongo.errors.ConnectionFailure) as err:
        print("AutoReconnect error: " + str(err))
        logger.error("AutoReconnect error: " + str(err))
    except pymongo.errors.DuplicateKeyError as err:
        print("DuplicateKeyError error: " + str(err))
        logger.error("DuplicateKeyError error: " + str(err))
    except pymongo.errors.OperationFailure as err:
        print("OperationFailure error : " + str(err))
        logger.error("OperationFailure error : " + str(err))
    except Exception as err:
        print("Exception error : " + str(err))
        logger.error("Exception error : " + str(err))

def majorHolders(symbol, ticker):
    try:
        mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
        allCompaniesDB= mongo_client["allCompaniesDB"]
        print(mongo_client.list_database_names())
        dblist = mongo_client.list_database_names()
        if "allCompaniesDB" in dblist:
            print("The database exists.")
        collist = allCompaniesDB.list_collection_names()
        if "allCompaniesCollection" in collist:
            print("The collection exists.")
            # allCompaniesDB.allCompaniesCollection.drop()

        symbol = symbol.upper()
        insidersPercentHeld = ticker.major_holders[symbol]['insidersPercentHeld']
        institutionsPercentHeld = ticker.major_holders[symbol]['institutionsPercentHeld']
        institutionsFloatPercentHeld = ticker.major_holders[symbol]['institutionsFloatPercentHeld']
        institutionsCount = ticker.major_holders[symbol]['institutionsCount']

        myquery = { "Ticker": symbol }
        newvalues = { "$set": { "insidersPercentHeld": insidersPercentHeld , "institutionsPercentHeld" : institutionsPercentHeld, "institutionsFloatPercentHeld" : institutionsFloatPercentHeld, "institutionsCount" : institutionsCount} }
        allCompaniesDB.allCompaniesCollection.update_one(myquery, newvalues)
    except (pymongo.errors.AutoReconnect, pymongo.errors.ConnectionFailure) as err:
        print("AutoReconnect error: " + str(err))
        logger.error("AutoReconnect error: " + str(err))
    except pymongo.errors.DuplicateKeyError as err:
        print("DuplicateKeyError error: " + str(err))
        logger.error("DuplicateKeyError error: " + str(err))
    except pymongo.errors.OperationFailure as err:
        print("OperationFailure error : " + str(err))
        logger.error("OperationFailure error : " + str(err))
    except Exception as err:
        print("Exception error : " + str(err))
        logger.error("Exception error : " + str(err))

def keyStats(symbol, ticker):
    try:
        mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
        allCompaniesDB= mongo_client["allCompaniesDB"]
        print(mongo_client.list_database_names())
        dblist = mongo_client.list_database_names()
        if "allCompaniesDB" in dblist:
            print("The database exists.")
        collist = allCompaniesDB.list_collection_names()
        if "allCompaniesCollection" in collist:
            print("The collection exists.")
            # allCompaniesDB.allCompaniesCollection.drop()

        symbol = symbol.upper()
        enterpriseValue = ticker.key_stats[symbol]['enterpriseValue']

        profitMargins = ticker.key_stats[symbol]['profitMargins']

        floatShares = ticker.key_stats[symbol]['floatShares']

        sharesOutstanding = ticker.key_stats[symbol]['sharesOutstanding']

        heldPercentInsiders = ticker.key_stats[symbol]['heldPercentInsiders']
        heldPercentInstitutions = ticker.key_stats[symbol]['heldPercentInstitutions']
        shortPercentOfFloat = ticker.key_stats[symbol]['shortPercentOfFloat']
        beta = ticker.key_stats[symbol]['beta']
        earningsQuarterlyGrowth = ticker.key_stats[symbol]['earningsQuarterlyGrowth']
        pegRatio = ticker.key_stats[symbol]['pegRatio']
        _52WeekChange = ticker.key_stats[symbol]['52WeekChange']

        myquery = { "Ticker": symbol }
        newvalues = { "$set": { "enterpriseValue": enterpriseValue , "profitMargins" : profitMargins, "floatShares" : floatShares, "sharesOutstanding" : sharesOutstanding, 'heldPercentInsiders':heldPercentInsiders , 'heldPercentInstitutions':heldPercentInstitutions, 'shortPercentOfFloat':shortPercentOfFloat, 'beta':beta, 'earningsQuarterlyGrowth':earningsQuarterlyGrowth, 'pegRatio':pegRatio, '_52WeekChange':_52WeekChange} }
        allCompaniesDB.allCompaniesCollection.update_one(myquery, newvalues)
    except (pymongo.errors.AutoReconnect, pymongo.errors.ConnectionFailure) as err:
        print("AutoReconnect error: " + str(err))
        logger.error("AutoReconnect error: " + str(err))
    except pymongo.errors.DuplicateKeyError as err:
        print("DuplicateKeyError error: " + str(err))
        logger.error("DuplicateKeyError error: " + str(err))
    except pymongo.errors.OperationFailure as err:
        print("OperationFailure error : " + str(err))
        logger.error("OperationFailure error : " + str(err))
    except Exception as err:
        print("Exception error : " + str(err))
        logger.error("Exception error : " + str(err))


def earningsDate(symbol, ticker):
    try:
        mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
        allCompaniesDB= mongo_client["allCompaniesDB"]
        print(mongo_client.list_database_names())
        dblist = mongo_client.list_database_names()
        if "allCompaniesDB" in dblist:
            print("The database exists.")
        collist = allCompaniesDB.list_collection_names()
        if "allCompaniesCollection" in collist:
            print("The collection exists.")
            # allCompaniesDB.allCompaniesCollection.drop()

        symbol = symbol.upper()
        earningsDate = ticker.calendar_events[symbol]['earnings']['earningsDate'][0]

        myquery = { "Ticker": symbol }
        newvalues = { "$set": { "earningsDate": earningsDate } }
        allCompaniesDB.allCompaniesCollection.update_one(myquery, newvalues)
    except (pymongo.errors.AutoReconnect, pymongo.errors.ConnectionFailure) as err:
        print("AutoReconnect error: " + str(err))
        logger.error("AutoReconnect error: " + str(err))
    except pymongo.errors.DuplicateKeyError as err:
        print("DuplicateKeyError error: " + str(err))
        logger.error("DuplicateKeyError error: " + str(err))
    except pymongo.errors.OperationFailure as err:
        print("OperationFailure error : " + str(err))
        logger.error("OperationFailure error : " + str(err))
    except Exception as err:
        print("Exception error : " + str(err))
        logger.error("Exception error : " + str(err))


def getCIK(ticker):
    df = pd.read_csv('CIK-Ticker-Map', sep="\t", header=None)
    df.columns = ["Ticker", "CIK"]
    df_new = df.query('Ticker == "%s" ' % ticker.lower())
    return str(df_new["CIK"].iloc[0])

def main(ticker):

    tickerObject = Ticker(ticker, asynchronous=True)
    print(ticker)
    fillTicker(ticker)
    fillCIK(ticker, getCIK(ticker))
    percentageChange(ticker, tickerObject)
    exchangeName(ticker, tickerObject)
    websiteCountry(ticker, tickerObject)
    priceMarketCap(ticker, tickerObject)
    majorHolders(ticker, tickerObject)
    keyStats(ticker, tickerObject)
    earningsDate(ticker, tickerObject)

if __name__=="__main__":
    begin_time = datetime.datetime.now()
    print(datetime.datetime.now())
    timestr = time.strftime("%Y%m%d")

    # now we will Create and configure logger
    logging.basicConfig(filename="batchFillDatabase" + timestr + ".log",
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                        filemode='w+')

    # Let us Create an object
    logger = logging.getLogger()

    # Now we are going to Set the threshold of logger to DEBUG
    logger.setLevel(logging.DEBUG)



    # tickerhelp()
    df = pd.read_csv('CIK-Ticker-Map', sep="\t", header=None)
    # df = df[:5]
    df.columns = ["Ticker", "CIK"]
    df = df[:100]
    string_list = [str(each_string).upper() for each_string in df["Ticker"]]

    p = Pool(16)
    company_object_list = p.map(main, string_list)
    p.terminate()
    p.join()
    end_time = datetime.datetime.now() - begin_time
    print(datetime.datetime.now() - begin_time)
