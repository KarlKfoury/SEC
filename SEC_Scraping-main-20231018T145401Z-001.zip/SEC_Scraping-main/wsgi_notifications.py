# -*- coding: utf-8 -*-
"""
Created on Sun Apr 25 18:44:11 2021

@author: marou
"""

from notifications import app

if __name__=="__main__":
    app.run()