import pandas as pd
from yahooquery import Ticker
from Definitions import web,summary2,pcs,sps,bss,fss,cfs,cash,kss_new,kss_old,mhs,pctchange,exchange,web2
from InsiderActivity import insiders2
from datetime import date
import datetime
import sqlite3
from bs4 import BeautifulSoup
from datetime import datetime
from IPython.display import HTML
import numpy as np
import requests
import textwrap
import feedparser
import random
from random import randint
from time import sleep
import Report

def database_file():
    filename = '/Users/ralph/biotech/BiotechDatabase.csv'
    fields = ['symbol','Company', 'My Notes Date','My Notes','Revisit Date','Score (1-10)','Last Updated','Exchange','First Traded','Industry','Sector','Phone',
                  'Web','Summary','Mkt. Cap','Price','Percent Change','Volume',
                  '1 Month Percentage Change','3 Month Percentage Change',
                  '1 Year Percentage Change','Date_BS','Cash/Short Term Inv.',
                  'Tot.Assets','Tot.Liabilities','Tot.Equity','Date_FS',
                  'Tot.Revenue','Net Income','Date_CF','Free Cash Flow',
                  'Date_CB','CashBurnPerDay','CashLeftToday','Months to 0$',
                  'Date of Short Report','EV','Shares Outst.','Float',
                  'Shares Short','Short % of Float','Short Ratio',
                  'Previous Date of Report','Prior Shares Short',
                  'Insiders % Held','Institutions Count',
                  'Institutions Float % Held','Institutions % Held',
                  'Buy (3M)','Buy (6M)','Buy (12M)','Sell (3M)','Sell (6M)',
                  'Sell (12M)','Shares Bought (3M)','Shares Bought (6M)',
                  'Shares Bought (12M)','Shares Sold (3M)','Shares Sold (6M)',
                  'Shares Sold (12M)']
    return filename,fields

def database():
    global db
    conn = sqlite3.connect("BiotechDatabase.db") 
    db = pd.read_sql_query("select * from biotech ORDER BY symbol ASC;", conn)
    conn.close()


def clean():
    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        symbols = pd.read_sql_query("select * from biotech;", conn)['symbol'].tolist()
        symbols
    except sqlite3.Error as error:
        print("Failed to access the BiotechDatabase file", error)  
    finally:
        if (conn):
            conn.close() 

        #validating if the ticker exists
        ticker = Ticker(symbols, asynchronous=True, validate = True)

    invalid = ticker.invalid_symbols
    if invalid is None:
        print('All symbols in the biotech table are valid')
    else:
        print("Invalid ticker list: "+ str(invalid))
        for i in ticker.invalid_symbols:
            print('Removing '+ i)
            remove(i)
    
def add(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    # ticker = Ticker(symbols, asynchronous=True)
    try:
        conn = sqlite3.connect("BiotechDatabase.db") 
        cur = conn.cursor()
        sql_select_query = "select * from biotech where symbol = ?"
        cur.execute(sql_select_query,(symbol,))
        row = cur.fetchone()
        conn.commit()
        cur.close()
    except sqlite3.Error as error:
        print("Failed to select symbol from biotech", error)
    finally:
        if (conn):
            conn.close()   
        
        if row is not None:
            print(symbol+ " is already in the biotech table")

        else:
            print('Adding '+ symbol)
            try:
                web2(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass
            try:
                summary2(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass
            try:
                pctchange(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass
            try:
                exchange(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass    
            try:
                pcs(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass    
            try:
                sps(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass    
            try:
                bss(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass    
            try:
                fss(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass    
            try:
                cfs(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass   
            try:
                cash(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass    
            try:
                kss_new(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass    
            try:
                kss_old(symbol)
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass     
            try:
                mhs(symbol)  
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass 
            try:
                insiders2(symbol) 
                sleep(randint(1,2))
            except Exception as e: 
                print(e)
                pass 

            date.today()
            try:
                conn = sqlite3.connect("BiotechDatabase.db") 
                cur = conn.cursor()
                cur.execute
                values = (symbol,date.today())
                # cur.execute("UPDATE biotech SET Web = ? WHERE symbol = ?", values )
                # cur.execute("update biotech set Web=? where symbol=?", values)
                cur.execute("""
                INSERT INTO biotech(symbol,[Last Updated]) 
                VALUES(?,?)
                ON CONFLICT(symbol) DO UPDATE SET [Last Updated]=excluded.`Last Updated`""",
                values 
                )
                conn.commit()
                cur.close()
            except sqlite3.Error as error:
                print("Failed to add Last updated", error)  
            finally:
                if (conn):
                    conn.close()

            sleep(randint(1,2))
    
    
def remove(symbol):
    symbol = symbol.upper()
    
    try:
        conn = sqlite3.connect("BiotechDatabase.db") 
        cur = conn.cursor()
        sql_select_query = "select * from biotech where symbol = ?"
        cur.execute(sql_select_query,(symbol,))
        row = cur.fetchone()
        conn.commit()
        cur.close()
    except sqlite3.Error as error:
        print("Failed to select from biotech", error)
    finally:
        if (conn):
            conn.close()   

    if row is None:
        print(symbol+ " is not in the biotech table")

    else:
        print('Removing '+ symbol)
        try:
            conn = sqlite3.connect("BiotechDatabase.db") 
            cur = conn.cursor()
            sql_delete_query = """DELETE from biotech where symbol = ?"""
            cur.execute(sql_delete_query, (symbol, ))
            conn.commit()
            print("Record deleted successfully")
            cur.close()

        except sqlite3.Error as error:
            print("Failed to delete symbol from biotech", error)
        finally:
            if (conn):
                conn.close()
    
def update():
    global df_bio
    filename,fields = database_file()
    df_bio = pd.read_csv(filename, names=fields, header=0, index_col='symbol')
    symbols = df_bio.index.tolist()
    #validating if the ticker exists
    ticker = Ticker(symbols, asynchronous=True)
    valid = ticker.validation

    #Dictionnary of all tickers with True for valid, False for invalid    
    for key1 in valid:
        dictionary  = valid[key1]
    #Dictionnary of all tickers with value = True for valid tickers
    dictionary_true = {key:value for (key,value) in dictionary.items() if value == True}
    #Dictionnary of all tickers with value = False for invalid tickers
    dictionary_false = {key:value for (key,value) in dictionary.items() if value == False}
    #List of all valid tickers 
    symbols_cleaned = list(dictionary_true.keys())
    #List of all invalid tickers
    symbols_na = list(dictionary_false.keys())
    print('Invalid tickers:')
    print(symbols_na)
    df_bio= df_bio.drop(symbols_na)

    for stock in symbols_cleaned:
        try:
            add(stock)
        except:
            continue
            
def add_list():
    global df_bio
    symbol = input("Insert your ticker symbols separated by ',' :  ")
    symbols = symbol.split(',')
    #validating if the ticker exists
    ticker = Ticker(symbols, asynchronous=True)
    valid = ticker.validation

    #Dictionnary of all tickers with True for valid, False for invalid    
    for key1 in valid:
        dictionary  = valid[key1]
    #Dictionnary of all tickers with value = True for valid tickers
    dictionary_true = {key:value for (key,value) in dictionary.items() if value == True}
    #Dictionnary of all tickers with value = False for invalid tickers
    dictionary_false = {key:value for (key,value) in dictionary.items() if value == False}
    #List of all valid tickers 
    symbols_cleaned = list(dictionary_true.keys())
    #List of all invalid tickers
    symbols_na = list(dictionary_false.keys())

    print('Invalid tickers:')
    print(symbols_na)

    for stock in symbols_cleaned:
        try:
            add(stock)
        except:
            continue

#compares database list to symbol list and only adds itmes not in database                   
def add_new_from_list():
    global df_bio
    symbol = input("Insert your ticker symbols separated by ',' :  ")
    symbols = symbol.split(',')
    filename,fields = database_file()
    df_bio = pd.read_csv(filename, names=fields, header=0, index_col='symbol')
    symbols_db = df_bio.index.tolist()

    diff = list(set(symbols) - set(symbols_db))

    #validating if the ticker exists
    ticker = Ticker(diff, asynchronous=True)
    valid = ticker.validation

    #Dictionnary of all tickers with True for valid, False for invalid    
    for key1 in valid:
        dictionary  = valid[key1]
    #Dictionnary of all tickers with value = True for valid tickers
    dictionary_true = {key:value for (key,value) in dictionary.items() if value == True}
    #Dictionnary of all tickers with value = False for invalid tickers
    dictionary_false = {key:value for (key,value) in dictionary.items() if value == False}
    #List of all valid tickers 
    symbols_cleaned = list(dictionary_true.keys())
    #List of all invalid tickers
    symbols_na = list(dictionary_false.keys())
    print('Invalid tickers:')
    print(symbols_na)

    print('Symbols not in the database:')
    print(diff)
    for stock in symbols_cleaned:
        try:
            add(stock)
        except:
            continue
            
def summary_search():    
    global df_bio
    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        df_bio = pd.read_sql_query("select * from biotech ORDER BY symbol ASC;", conn)
        df_bio = df_bio.set_index('symbol')
    except sqlite3.Error as error:
        print("Failed to select from biotech", error)  
    finally:
        if (conn):
            conn.close() 
    
    def find():
        search = input("Insert your keyword here: ")
        print('Results: ')
        return search
    item = find()

    ticker_list = df_bio[df_bio['Summary'].str.contains(item, case=False, na=False)].index.tolist()
    if not ticker_list:
        print('')
        print ('No stocks found')
    else:
        ticker_list_tweet = ', $'.join(ticker_list)
        ticker_list_tweet = "$"+ticker_list_tweet

        print('')
        print('Stocks researching '+ item+":")
        print(ticker_list_tweet)
  
        
        df_ticker_list = df_bio.loc[ticker_list]  
        return(df_ticker_list)
        
# search the clinicaltrials.gov database
def ct_search():
    global df_ct
    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        df_ct = pd.read_sql_query("select * from clinical_trials ORDER BY symbol ASC;", conn)
        df_ct = df_ct.set_index('symbol')
    except sqlite3.Error as error:
        print("Failed to select from biotech", error)  
    finally:
        if (conn):
            conn.close() 
    
    def find():
        search = input("Insert your keyword here: ")
        print('Results: ')
        return search
    item = find()
    
    ticker_list = []
    NCT_number_list = []
    search_cols = ['Title', 'Acronym', 'Study Results','Conditions','Interventions','Outcome Measures', 
                   'Sponsor/Collaborators','Study Designs','Other IDs']
    
    for col in search_cols:
        try:
            ticker_list_col = df_ct[df_ct[col].str.contains(item, case=False, na=False)].index.tolist() 
            NCT_number_list_col = df_ct[df_ct[col].str.contains(item, case=False, na=False)]['NCT Number'].tolist() 
            ticker_list = ticker_list + ticker_list_col
            NCT_number_list = NCT_number_list + NCT_number_list_col
        except AttributeError:
            continue

    if not ticker_list:
        print('')
        print ('No stocks found')
    else:
        ticker_list = list(set(ticker_list))
        ticker_list.sort()
        ticker_list
        ticker_list_tweet = ', $'.join(ticker_list)
        ticker_list_tweet = "$"+ticker_list_tweet

        df_ct_final = df_ct[df_ct['NCT Number'].isin(NCT_number_list) ]
        
        print('')
        print('Stocks researching '+ item+":")
        print(ticker_list_tweet)
        display(df_ct_final)

#Calls the add_later_list and checks if its tickers are already in the database, 
#if not it tries to add them then updates the list named add_later_list.pkl accordingly
def add_add_later_list():
    import pickle
    fh = open("add_later_list.pkl", 'rb')
    add_later_list = pickle.load(fh)
    print('Initial list content :')
    print(str(add_later_list))
    print('')
    fh.close()

    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        symbols_db1 = pd.read_sql_query("select * from biotech;", conn)['symbol'].tolist()

    except sqlite3.Error as error:
        print("Failed to select from biotech", error)  
    finally:
        if (conn):
            conn.close() 

    diff = list(set(add_later_list) - set(symbols_db1))
    diff = sorted(list(set(diff)))
    
    while("" in diff) : 
        diff.remove("")

    print('Validating stocks that are not yet in the database: ')
    print (str(diff))
    print('')

    #validating if the ticker exists
    ticker = Ticker(diff, asynchronous=True, validate = True)
    valid = ticker.symbols
    invalid = ticker.invalid_symbols
    if not valid:
        print('All symbols in the list to add are currently invalid')
    else:
        print('Adding valid stocks : '+str(valid))
        for stock in valid:
            try:
                add(stock)
                print('')
            except Exception as e: 
                print(e)
                pass

        try:
            conn = sqlite3.connect("BiotechDatabase.db")
            symbols_db2 = pd.read_sql_query("select * from biotech;", conn)['symbol'].tolist()

        except sqlite3.Error as error:
            print("Failed to select from biotech", error)  
        finally:
            if (conn):
                conn.close() 

        diff2 = list(set(diff) - set(symbols_db2))
        diff2 = sorted(list(set(diff2)))
        print('')
        print('Remaining list to add later: '+str(diff2))

        fh = open("add_later_list.pkl", 'wb')
        pickle.dump(diff2, fh)
        fh.close()
        fh = open("add_later_list.pkl", 'rb')
        add_later_list = pickle.load(fh)
        print()
        print('add_later_list updated')

#Adds tickers that are not yet on the market (new IPOs...) to a list named add_later_list.pkl
def add_later():
    import pickle

    fh = open("add_later_list.pkl", 'rb')
    add_later_list = pickle.load(fh)
    print('Initial list content ' + str(add_later_list))
    fh.close()

    def symbols_to_add():
        symbols_to_add = input("Insert your ticker symbols separated by ',' :  ")
        symbols_to_add = symbols_to_add.upper() 
        return symbols_to_add
    
    symbols_to_add =symbols_to_add()
    symbols_to_add = symbols_to_add.split(',')

    print('Tickers to add: '+ str(symbols_to_add))
    for i in symbols_to_add:
        add_later_list.append(i)
    add_later_list = sorted(list(set(add_later_list)))
    while("" in add_later_list) : 
        add_later_list.remove("")
    fh = open("add_later_list.pkl", 'wb')
    pickle.dump(add_later_list, fh)
    fh.close()
    print()
    print('add_later_list updated: ')
    print(add_later_list)
    
def my_notes(symbol):
    global df_bio
    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        df_bio = pd.read_sql_query("select * from biotech ORDER BY symbol ASC;", conn)

    except sqlite3.Error as error:
        print("Failed to select from biotech", error)  
    finally:
        if (conn):
            conn.close() 

    try:
        df_symbol = df_bio.loc[df_bio['symbol'] == symbol]

        df_notes = df_symbol[['symbol','My Notes Date','Revisit Date','Score (1-10)']]        
        print('My current notes on ' + symbol+': ')
        print(df_symbol.iloc[0]['My Notes'])
        return(df_notes)
    except Exception as e: 
        print(e)
        pass
    
def add_notes(symbol):   
    import datetime  
    symbol = symbol.upper()
    display(my_notes(symbol))
    print('')
    global df_bio
    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        df_bio = pd.read_sql_query("select * from biotech ORDER BY symbol ASC;", conn)
        df_symbol = df_bio.loc[df_bio['symbol'] == symbol]
    except sqlite3.Error as error:
        print("Failed to select from biotech", error)  
    finally:
        if (conn):
            conn.close() 
    
    def notes():
        notes = input("My updated notes: ")
        print('')
        return notes
    item = notes()
    
    date_entry = input('When to revisit (Enter a date in MM/DD/YYYY format): ')
    if date_entry =="":
        date1 = df_symbol.iloc[0]['Revisit Date']
        pass
    else:
        month, day, year = map(int, date_entry.split('/'))
        date1 = datetime.date(year,month,day)
    score = input('Scientific score (1-10): ')
    if score =="":
        score = df_symbol.iloc[0]['Score (1-10)']
        pass
    else:
        score = score
        
    try:
        conn = sqlite3.connect("BiotechDatabase.db")   
        cur = conn.cursor()
        values = (symbol,date.today(),item,date1,score)
        # cur.execute("UPDATE biotech SET Web = ? WHERE symbol = ?", values )
        # cur.execute("update biotech set Web=? where symbol=?", values)
        cur.execute("""
        INSERT INTO biotech(symbol,[My Notes Date],[My Notes],[Revisit Date],[Score (1-10)]) 
        VALUES(?,?,?,?,?)
        ON CONFLICT(symbol) DO UPDATE SET [My Notes Date]=excluded.`My Notes Date`,[My Notes]=excluded.`My Notes`,[Revisit Date]=excluded.`Revisit Date`,[Score (1-10)]=excluded.`Score (1-10)`""",
        values 
        )

        conn.commit()
        cur.close()
    except sqlite3.Error as error:
        print("Failed to add notes", error)                                
    conn.close() 
    print(symbol+' notes updated')

def cik(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    # ticker = Ticker(symbols, asynchronous=True)
    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db") 
        cur = conn.cursor()
        sql_select_query = "select CIK from biotech where symbol = ?"
        cur.execute(sql_select_query,(symbol,))
        cik = str(cur.fetchone()[0])
        conn.commit()
        cur.close()
        return cik
    except sqlite3.Error as error:
        print("Failed to select symbol from biotech", error)
    finally:
        if (conn):
            conn.close() 