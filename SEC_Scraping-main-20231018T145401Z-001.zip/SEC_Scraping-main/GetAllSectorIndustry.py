import pandas as pd
from yahooquery import Ticker
from multiprocessing import Pool
from pymongo import MongoClient


import utils
def yahooqueryuerysectorindustry(ticker):
    print("Ticker: " + ticker)
    try:
        symbol = ticker
        ticker1 = Ticker(symbol, asynchronous=True)
        industry = ticker1.summary_profile[ticker]['Industry']
        sector = ticker1.summary_profile[ticker]['Sector']
    except:
        try:
            symbol = ticker
            ticker1 = Ticker(symbol, asynchronous=True)
            industry = ticker1.summary_profile[ticker]['industry']
            sector = ticker1.summary_profile[ticker]['sector']
        except:
            sector = "Undefined"
            industry = "Undefined"

    print("Sector: " + sector)
    print("Industry: " + industry)

    return {"sector" : sector , "industry" : industry }


def getsectorindustry():
    utils.createTickerCIKMap()
    df = pd.read_csv('CIK-Ticker-Map', sep="\t", header=None)
    df.columns = ["Ticker", "CIK"]
    p = Pool(8)
    formDataList = p.map(yahooqueryuerysectorindustry, df["Ticker"])
    p.terminate()
    p.join()

    return formDataList


def getindustrysectorfromDB():


    # creation of MongoClient
    client=MongoClient()

    # Connect with the portnumber and host
    client = MongoClient("mongodb://localhost:27017/")

    # Access database
    mydatabase = client['IndustrySectorDB']

    # Access collection of the database
    mycollection=mydatabase['IndustrySector']

    stage_group_year = {
   "$group": {
         "_id": "$industry",
       }
    }
    pipeline = [
       stage_group_year,
    ]
    results = mycollection.aggregate(pipeline)


    for i in results:
        print(i)
if __name__ == '__main__':

    # getsectorindustry()
    getindustrysectorfromDB()



