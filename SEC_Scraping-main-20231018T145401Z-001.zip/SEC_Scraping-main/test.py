import csv
import sqlite3
con = sqlite3.connect("biotechdatabase.db")
cur = con.cursor()

clinical_trials = open("clinical_trials.csv")
rows = csv.reader(clinical_trials)
cur.executemany("INSERT INTO clinical_trials VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)

cur.execute("SELECT * FROM clinical_trials")
print(cur.fetchall())

con.commit()
con.close()