import pandas as pd
import numpy as np
from bs4 import BeautifulSoup
import requests
import sqlite3

def insiders(symbol):
    df_insiders_all = pd.DataFrame()
    symbol = symbol.upper()
    symbols = symbol.split(',')
    #ticker = Ticker(symbols, asynchronous=True)
    for a in symbols:
        try:
            url1 = 'https://www.marketwatch.com/investing/stock/'+str(a)+'/insideractions'
            #print(url1)
            res1 = requests.get(url1)
            #print(res1)
            soup1 = BeautifulSoup(res1.text, 'html.parser')
            summary = soup1.find("div", {"id": "insiderTransactionSummary"})
            try:
                pd.read_html(str(summary), header =0, index_col=0)
            except ValueError:
                print('-'*60)
                print('-'*60)
                print('')
                print ('INSIDER TRANSACTIONS:')
                print("No Insider Transaction data available for "+symbol)
                pass
            else:
                dfs1=pd.read_html(str(summary), header =0, index_col=0)
                for df1 in dfs1:
                    df1.insert(0, "symbol", [str(a), str(a), str(a)], True) 
                    df1.reset_index(inplace=True)
                    df1 = df1.drop(['Timeframe'], axis = 1)
                    df1 = df1.set_index ('symbol')

                    df_transactions=df1[['Transactions']]
                    df_shares=df1[['Shares']]

                    new1 = df_shares["Shares"].str.split(" ", n = -1, expand = True) 
                    df_shares["Shares Bought"]= new1[0]
                    df_shares["Shares Bought"]=df_shares["Shares Bought"].replace({',':''},regex=True).apply(pd.to_numeric,1)
                    df_shares["Shares Sold"]= new1[1] 
                    df_shares["Shares Sold"]=df_shares["Shares Sold"].replace({',':''},regex=True).apply(pd.to_numeric,1)
                    df_shares.drop(columns =["Shares"], inplace = True) 
                    df_shares = df_shares.reset_index()

                    new2 = df_transactions["Transactions"].str.split(" ", n = -1, expand = True) 
                    df_transactions["Buy"]= new2[0]
                    df_transactions["Sell"]= new2[4]
                    df_transactions = df_transactions.reset_index()
                    df_transactions.drop(columns =["Transactions"], inplace = True) 
                    df_transactions

                    df_insiders = pd.concat([df_transactions,df_shares], axis=1)
                    df_insiders = df_insiders.loc[:,~df_insiders.columns.duplicated()]
                    df_insiders
                    df_insiders = df_insiders.set_index ('symbol')
                    df_insiders1 = df_insiders.groupby('symbol').first()
                    df_insiders3 = df_insiders.groupby('symbol').last()
                    df_insiders2 = df_insiders.iloc[1:2]
                    df_insidersow = df_insiders1.merge(df_insiders2, left_index=True, right_index=True).merge(df_insiders3, left_index=True, right_index=True)
                    df_insidersow = df_insidersow.rename(columns={"Buy_x": "Buy (3M)", "Sell_x": "Sell (3M)","Shares Bought_x": "Shares Bought (3M)","Shares Sold_x": "Shares Sold (3M)","Buy_y": "Buy (6M)","Sell_y": "Sell (6M)","Shares Bought_y": "Shares Bought (6M)","Shares Sold_y": "Shares Sold (6M)","Buy": "Buy (12M)","Sell": "Sell (12M)","Shares Bought": "Shares Bought (12M)","Shares Sold": "Shares Sold (12M)"})
                    df_insidersow
                    df_insiders_all = df_insiders_all.append(df_insidersow)

                    df_buys=df_insiders_all[["Buy (3M)","Buy (6M)","Buy (12M)"]].copy()
                    df_sells=df_insiders_all[["Sell (3M)","Sell (6M)","Sell (12M)"]].copy()
                    df_sharesB=df_insiders_all[["Shares Bought (3M)","Shares Bought (6M)","Shares Bought (12M)"]].copy()
                    df_sharesS=df_insiders_all[["Shares Sold (3M)","Shares Sold (6M)","Shares Sold (12M)"]].copy()

                    cols1=[i for i in df_buys.columns]
                    df_buys[cols1] = df_buys[cols1].apply(pd.to_numeric, errors='ignore', downcast='float')
                    df_buys[cols1] = df_buys[cols1].astype(np.float64)

                    cols2=[j for j in df_sells.columns]
                    df_sells[cols2] = df_sells[cols2].apply(pd.to_numeric, errors='ignore', downcast='float')
                    df_sells[cols2] = df_sells[cols2].astype(np.float64)   

                    cols3=[k for k in df_sharesB.columns]
                    df_sharesB[cols3] = df_sharesB[cols3].apply(pd.to_numeric, errors='ignore', downcast='float')
                    df_sharesB[cols3] = df_sharesB[cols3].astype(np.float64)

                    cols4=[l for l in df_sharesS.columns]
                    df_sharesS[cols4] = df_sharesS[cols4].apply(pd.to_numeric, errors='ignore', downcast='float')
                    df_sharesS[cols4] = df_sharesS[cols4].astype(np.float64)

#                 return (df_insiders_all)
                print('-'*60)
                print('-'*60)
                print('')
                print ('INSIDER TRANSACTIONS:')
                try:
                    display (df_buys)
                except Exception as e: 
                    print(e)
                    pass
                try:
                    display (df_sells)
                except Exception as e: 
                    print(e)
                    pass
                print('-'*60)
                print('-'*60)
                print ('INSIDER VOLUME:')
                try:
                    display (df_sharesB)
                except Exception as e: 
                    print(e)
                    pass
                try:
                    display (df_sharesS)
                except Exception as e: 
                    print(e)
                    pass
                    
                try:    
                    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")   
                    cur = conn.cursor()
                    values = (symbol,df_buys.loc[symbol,'Buy (3M)'],df_buys.loc[symbol,'Buy (6M)'],df_buys.loc[symbol,'Buy (12M)'],df_sells.loc[symbol,'Sell (3M)'],df_sells.loc[symbol,'Sell (6M)'],df_sells.loc[symbol,'Sell (12M)'],df_sharesB.loc[symbol,'Shares Bought (3M)'],df_sharesB.loc[symbol,'Shares Bought (6M)'],df_sharesB.loc[symbol,'Shares Bought (12M)'],df_sharesS.loc[symbol,'Shares Sold (3M)'],df_sharesS.loc[symbol,'Shares Sold (6M)'],df_sharesS.loc[symbol,'Shares Sold (12M)'])
                    cur.execute("""
                    INSERT INTO biotech(symbol,[Buy (3M)],[Buy (6M)],[Buy (12M)],[Sell (3M)],[Sell (6M)],[Sell (12M)],[Shares Bought (3M)],[Shares Bought (6M)],[Shares Bought (12M)],[Shares Sold (3M)],[Shares Sold (6M)],[Shares Sold (12M)])
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(symbol) DO UPDATE SET [Buy (3M)]=excluded.`Buy (3M)`,[Buy (6M)]=excluded.`Buy (6M)`,[Buy (12M)]=excluded.`Buy (12M)`,[Sell (3M)]=excluded.`Sell (3M)`,[Sell (6M)]=excluded.`Sell (6M)`,[Sell (12M)]=excluded.`Sell (12M)`,[Shares Bought (3M)]=excluded.`Shares Bought (3M)`,[Shares Bought (6M)]=excluded.`Shares Bought (6M)`,[Shares Bought (12M)]=excluded.`Shares Bought (12M)`,[Shares Sold (3M)]=excluded.`Shares Sold (3M)`,[Shares Sold (6M)]=excluded.`Shares Sold (6M)`,[Shares Sold (12M)]=excluded.`Shares Sold (12M)`""",
                    values)

                    conn.commit()
                    cur.close()
                except sqlite3.Error as error:
                    print("Failed to add insiders", error)                                
                finally:
                    if (conn):
                        conn.close()              
  
        except Exception as e: 
            print(e)
            pass

    
def insiders2(symbol):
    df_insiders_all = pd.DataFrame()
    symbol = symbol.upper()
    symbols = symbol.split(',')
    #ticker = Ticker(symbols, asynchronous=True)
    for a in symbols:
        try:
            url1 = 'https://www.marketwatch.com/investing/stock/'+str(a)+'/insideractions'
            #print(url1)
            res1 = requests.get(url1)
            #print(res1)
            soup1 = BeautifulSoup(res1.text, 'html.parser')
            summary = soup1.find("div", {"id": "insiderTransactionSummary"})
            try:
                pd.read_html(str(summary), header =0, index_col=0)
            except ValueError:
                pass
                print("No Insider Transaction data available for "+symbol)
            else:
                dfs1=pd.read_html(str(summary), header =0, index_col=0)
                for df1 in dfs1:
                    df1.insert(0, "symbol", [str(a), str(a), str(a)], True) 
                    df1.reset_index(inplace=True)
                    df1 = df1.drop(['Timeframe'], axis = 1)
                    df1 = df1.set_index ('symbol')

                    df_transactions=df1[['Transactions']]
                    df_shares=df1[['Shares']]

                    new1 = df_shares["Shares"].str.split(" ", n = -1, expand = True) 
                    df_shares["Shares Bought"]= new1[0]
                    df_shares["Shares Bought"]=df_shares["Shares Bought"].replace({',':''},regex=True).apply(pd.to_numeric,1)
                    df_shares["Shares Sold"]= new1[1] 
                    df_shares["Shares Sold"]=df_shares["Shares Sold"].replace({',':''},regex=True).apply(pd.to_numeric,1)
                    df_shares.drop(columns =["Shares"], inplace = True) 
                    df_shares = df_shares.reset_index()

                    new2 = df_transactions["Transactions"].str.split(" ", n = -1, expand = True) 
                    df_transactions["Buy"]= new2[0]
                    df_transactions["Sell"]= new2[4]
                    df_transactions = df_transactions.reset_index()
                    df_transactions.drop(columns =["Transactions"], inplace = True) 
                    df_transactions

                    df_insiders = pd.concat([df_transactions,df_shares], axis=1)
                    df_insiders = df_insiders.loc[:,~df_insiders.columns.duplicated()]
                    df_insiders
                    df_insiders = df_insiders.set_index ('symbol')
                    df_insiders1 = df_insiders.groupby('symbol').first()
                    df_insiders3 = df_insiders.groupby('symbol').last()
                    df_insiders2 = df_insiders.iloc[1:2]
                    df_insidersow = df_insiders1.merge(df_insiders2, left_index=True, right_index=True).merge(df_insiders3, left_index=True, right_index=True)
                    df_insidersow = df_insidersow.rename(columns={"Buy_x": "Buy (3M)", "Sell_x": "Sell (3M)","Shares Bought_x": "Shares Bought (3M)","Shares Sold_x": "Shares Sold (3M)","Buy_y": "Buy (6M)","Sell_y": "Sell (6M)","Shares Bought_y": "Shares Bought (6M)","Shares Sold_y": "Shares Sold (6M)","Buy": "Buy (12M)","Sell": "Sell (12M)","Shares Bought": "Shares Bought (12M)","Shares Sold": "Shares Sold (12M)"})
                    df_insidersow
                    df_insiders_all = df_insiders_all.append(df_insidersow)

                    df_buys=df_insiders_all[["Buy (3M)","Buy (6M)","Buy (12M)"]].copy()
                    df_sells=df_insiders_all[["Sell (3M)","Sell (6M)","Sell (12M)"]].copy()
                    df_sharesB=df_insiders_all[["Shares Bought (3M)","Shares Bought (6M)","Shares Bought (12M)"]].copy()
                    df_sharesS=df_insiders_all[["Shares Sold (3M)","Shares Sold (6M)","Shares Sold (12M)"]].copy()

                    cols1=[i for i in df_buys.columns]
                    df_buys[cols1] = df_buys[cols1].apply(pd.to_numeric, errors='ignore', downcast='float')
                    df_buys[cols1] = df_buys[cols1].astype(np.float64)

                    cols2=[j for j in df_sells.columns]
                    df_sells[cols2] = df_sells[cols2].apply(pd.to_numeric, errors='ignore', downcast='float')
                    df_sells[cols2] = df_sells[cols2].astype(np.float64)   

                    cols3=[k for k in df_sharesB.columns]
                    df_sharesB[cols3] = df_sharesB[cols3].apply(pd.to_numeric, errors='ignore', downcast='float')
                    df_sharesB[cols3] = df_sharesB[cols3].astype(np.float64)

                    cols4=[l for l in df_sharesS.columns]
                    df_sharesS[cols4] = df_sharesS[cols4].apply(pd.to_numeric, errors='ignore', downcast='float')
                    df_sharesS[cols4] = df_sharesS[cols4].astype(np.float64)
                    
#                     try:
#                         return(df_buys)
#                     except Exception as e: 
#                             print(e)
#                             pass
#                     try:
#                         return(df_sells)
#                     except Exception as e: 
#                             print(e)
#                             pass
#                     try:
#                         return(df_sharesB)
#                     except Exception as e: 
#                             print(e)
#                             pass
#                     try:
#                         return(df_sharesS)
#                     except Exception as e: 
#                             print(e)
#                             pass

                    try:    
                        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")   
                        cur = conn.cursor()
                        values = (symbol,df_buys.loc[symbol,'Buy (3M)'],df_buys.loc[symbol,'Buy (6M)'],df_buys.loc[symbol,'Buy (12M)'],df_sells.loc[symbol,'Sell (3M)'],df_sells.loc[symbol,'Sell (6M)'],df_sells.loc[symbol,'Sell (12M)'],df_sharesB.loc[symbol,'Shares Bought (3M)'],df_sharesB.loc[symbol,'Shares Bought (6M)'],df_sharesB.loc[symbol,'Shares Bought (12M)'],df_sharesS.loc[symbol,'Shares Sold (3M)'],df_sharesS.loc[symbol,'Shares Sold (6M)'],df_sharesS.loc[symbol,'Shares Sold (12M)'])
                        cur.execute("""
                        INSERT INTO biotech(symbol,[Buy (3M)],[Buy (6M)],[Buy (12M)],[Sell (3M)],[Sell (6M)],[Sell (12M)],[Shares Bought (3M)],[Shares Bought (6M)],[Shares Bought (12M)],[Shares Sold (3M)],[Shares Sold (6M)],[Shares Sold (12M)])
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(symbol) DO UPDATE SET [Buy (3M)]=excluded.`Buy (3M)`,[Buy (6M)]=excluded.`Buy (6M)`,[Buy (12M)]=excluded.`Buy (12M)`,[Sell (3M)]=excluded.`Sell (3M)`,[Sell (6M)]=excluded.`Sell (6M)`,[Sell (12M)]=excluded.`Sell (12M)`,[Shares Bought (3M)]=excluded.`Shares Bought (3M)`,[Shares Bought (6M)]=excluded.`Shares Bought (6M)`,[Shares Bought (12M)]=excluded.`Shares Bought (12M)`,[Shares Sold (3M)]=excluded.`Shares Sold (3M)`,[Shares Sold (6M)]=excluded.`Shares Sold (6M)`,[Shares Sold (12M)]=excluded.`Shares Sold (12M)`""",
                        values)

                        conn.commit()
                        cur.close()
                    except sqlite3.Error as error:
                        print("Failed to add insiders", error)                                
                    finally:
                        if (conn):
                            conn.close()              

        except Exception as e: 
            print(e)
            pass



