import pandas as pd
from yahooquery import Ticker
import sqlite3
from bs4 import BeautifulSoup
from datetime import date
import matplotlib.pyplot as plt
import textwrap
import numpy as np
import requests
import sys
from IPython.display import HTML
import contextlib
import pandas.io.formats.format as pf

from IPython.display import display


# class _IntArrayFormatter(pd.io.formats.format.GenericArrayFormatter):

#     def _format_strings(self):
#         formatter = self.formatter or (lambda x: ' {:,}'.format(x))
#         fmt_values = [formatter(x) for x in self.values]
#         return fmt_values
# #-------------------------------------------

# This script allows to display integers with commas if the following is used:
# with custom_formatting():
#            display(df)
@contextlib.contextmanager
def custom_formatting():
    orig_float_format = pd.options.display.float_format
    orig_int_format = pf.IntArrayFormatter

    pd.options.display.float_format = '{:0,.2f}'.format

    class IntArrayFormatter(pf.GenericArrayFormatter):
        def _format_strings(self):
            formatter = self.formatter or '{:,d}'.format
            fmt_values = [formatter(x) for x in self.values]
            return fmt_values

    pf.IntArrayFormatter = IntArrayFormatter
    yield
    pd.options.display.float_format = orig_float_format
    pf.IntArrayFormatter = orig_int_format


def tickerhelp():
    print('''
    Stock's Company related:
    summary(''): Company summary 
    web(''): Company website
    sp(''), sps('') (for short version):  Summary profile
    salaries(''): Executive Salaries
    news(''): Recent news (yahoo)
    links(''): Helpful links
    
    Stock related:
    exchange(''):Stock exchange, along with date it started trading
    trend(''): Stock trend
    pctchange(''): Stock % change
    pc(''), pcs('') (for short version): Stock price
    ks(''), kss_new('') kss_old('') (for short version): Key statistics
    validate(''): Validate a ticker

    
    Stock Financials:
    bs('') , bss('') (for short version): Balance sheet
    fs('') , fss('') (for short version): Financial statement
    cf(''), cfs('') (for short version): Cash flows
    cash(''): time to 0$ cash based on cash burn
    dilution(''): Dilution SEC filings

    Stock Ownership:
    mhs(''): Major holders (from Yahoo)
    insiders(''): Insider activity (Buyers/sellers for the past 12 months)
    biotech_hf(''): Biotech hedge funds positionning (Perceptive, Baker Brothers...) from the latest 13F SEC filings
    institutions(''): Institutional Ownnership
    
    Drug related:
    pipeline (''): pulls the drug pipeline of a particular stock
    catalyst(''): pulls the drug catalysts of a particular stock
    search():asks for a word to look up in all the pipeline data
    catalystsall(): generates the whole dataframe of catalysts from the CSV file
    catalysts_update():updates the whole dataframe of catalysts and saves it to the CSV file
    pipeline_update():updates the pipeline of drugs of all companies with their news links, phase of study, and status
    clinical_trials('drug'): looks up a drug in clinicaltrials.gov and results a dataframe of all studies
    
    Database:
    database(): calls in df_bio, my main database
    add('symbol'): adds symbol to database along with report data
    clean(): cleans database from invalid tickers
    remove(''): removes a particular ticker from the database
    update(): update all tickers 
    add_list(): adds the items in symbol (separated by ',') to database
    add_new_from_list(): compares database list to symbol list and only adds itmes not in database
    add_later():adds tickers not yet on the market (IPO...) to add_later_list.pkl
    add_add_later_list():Calls the add_later_list and checks if its tickers are already in the database, if not it tries to add them then updates the list named add_later_list.pkl accordingly
    summary_search(): asks for a word to look up in all the database summaries
    ct_search(): searches for a word in the ClinicalTrials.Gov database
    
    Insider activity in the database:
    insiders_buy(): displays the most recent insider buyin activity of stocks in the database
    insiders_all(): displays the most recent insider activity of stocks in the database     
    
    Feeds:
    news(): News feed
    journals(): new publications in medical journals
    ''')


# -------------------------------------------
def trend(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    fig = plt.figure()
    ax1 = fig.add_subplot(1, 3, 1)
    ax1.set_title('1 Month Chart')
    ax2 = fig.add_subplot(1, 3, 2)
    ax2.set_title('3 Month Chart')
    ax3 = fig.add_subplot(1, 3, 3)
    ax3.set_title('1 Year Chart')

    df_1m = ticker.history(period='1mo')
    df_3m = ticker.history(period='3mo')
    df_1y = ticker.history(period='1y')

    df_1m = df_1m.reset_index(level=['date'])
    df_3m = df_3m.reset_index(level=['date'])
    df_1y = df_1y.reset_index(level=['date'])
    # # print(plt.plot(df_1m['adjclose']))
    # # print(plt.plot(df_3m['adjclose']))
    # # print(plt.plot(df_1y['adjclose']))

    ax1.plot(df_1m['date'], df_1m['close'])
    ax2.plot(df_3m['date'], df_3m['close'])
    ax3.plot(df_1y['date'], df_1y['close'])
    # fig = plt.gcf()
    fig.set_size_inches(13, 2)
    fig.autofmt_xdate()
    return (plt.show())


# -------------------------------------------

def pctchange(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_pc1 = pd.DataFrame.from_dict(ticker.price, orient='index')
    try:

        df_1m = ticker.history(period='1mo')
        df_3m = ticker.history(period='3mo')
        df_1y = ticker.history(period='1y')

        Close1Mo = float(df_1m.head(1)['close'])
        Close3Mo = float(df_3m.head(1)['close'])
        Close1Y = float(df_1y.head(1)['close'])
        PriceToday = float(df_pc1['regularMarketPrice'])

        close = [{'PriceToday': PriceToday, 'Close1Mo': Close1Mo, 'Close3Mo': Close3Mo, 'Close1Y': Close1Y}]
        df_close = pd.DataFrame(close, index=symbols)
        df_close['1 Month Percentage Change'] = (df_close['PriceToday'] - df_close['Close1Mo']) / df_close['Close1Mo']
        df_close['1 Month Percentage Change'] = df_close['1 Month Percentage Change'].apply('{:.2%}'.format)
        df_close['3 Month Percentage Change'] = (df_close['PriceToday'] - df_close['Close3Mo']) / df_close['Close3Mo']
        df_close['3 Month Percentage Change'] = df_close['3 Month Percentage Change'].apply('{:.2%}'.format)
        df_close['1 Year Percentage Change'] = (df_close['PriceToday'] - df_close['Close1Y']) / df_close['Close1Y']
        df_close['1 Year Percentage Change'] = df_close['1 Year Percentage Change'].apply('{:.2%}'.format)
        df_pct = df_close.drop(columns=['PriceToday', 'Close1Mo', 'Close3Mo', 'Close1Y'])

        try:
            conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
            cur = conn.cursor()
            values = (symbol, df_close['1 Month Percentage Change'][0], df_close['3 Month Percentage Change'][0],
                      df_close['1 Year Percentage Change'][0])
            cur.execute('''
            INSERT INTO biotech (symbol,[1 Month Percentage Change],[3 Month Percentage Change],[1 Year Percentage Change]) 
            VALUES(?,?,?,?)
            ON CONFLICT(symbol) DO UPDATE SET 
            ([1 Month Percentage Change],[3 Month Percentage Change],[1 Year Percentage Change])=
            (excluded.`1 Month Percentage Change`,excluded.`3 Month Percentage Change`,excluded.`1 Year Percentage Change`)''',
                        values
                        )
            conn.commit()
            cur.close()
        except sqlite3.Error as error:
            print("Failed to add pctchange", error)
        finally:
            if (conn):
                conn.close()

        return (df_pct)
    except Exception as e:
        print(e)
        pass


# --------------------------------------------

def web(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_sp1 = pd.DataFrame.from_dict(ticker.summary_profile, orient='index')
    df_sp2 = df_sp1.add_suffix('_sp')
    try:
        df_web1 = df_sp2['website_sp']
        df_web2 = df_web1.iloc[0]

        try:
            conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
            cur = conn.cursor()
            values = (symbol, df_web2)
            # cur.execute("UPDATE biotech SET Web = ? WHERE symbol = ?", values )
            # cur.execute("update biotech set Web=? where symbol=?", values)
            cur.execute("""
            INSERT INTO biotech(symbol,Web) 
            VALUES(?,?)
            ON CONFLICT(symbol) DO UPDATE SET Web=excluded.Web""",
                        values
                        )

            conn.commit()
            cur.close()
        except sqlite3.Error as error:
            print("Failed to add pctchange", error)
            conn.close()

        print(df_web2)
    except Exception as e:
        print(e)
        pass


def web2(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_sp1 = pd.DataFrame.from_dict(ticker.summary_profile, orient='index')
    df_sp2 = df_sp1.add_suffix('_sp')
    try:
        df_web1 = df_sp2['website_sp']
        df_web2 = df_web1.iloc[0]

        try:
            conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
            cur = conn.cursor()
            values = (symbol, df_web2)
            # cur.execute("UPDATE biotech SET Web = ? WHERE symbol = ?", values )
            # cur.execute("update biotech set Web=? where symbol=?", values)
            cur.execute("""
            INSERT INTO biotech(symbol,Web) 
            VALUES(?,?)
            ON CONFLICT(symbol) DO UPDATE SET Web=excluded.Web""",
                        values
                        )

            conn.commit()
            cur.close()
        except sqlite3.Error as error:
            print("Failed to add pctchange", error)
            conn.close()

            return (df_web2)
    except Exception as e:
        print(e)
        pass


# --------------------------------------------
def sp(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_sp1 = pd.DataFrame.from_dict(ticker.summary_profile, orient='index')
    df_sp2 = df_sp1.add_suffix('_sp')
    try:
        return (df_sp2)
    except Exception as e:
        print(e)
        pass


# --------------------------------------------
def summary(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_sp1 = pd.DataFrame.from_dict(ticker.summary_profile, orient='index')
    df_sp2 = df_sp1.add_suffix('_sp')
    try:
        df_sum1 = df_sp2['longBusinessSummary_sp']
        df_sum2 = df_sum1.iloc[0]
        sum = str(df_sum2)
        print(textwrap.fill(sum, width=70))
        try:
            conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
            cur = conn.cursor()
            values = (symbol, sum)
            cur.execute("""
            INSERT INTO biotech(symbol,Summary) 
            VALUES(?,?)
            ON CONFLICT(symbol) DO UPDATE SET Summary=excluded.Summary""",
                        values
                        )
            conn.commit()
            cur.close()
        except sqlite3.Error as error:
            print("Failed to add summary", error)
        finally:
            if (conn):
                conn.close()

    except Exception as e:
        print(e)
        pass


# --------------------------------------------

def summary2(symbol):  # Code identical to summary except for I removed the print command so I get no output
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_sp1 = pd.DataFrame.from_dict(ticker.summary_profile, orient='index')
    df_sp2 = df_sp1.add_suffix('_sp')
    try:
        df_sum1 = df_sp2['longBusinessSummary_sp']
        df_sum2 = df_sum1.iloc[0]
        sum = str(df_sum2)

        try:
            conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
            cur = conn.cursor()
            values = (symbol, sum)
            cur.execute("""
            INSERT INTO biotech(symbol,Summary) 
            VALUES(?,?)
            ON CONFLICT(symbol) DO UPDATE SET Summary=excluded.Summary""",
                        values
                        )
            conn.commit()
            cur.close()
        except sqlite3.Error as error:
            print("Failed to add summary", error)
        finally:
            if (conn):
                conn.close()

    except Exception as e:
        print(e)
        pass


# --------------------------------------------
def exchange(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        df_exchange = pd.DataFrame.from_dict(ticker.quote_type, orient='index')
        df_exchange = df_exchange[['exchange', 'firstTradeDateEpochUtc']]
        df_exchange = df_exchange.rename(columns={"exchange": "Exchange", "firstTradeDateEpochUtc": "First Traded"})
        df_pc1 = pd.DataFrame.from_dict(ticker.price, orient='index')
        df_pc1 = df_pc1.rename(columns={"exchangeName": "Exchange Name"})
        df_pc2 = df_pc1[['Exchange Name']]
        df_exchange = df_pc2.join(df_exchange)
        try:
            conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
            cur = conn.cursor()
            values = (symbol, df_exchange.loc[symbol, 'Exchange Name'], df_exchange.loc[symbol, 'First Traded'])
            cur.execute("""
            INSERT INTO biotech(symbol,Exchange,[First Traded]) 
            VALUES(?,?,?)
            ON CONFLICT(symbol) DO UPDATE SET Exchange=excluded.Exchange, [First Traded]=excluded.`First Traded`""",
                        values
                        )
            conn.commit()
            cur.close()
        except sqlite3.Error as error:
            print("Failed to add exchange", error)
        finally:
            if (conn):
                conn.close()

        return (df_exchange)
    except Exception as e:
        print(e)
        pass


# --------------------------------------------

def sps(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_sp1 = pd.DataFrame.from_dict(ticker.summary_profile, orient='index')
    df_sp2 = df_sp1.add_suffix('_sp')
    try:
        df_sps = df_sp2[['industry_sp', 'sector_sp', 'phone_sp']]
        df_sps.columns = [['Industry', 'Sector', 'Phone']]

        try:
            conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
            cur = conn.cursor()
            values = (
            symbol, df_sps.loc[symbol, 'Industry'][0], df_sps.loc[symbol, 'Sector'][0], df_sps.loc[symbol, 'Phone'][0])
            cur.execute("""
            INSERT INTO biotech(symbol,Industry,Sector,Phone) 
            VALUES(?,?,?,?)
            ON CONFLICT(symbol) DO UPDATE SET Industry=excluded.Industry, Sector=excluded.Sector,Phone=excluded.Phone""",
                        values
                        )
            conn.commit()
            cur.close()
        except sqlite3.Error as error:
            print("Failed to add sps", error)
        finally:
            if (conn):
                conn.close()

        return (df_sps)
    except Exception as e:
        print(e)
        pass


# -------------------------------------------------------

# Price
def pc(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_pc1 = pd.DataFrame.from_dict(ticker.price, orient='index')
    df_pc2 = df_pc1.add_suffix('_pc')
    return (df_pc2)


def pcs(symbol):
    import numpy as np
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        df_pc1 = pd.DataFrame.from_dict(ticker.price, orient='index')
        df_pc2 = df_pc1.add_suffix('_pc')
        pc_columns = ['shortName_pc', 'marketCap_pc', 'regularMarketPrice_pc', 'regularMarketChangePercent_pc',
                      'regularMarketVolume_pc']
        df_pcs = df_pc2[df_pc2.columns.intersection(pc_columns)]
        df_pcs = df_pcs.rename(
            columns={'shortName_pc': 'Company', 'marketCap_pc': 'Mkt. Cap', 'regularMarketPrice_pc': 'Price',
                     'regularMarketChangePercent_pc': 'Percent Change', 'regularMarketVolume_pc': 'Volume'})
        cols = [i for i in df_pcs.columns if i not in ["Company"]]
        df_pcs[cols] = df_pcs[cols].apply(pd.to_numeric, errors='ignore', downcast='float')
        df_pcs['Percent Change'] = df_pcs['Percent Change'].apply('{:.2%}'.format)
        df_pcs = df_pcs[['Company', 'Mkt. Cap', 'Price', 'Percent Change', 'Volume']]
        df_pcs['Price'] = df_pcs['Price'].apply(lambda x: round(x, 2))
        df_pcs['Mkt. Cap'] = df_pcs['Mkt. Cap'].apply(lambda x: pd.to_numeric(x))
        df_pcs['Volume'] = df_pcs['Volume'].astype(np.float64)

        try:
            conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
            cur = conn.cursor()
            values = (
            symbol, df_pcs.loc[symbol, 'Company'], df_pcs.loc[symbol, 'Price'], df_pcs.loc[symbol, 'Mkt. Cap'],
            df_pcs.loc[symbol, 'Volume'], df_pcs.loc[symbol, 'Percent Change'])
            cur.execute("""
            INSERT INTO biotech(symbol,'Company',Price,[Mkt. Cap],Volume,[Percent Change]) 
            VALUES(?,?,?,?,?,?)
            ON CONFLICT(symbol) DO UPDATE SET Company=excluded.Company, Price=excluded.Price,[Mkt. Cap]=excluded.`Mkt. Cap`,Volume=excluded.Volume,[Percent Change]=excluded.`Percent Change`""",
                        values
                        )
            conn.commit()
            cur.close()
        except sqlite3.Error as error:
            print("Failed to add pcs", error)
        finally:
            if (conn):
                conn.close()

        return (df_pcs)
    except Exception as e:
        print(e)
        pass


# -------------------------------------------------------

def bs(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_bs1 = ticker.balance_sheet("q")
    df_bs2 = df_bs1[df_bs1.periodType != 'TTM']
    df_bs3 = df_bs2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
    df_bs4 = df_bs3.add_suffix('_bs')
    return (df_bs4)


def bs1(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_bs1 = ticker.balance_sheet("q")
    # Full year from today
    df_bs2 = df_bs1[df_bs1.periodType != 'TTM']
    df_bs3 = df_bs2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
    df_bs4 = df_bs3.add_suffix('_bs')
    df_bs1 = df_bs4.groupby('symbol').first()
    return (df_bs1)


def bss(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        df_bs1 = ticker.balance_sheet("q")
        if str(df_bs1) == str("Balance Sheet data unavailable for " + symbol):
            print("Balance Sheet data unavailable for " + symbol)
        else:
            df_bs2 = df_bs1[df_bs1.periodType != 'TTM']
            if str(df_bs2['asOfDate'].count()) == '0':
                print('Only TTM Balance Sheet Statement available for ' + symbol + ', with last report as of ' + str(
                    df_bs1['asOfDate'][0]))
            else:
                df_bs3 = df_bs2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
                df_bs4 = df_bs3.add_suffix('_bs')
                df_bss = df_bs4[['asOfDate_bs', 'CashCashEquivalentsAndShortTermInvestments_bs', 'TotalAssets_bs',
                                 'TotalLiabilitiesNetMinorityInterest_bs', 'TotalEquityGrossMinorityInterest_bs']]
                df_bss.columns = ['Date', 'Cash/Short Term Inv.', 'Tot.Assets', 'Tot.Liabilities', 'Tot.Equity']

                try:
                    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
                    cur = conn.cursor()
                    values = (
                    symbol, df_bss.loc[symbol, 'Date'][0].date(), df_bss.loc[symbol, 'Cash/Short Term Inv.'][0],
                    df_bss.loc[symbol, 'Tot.Assets'][0], df_bss.loc[symbol, 'Tot.Liabilities'][0],
                    df_bss.loc[symbol, 'Tot.Equity'][0])
                    cur.execute("""
                    INSERT INTO biotech(symbol,'Date_BS',[Cash/Short Term Inv.],[Tot.Assets],[Tot.Liabilities],[Tot.Equity]) 
                    VALUES(?,?,?,?,?,?)
                    ON CONFLICT(symbol) DO UPDATE SET [Date_BS]=excluded.Date_BS, [Cash/Short Term Inv.]=excluded.`Cash/Short Term Inv.`,[Tot.Assets]=excluded.`Tot.Assets`,[Tot.Liabilities]=excluded.`Tot.Liabilities`,[Tot.Equity]=excluded.`Tot.Equity`""",
                                values
                                )
                    conn.commit()
                    cur.close()
                except sqlite3.Error as error:
                    print("Failed to add bss", error)
                finally:
                    if (conn):
                        conn.close()

                return (df_bss)
    except Exception as e:
        print(e)
        pass


def bss1(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_bs1 = ticker.balance_sheet("q")
    df_bs2 = df_bs1[df_bs1.periodType != 'TTM']
    df_bs3 = df_bs2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
    df_bs4 = df_bs3.add_suffix('_bs')
    df_bs1 = df_bs4.groupby('symbol').first()
    df_bss1 = df_bs1[['asOfDate_bs', 'CashCashEquivalentsAndShortTermInvestments_bs', 'TotalAssets_bs',
                      'TotalLiabilitiesNetMinorityInterest_bs', 'TotalEquityGrossMinorityInterest_bs']]
    df_bss1.columns = ['Date', 'Cash/Short Term Inv.', 'Tot.Assets', 'Tot.Liabilities', 'Tot.Equity']
    return (df_bss1)


# -------------------------------------------------------


def fs(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_is1 = ticker.income_statement("q")
    df_is2 = df_is1[df_is1.periodType != 'TTM']
    df_is3 = df_is2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
    df_is4 = df_is3.add_suffix('_is')
    return (df_is4)


def fs1(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_is1 = ticker.income_statement("q")
    df_is2 = df_is1[df_is1.periodType != 'TTM']
    df_is3 = df_is2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
    df_is4 = df_is3.add_suffix('_is')
    df_is1 = df_is4.groupby('symbol').first()
    return (df_is1)


def fss(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        df_is1 = ticker.income_statement("q")
        if str(df_is1) == str("Income Statement data unavailable for " + symbol):
            print("Income Statement data unavailable for " + symbol)
        else:
            df_is2 = df_is1[df_is1.periodType != 'TTM']
            if str(df_is2['asOfDate'].count()) == '0':
                print('Only TTM Income Statement available for ' + symbol + ', with last report as of ' + str(
                    df_is1['asOfDate'][0]))
            else:
                df_is3 = df_is2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
                df_is4 = df_is3.add_suffix('_is')
                df_iss = df_is4[['asOfDate_is', 'TotalRevenue_is', 'NetIncome_is']]
                df_iss.columns = ['Date', 'Tot.Revenue', 'Net Income']

                try:
                    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
                    cur = conn.cursor()
                    values = (symbol, df_iss.loc[symbol, 'Date'][0].date(), df_iss.loc[symbol, 'Tot.Revenue'][0],
                              df_iss.loc[symbol, 'Net Income'][0])
                    cur.execute("""
                    INSERT INTO biotech(symbol,'Date_FS',[Tot.Revenue],[Net Income]) 
                    VALUES(?,?,?,?)
                    ON CONFLICT(symbol) DO UPDATE SET [Date_FS]=excluded.Date_FS,[Tot.Revenue]=excluded.`Tot.Revenue`,[Net Income]=excluded.`Net Income`""",
                                values
                                )
                    conn.commit()
                    cur.close()
                except sqlite3.Error as error:
                    print("Failed to add fss", error)
                finally:
                    if (conn):
                        conn.close()
                return (df_iss)

    except Exception as e:
        print(e)
        pass


def fss1(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_is1 = ticker.income_statement("q")
    df_is2 = df_is1[df_is1.periodType != 'TTM']
    df_is3 = df_is2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
    df_is4 = df_is3.add_suffix('_is')
    df_is1 = df_is4.groupby('symbol').first()
    df_iss1 = df_is1[['asOfDate_is', 'TotalRevenue_is', 'NetIncome_is']]
    df_iss1.columns = ['Date', 'Tot.Revenue', 'Net Income']
    return (df_iss1)


# -------------------------------------------------------


def cf(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_cf1 = ticker.cash_flow("q")
    df_cf2 = df_cf1[df_cf1.periodType != 'TTM']
    df_cf3 = df_cf2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
    df_cf4 = df_cf3.add_suffix('_cf')
    return (df_cf4)


def cf1(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_cf1 = ticker.cash_flow("q")
    df_cf2 = df_cf1[df_cf1.periodType != 'TTM']
    df_cf3 = df_cf2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
    df_cf4 = df_cf3.add_suffix('_cf')
    df_cf1 = df_cf4.groupby('symbol').first()
    return (df_cf1)


def cfs(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        df_cf1 = ticker.cash_flow("q")
        if str(df_cf1) == str("Cash Flow data unavailable for " + symbol):
            print("Cash Flow data unavailable for " + symbol)
        else:
            df_cf2 = df_cf1[df_cf1.periodType != 'TTM']
            if str(df_cf2['asOfDate'].count()) == '0':
                print('Only TTM Cash Flow available for ' + symbol + ', with last report as of ' + str(
                    df_cf1['asOfDate'][0]))
            else:
                df_cf3 = df_cf2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
                df_cf4 = df_cf3.add_suffix('_cf')
                df_cfs = df_cf4[['asOfDate_cf', 'FreeCashFlow_cf']]
                df_cfs.columns = ['Date', 'Free Cash Flow']

                try:
                    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
                    cur = conn.cursor()
                    values = (symbol, df_cfs.loc[symbol, 'Date'][0].date(), df_cfs.loc[symbol, 'Free Cash Flow'][0])
                    cur.execute("""
                    INSERT INTO biotech(symbol,'Date_CF',[Free Cash Flow]) 
                    VALUES(?,?,?)
                    ON CONFLICT(symbol) DO UPDATE SET [Date_CF]=excluded.Date_CF,[Free Cash Flow]=excluded.`Free Cash Flow`""",
                                values
                                )
                    conn.commit()
                    cur.close()
                except sqlite3.Error as error:
                    print("Failed to add cfs", error)
                finally:
                    if (conn):
                        conn.close()
                return (df_cfs)
    except Exception as e:
        print(e)
        pass


def cfs1(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_cf1 = ticker.cash_flow("q")
    df_cf2 = df_cf1[df_cf1.periodType != 'TTM']
    df_cf3 = df_cf2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
    df_cf4 = df_cf3.add_suffix('_cf')
    df_cf1 = df_cf4.groupby('symbol').first()
    df_cfs1 = df_cf1[['asOfDate_cf', 'FreeCashFlow_cf']]
    df_cfs1.columns = ['Date', 'Free Cash Flow']
    return (df_cfs1)


# -------------------------------------------------------
def cash(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    pd.options.mode.chained_assignment = None
    try:
        df_bs1 = ticker.balance_sheet("q")
        if str(df_bs1) == str("Balance Sheet data unavailable for " + symbol):
            print("Cash Burn can not be calculated for " + symbol)
        else:
            df_bs2 = df_bs1[df_bs1.periodType != 'TTM']
            if str(df_bs2['asOfDate'].count()) == '0':
                print("Cash Burn can not be calculated for " + symbol)
            else:
                df_bs3 = df_bs2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
                df_bs4 = df_bs3.add_suffix('_bs')
                df_bs1 = df_bs4.groupby('symbol').first()
                df_bss1 = df_bs1[['asOfDate_bs', 'CashCashEquivalentsAndShortTermInvestments_bs', 'TotalAssets_bs',
                                  'TotalLiabilitiesNetMinorityInterest_bs', 'TotalEquityGrossMinorityInterest_bs']]
                df_bss1.columns = ['Date', 'Cash/Short Term Inv.', 'Tot.Assets', 'Tot.Liabilities', 'Tot.Equity']

                df_cf1 = ticker.cash_flow("q")
                if str(df_cf1) == str("Cash Flow data unavailable for " + symbol):
                    print("Cash Burn can not be calculated for " + symbol)
                else:
                    df_cf2 = df_cf1[df_cf1.periodType != 'TTM']
                    if str(df_cf2['asOfDate'].count()) == '0':
                        print("Cash Burn can not be calculated for " + symbol)
                    else:
                        df_cf3 = df_cf2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
                        df_cf4 = df_cf3.add_suffix('_cf')
                        df_cf1 = df_cf4.groupby('symbol').first()
                        df_cfs1 = df_cf1[['asOfDate_cf', 'FreeCashFlow_cf']]
                        df_cfs1.columns = ['Date', 'Free Cash Flow']

                        df_is1 = ticker.income_statement("q")
                        if str(df_is1) == str("Income Statement data unavailable for " + symbol):
                            print("Cash Burn can not be calculated for " + symbol)
                        else:
                            df_is2 = df_is1[df_is1.periodType != 'TTM']
                            if str(df_is2['asOfDate'].count()) == '0':
                                print("Cash Burn can not be calculated for " + symbol)
                            else:
                                df_is3 = df_is2.sort_values(by=['symbol', 'asOfDate'], ascending=[True, False])
                                df_is4 = df_is3.add_suffix('_is')
                                df_is1 = df_is4.groupby('symbol').first()
                                df_iss1 = df_is1[['asOfDate_is', 'TotalRevenue_is', 'NetIncome_is']]
                                df_iss1.columns = ['Date', 'Tot.Revenue', 'Net Income']

                                if df_bss1.iloc[0]['Date'] == df_iss1.iloc[0]['Date'] == df_cfs1.iloc[0]['Date']:
                                    df_all1 = df_bss1.merge(df_iss1, left_index=True, right_index=True).merge(df_cfs1,
                                                                                                              left_index=True,
                                                                                                              right_index=True)
                                    df_all1 = df_all1.sort_index()
                                    df_cash_burn1 = df_all1[['Date', 'Free Cash Flow', 'Cash/Short Term Inv.']]
                                    date1 = date.today()
                                    date2 = pd.to_datetime(df_cash_burn1['Date'].iloc[0])
                                    date2 = date2.date()
                                    days_since_last_quarter = (date1 - date2).days

                                    df_cash_burn1 = df_all1[['Date', 'Free Cash Flow', 'Cash/Short Term Inv.']]
                                    df_cash_burn1['CashBurnPerDay'] = (df_cash_burn1['Free Cash Flow'] / 91).apply(
                                        pd.to_numeric, errors='coerce').round(1)
                                    df_cash_burn1['CashLeftToday'] = df_cash_burn1['Cash/Short Term Inv.'] + \
                                                                     df_cash_burn1[
                                                                         'CashBurnPerDay'] * days_since_last_quarter
                                    decimals = 1
                                    df_cash_burn1['CashLeftToday'] = df_cash_burn1['CashLeftToday'].apply(
                                        lambda x: round(x, decimals))
                                    df_cash_burn1['Months to 0$'] = (df_cash_burn1['CashLeftToday'] / (
                                                -df_cash_burn1['CashBurnPerDay'] * 30.42)).round(1)
                                    df_cash_burn1

                                    try:
                                        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
                                        cur = conn.cursor()
                                        values = (symbol, df_cash_burn1.loc[symbol, 'Date'].date(),
                                                  df_cash_burn1.loc[symbol, 'CashBurnPerDay'],
                                                  df_cash_burn1.loc[symbol, 'CashLeftToday'],
                                                  df_cash_burn1.loc[symbol, 'Months to 0$'])
                                        cur.execute("""
                                        INSERT INTO biotech(symbol,'Date_CB',CashBurnPerDay,CashLeftToday,[Months to 0$]) 
                                        VALUES(?,?,?,?,?)
                                        ON CONFLICT(symbol) DO UPDATE SET [Date_CB]=excluded.Date_CB,CashBurnPerDay=excluded.CashBurnPerDay,CashLeftToday=excluded.CashLeftToday,[Months to 0$]=excluded.`Months to 0$`""",
                                                    values
                                                    )
                                        conn.commit()
                                        cur.close()
                                    except sqlite3.Error as error:
                                        print("Failed to add cash", error)
                                    finally:
                                        if (conn):
                                            conn.close()

                                    return (df_cash_burn1)

                                else:
                                    print(
                                        'Dates for Balance Sheet, Financial Statement and Cash Flow are not identical to calculate cash burn')
    except Exception as e:
        print(e)
        pass


# -------------------------------------------------------

def mh(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_mh1 = pd.DataFrame.from_dict(ticker.major_holders, orient='index')
    df_mh2 = df_mh1.add_suffix('_mh')
    return (df_mh2)


def mhs(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        df_mh1 = pd.DataFrame.from_dict(ticker.major_holders, orient='index')
        df_mh2 = df_mh1.add_suffix('_mh')
        mh_columns = ['insidersPercentHeld_mh', 'institutionsPercentHeld_mh', 'institutionsFloatPercentHeld_mh',
                      'institutionsCount_mh']
        df_mhs = df_mh2[df_mh2.columns.intersection(mh_columns)]
        for col in mh_columns:
            if col not in df_mhs.columns:
                df_mhs[col] = np.nan
        df_mhs = df_mhs.rename(
            columns={'insidersPercentHeld_mh': 'Insiders % Held', 'institutionsPercentHeld_mh': 'Institutions % Held',
                     'institutionsFloatPercentHeld_mh': 'Institutions Float % Held',
                     'institutionsCount_mh': 'Institutions Count'})
        cols2 = [i for i in df_mhs.columns]
        df_mhs[cols2] = df_mhs[cols2].apply(pd.to_numeric, errors='ignore', downcast='float')
        df_mhs["Insiders % Held"] = df_mhs["Insiders % Held"].apply('{:.2%}'.format)
        df_mhs["Institutions % Held"] = df_mhs["Institutions % Held"].apply('{:.2%}'.format)
        df_mhs["Institutions Float % Held"] = df_mhs["Institutions Float % Held"].apply('{:.2%}'.format)
        df_mhs['Institutions Count'] = df_mhs['Institutions Count'].astype(np.float64)

        try:
            conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
            cur = conn.cursor()
            values = (symbol, df_mhs.loc[symbol, 'Insiders % Held'], df_mhs.loc[symbol, 'Institutions % Held'],
                      df_mhs.loc[symbol, 'Institutions Float % Held'], df_mhs.loc[symbol, 'Institutions Count'])
            cur.execute("""
            INSERT INTO biotech(symbol,[Insiders % Held],[Institutions % Held],[Institutions Float % Held],[Institutions Count]) 
            VALUES(?,?,?,?,?)
            ON CONFLICT(symbol) DO UPDATE SET [Insiders % Held]=excluded.`Insiders % Held`,[Institutions % Held]=excluded.`Institutions % Held`,[Institutions Float % Held]=excluded.`Institutions Float % Held`,[Institutions Count]=excluded.`Institutions Count`""",
                        values
                        )
            conn.commit()
            cur.close()
        except sqlite3.Error as error:
            print("Failed to add mhs", error)
        finally:
            if (conn):
                conn.close()

        df_mhs.style.format(
            {'Insiders % Held': "{:.2%}", 'Institutions % Held': '{:.2%}', 'Institutions Float % Held': '{:.2%}',
             'Institutions Count': '{:.0f}'})
        return (df_mhs)
    except Exception as e:
        print(e)
        pass


# -------------------------------------------------------

def ks(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    df_ks1 = pd.DataFrame.from_dict(ticker.key_stats, orient='index')
    df_ks2 = df_ks1.add_suffix('_ks')
    return (df_ks2)


def kss_new(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        df_ks1 = pd.DataFrame.from_dict(ticker.key_stats, orient='index')
        df_ks2 = df_ks1.add_suffix('_ks')
        ks_columns = ['enterpriseValue_ks', 'sharesOutstanding_ks', 'floatShares_ks', 'dateShortInterest_ks',
                      'sharesShort_ks', 'shortRatio_ks', 'shortPercentOfFloat_ks', 'sharesShortPreviousMonthDate_ks',
                      'sharesShortPriorMonth_ks']
        df_kss = df_ks2[df_ks2.columns.intersection(ks_columns)].copy()
        for col in ks_columns:
            if col not in df_kss.columns:
                df_kss[col] = np.nan
        df_kss = df_kss.rename(
            columns={'enterpriseValue_ks': 'EV', 'sharesOutstanding_ks': 'Shares Outst.', 'floatShares_ks': 'Float',
                     'dateShortInterest_ks': 'Date of Short Report', 'sharesShort_ks': 'Shares Short',
                     'shortRatio_ks': 'Short Ratio', 'shortPercentOfFloat_ks': 'Short % of Float',
                     'sharesShortPreviousMonthDate_ks': 'Previous Date of Report',
                     'sharesShortPriorMonth_ks': 'Prior Shares Short'})
        df_kss.loc[:, 'Short % of Float'] = df_kss.loc[:, 'Short % of Float'].apply('{:.2%}'.format)

        df_kss_new = df_kss[['Date of Short Report', 'EV', 'Shares Outst.', 'Float', 'Shares Short', 'Short % of Float',
                             'Short Ratio']].copy()

        df_kss_new.loc[symbol, 'EV'] = df_kss_new.loc[symbol, 'EV'].astype(np.float64)
        df_kss_new.loc[symbol, 'Shares Outst.'] = df_kss_new.loc[symbol, 'Shares Outst.'].astype(np.float64)
        df_kss_new.loc[symbol, 'Float'] = df_kss_new.loc[symbol, 'Float'].astype(np.float64)
        df_kss_new.loc[symbol, 'Shares Short'] = df_kss_new.loc[symbol, 'Shares Short'].astype(np.float64)

        if df_kss_new['Date of Short Report'].isnull().values.any() == True:
            try:
                conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
                cur = conn.cursor()
                values = (symbol, df_kss_new.loc[symbol, 'Date of Short Report'], df_kss_new.loc[symbol, 'EV'],
                          df_kss_new.loc[symbol, 'Shares Outst.'], df_kss_new.loc[symbol, 'Float'],
                          df_kss_new.loc[symbol, 'Shares Short'], df_kss_new.loc[symbol, 'Short % of Float'],
                          df_kss_new.loc[symbol, 'Short Ratio'])
                cur.execute("""
                INSERT INTO biotech(symbol,[Date of Short Report],EV,[Shares Outst.],Float,[Shares Short],[Short % of Float],[Short Ratio]) 
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(symbol) DO UPDATE SET [Date of Short Report]=excluded.`Date of Short Report`,EV=excluded.EV, [Shares Outst.]=excluded.`Shares Outst.`,Float=excluded.Float,[Shares Short]=excluded.`Shares Short`,[Short % of Float]=excluded.`Short % of Float`,[Short Ratio]=excluded.`Short Ratio`""",
                            values
                            )
                conn.commit()
                cur.close()
            except sqlite3.Error as error:
                print("Failed to add kss_new", error)
            finally:
                if (conn):
                    conn.close()
            return (df_kss_new)

        else:
            df_kss_new.loc[:, 'Date of Short Report'] = pd.to_datetime(df_kss_new.loc[:, 'Date of Short Report'])
            try:
                conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
                cur = conn.cursor()
                values = (symbol, df_kss_new.loc[symbol, 'Date of Short Report'].date(), df_kss_new.loc[symbol, 'EV'],
                          df_kss_new.loc[symbol, 'Shares Outst.'], df_kss_new.loc[symbol, 'Float'],
                          df_kss_new.loc[symbol, 'Shares Short'], df_kss_new.loc[symbol, 'Short % of Float'],
                          df_kss_new.loc[symbol, 'Short Ratio'])
                cur.execute("""
                INSERT INTO biotech(symbol,[Date of Short Report],EV,[Shares Outst.],Float,[Shares Short],[Short % of Float],[Short Ratio]) 
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(symbol) DO UPDATE SET [Date of Short Report]=excluded.`Date of Short Report`,EV=excluded.EV, [Shares Outst.]=excluded.`Shares Outst.`,Float=excluded.Float,[Shares Short]=excluded.`Shares Short`,[Short % of Float]=excluded.`Short % of Float`,[Short Ratio]=excluded.`Short Ratio`""",
                            values
                            )
                conn.commit()
                cur.close()
            except sqlite3.Error as error:
                print("Failed to add kss_new", error)
            finally:
                if (conn):
                    conn.close()
            return (df_kss_new)

    except Exception as e:
        print(e)
        pass


def kss_old(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        df_ks1 = pd.DataFrame.from_dict(ticker.key_stats, orient='index')
        df_ks2 = df_ks1.add_suffix('_ks')
        ks_columns = ['enterpriseValue_ks', 'sharesOutstanding_ks', 'floatShares_ks', 'dateShortInterest_ks',
                      'sharesShort_ks', 'shortRatio_ks', 'shortPercentOfFloat_ks', 'sharesShortPreviousMonthDate_ks',
                      'sharesShortPriorMonth_ks']
        df_kss = df_ks2[df_ks2.columns.intersection(ks_columns)].copy()
        for col in ks_columns:
            if col not in df_kss.columns:
                df_kss[col] = np.nan
        df_kss = df_kss.rename(
            columns={'enterpriseValue_ks': 'EV', 'sharesOutstanding_ks': 'Shares Outst.', 'floatShares_ks': 'Float',
                     'dateShortInterest_ks': 'Date of Short Report', 'sharesShort_ks': 'Shares Short',
                     'shortRatio_ks': 'Short Ratio', 'shortPercentOfFloat_ks': 'Short % of Float',
                     'sharesShortPreviousMonthDate_ks': 'Previous Date of Report',
                     'sharesShortPriorMonth_ks': 'Prior Shares Short'})
        df_kss['Short % of Float'] = df_kss['Short % of Float'].apply('{:.2%}'.format)

        df_kss_old = df_kss[['Previous Date of Report', 'Prior Shares Short']].copy()
        df_kss_old.loc[symbol, 'Prior Shares Short'] = df_kss_old.loc[symbol, 'Prior Shares Short'].astype(np.float64)

        if df_kss_old['Previous Date of Report'].isnull().values.any() == True:
            try:
                conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
                cur = conn.cursor()
                values = (
                symbol, df_kss_old.loc[symbol, 'Previous Date of Report'], df_kss_old.loc[symbol, 'Prior Shares Short'])
                cur.execute("""
                INSERT INTO biotech(symbol,[Previous Date of Report],[Prior Shares Short]) 
                VALUES(?,?,?)
                ON CONFLICT(symbol) DO UPDATE SET [Previous Date of Report]=excluded.`Previous Date of Report`,[Prior Shares Short]=excluded.`Prior Shares Short` """,
                            values
                            )
                conn.commit()
                cur.close()
            except sqlite3.Error as error:
                print("Failed to add kss_old", error)
            finally:
                if (conn):
                    conn.close()
            return (df_kss_old)
        else:
            df_kss_old.loc[:, 'Previous Date of Report'] = pd.to_datetime(df_kss_old.loc[:, 'Previous Date of Report'])
            try:
                conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
                cur = conn.cursor()
                values = (symbol, df_kss_old.loc[symbol, 'Previous Date of Report'].date(),
                          df_kss_old.loc[symbol, 'Prior Shares Short'])
                cur.execute("""
                INSERT INTO biotech(symbol,[Previous Date of Report],[Prior Shares Short]) 
                VALUES(?,?,?)
                ON CONFLICT(symbol) DO UPDATE SET [Previous Date of Report]=excluded.`Previous Date of Report`,[Prior Shares Short]=excluded.`Prior Shares Short` """,
                            values
                            )
                conn.commit()
                cur.close()
            except sqlite3.Error as error:
                print("Failed to add kss_old", error)
            finally:
                if (conn):
                    conn.close()
            return (df_kss_old)

    except Exception as e:
        print(e)
        pass


# -------------------------------------------------------
def institutions(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        df_inst = ticker.institution_ownership
        if df_inst.empty:
            print('No Institutional Holdings data available for ' + symbol)
        else:
            df_inst = df_inst.reset_index(level='row', drop=True)
            df_inst['position'] = df_inst['position'].apply('{:,}'.format)
            df_inst['value'] = df_inst['value'].apply('{:,}'.format)
            df_inst['pctHeld'] = df_inst['pctHeld'].apply('{:.2%}'.format)
            return (df_inst)
    except Exception as e:
        print(e)
        pass

    # -------------------------------------------------------


def salaries(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        asset_profiles = ticker.asset_profile
        df_pay = pd.DataFrame(asset_profiles[symbol]['companyOfficers'])
        df_pay['symbol'] = symbol

        df_pay = df_pay.drop(['maxAge'], axis=1)
        df_pay = df_pay.set_index('symbol')
        df_pay['totalPay'] = df_pay['totalPay'].apply('{:,}'.format)
        df_pay['fiscalYear'] = df_pay['fiscalYear'].fillna(0).astype(int)
        df_pay['unexercisedValue'] = df_pay['unexercisedValue'].apply('{:,}'.format)
        df_pay['exercisedValue'] = df_pay['exercisedValue'].apply('{:,}'.format)
        return (df_pay)
    except Exception as e:
        print(e)
        pass


# -------------------------------------------------------
def sec(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')

    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
        cur = conn.cursor()
        sql_select_query = "select CIK from biotech where symbol = ?"
        cur.execute(sql_select_query, (symbol,))
        cik = str(cur.fetchone()[0])
        conn.commit()
        cur.close()

    except sqlite3.Error as error:
        print("Failed to select symbol from biotech", error)
    finally:
        if (conn):
            conn.close()

    if cik == 'None':
        ticker = Ticker(symbols, asynchronous=True)
        df_secfilings = ticker.sec_filings
        if type(df_secfilings) is dict:
            print('No SEC Filings data available')
        else:
            df_secfilings = df_secfilings.drop(['maxAge', 'epochDate'], axis=1)
            df_secfilings = df_secfilings.reset_index(level='row', drop=True)
            df_secfilings['edgarUrl'] = df_secfilings['edgarUrl'].apply(
                lambda x: '<a href="{0}" target="_blank">{0}</a>'.format(x))
            display(HTML(df_secfilings.to_html(escape=False)))

    else:
        # Obtain HTML for search page
        base_url = "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={}&count=100"  # &type={}&dateb={}"
        edgar_resp = requests.get(base_url.format(cik))
        edgar_str = edgar_resp.text

        # Find the document link
        doc_link = ''
        soup = BeautifulSoup(edgar_str, 'html.parser')
        table_tag = soup.find('table', class_='tableFile2')
        rows = table_tag.find_all('tr')

        # Table of all recent listings
        table = soup.find_all('table')
        filings_df = pd.read_html(str(table))[2]
        filings_df['URL'] = ''

        for index, row in zip(filings_df.index.to_list(), rows[1:]):

            cells = row.find_all('td')
            if len(cells) > 3:
                # #         if '2020' in cells[3].text:

                try:
                    doc_link = 'https://www.sec.gov' + cells[1].a['href']
                    filings_df.loc[index, 'URL'] = doc_link
                except:
                    continue
        filings_df = filings_df.groupby('Filings').head(2).reset_index(drop=True)
        filings_df['URL'] = filings_df['URL'].apply(lambda x: '<a href="{0}" target="_blank">{0}</a>'.format(x))
        display(HTML(filings_df.to_html(escape=False)))


# -------------------------------------------------------
def corporate_events(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    try:
        corp_events_df = ticker.corporate_events
        corp_events_df = corp_events_df.reset_index(level='date')
        corp_events_df = corp_events_df.sort_values('date', ascending=False)
        corp_events_df = corp_events_df.drop(['significance'], axis=1)
        return (corp_events_df)
    except Exception as e:
        print(e)
        pass


# -------------------------------------------------------
def news(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    ticker = Ticker(symbols, asynchronous=True)
    dict = ticker.news(12)
    news_list = list(dict.values())
    if news_list[0] == 'No data found':
        print("No news found for " + symbol)
    else:
        news_list = list(dict.values())
        flattened_news_list = [val for sublist in news_list for val in sublist]
        try:
            for sub in flattened_news_list:
                print(sub['title'])
                # print(sub['summary'])
                print(sub['provider_name'])
                print(sub['url'])
                print()
        except Exception as e:
            print(e)
            pass


# -------------------------------------------------------
def dilution(symbol):
    symbol = symbol.upper()

    import json

    dil_columns = ['filingType',
                   'date',
                   'effective',
                   'sharesOffered',
                   'aggregateAmount',
                   'remaining',
                   'mvphs',
                   'float',
                   'ib6',
                   'price',
                   'resaleAggregate',
                   'resaleShares',
                   'isHybrid',
                   'warrants',
                   'placementAgent',
                   'subjectToCompletion',
                   'isAmendment',
                   'amendmentType',
                   'AmountSold',
                   'AtmIncreased',
                   'addToRemaining',
                   'markToOpen',
                   'hasATM',
                   'hasResale',
                   'explanatoryNote',
                   'hiddenATM',
                   'foreign',
                   'isIPO',
                   'IsLatestPreliminary',
                   'IsSupplement',
                   'offeringInfo',
                   'error',
                   'fileID',
                   'documentUrl',
                   'fileUrl'
                   ]

    url = "https://api.filingspro.com/sec?ticker=" + symbol
    resp = requests.get(url)
    text = resp.text

    d = json.loads(text)
    if not d['shelfs']:
        print('No dilution data available')
    else:
        # rows list initialization 
        dil_rows = []

        # appending rows 
        for data in d["shelfs"]:
            data_row = data['filings']
            time = data['effective']

            for row in data_row:
                row['effective'] = time
                dil_rows.append(row)

                # using data frame
        dil_df = pd.DataFrame(dil_rows)

        dil_df.columns = pd.CategoricalIndex(dil_df.columns, categories=dil_columns, ordered=True)
        dil_df = dil_df.sort_values(by=['date'], ascending=False)
        dil_df = dil_df.sort_index(axis=1)
        dil_df = dil_df.reset_index(drop=True)
        #     dil_df = df[df.columns.intersection(dil_columns)]
        dil_df = dil_df[dil_columns]
        dil_df['date'] = dil_df['date'].astype('datetime64[ns]')
        dil_df['effective'] = dil_df['effective'].astype('datetime64[ns]')
        # df['effective'] = df['effective'].dt.date
        dil_df = dil_df.loc[:, ~(dil_df.astype(str) == 'False').all()]
        dil_df = dil_df.loc[:, ~(dil_df.astype(str) == '').all()]

        #     get a list of names
        fileID_list = dil_df['fileID'].unique()
        for i in fileID_list:
            sub_df = dil_df.loc[dil_df.fileID == i]
            sub_df = sub_df.loc[:, ~(sub_df.astype(str) == 'False').all()]
            sub_df = sub_df.loc[:, ~(sub_df.astype(str) == '').all()]
            try:
                sub_df = sub_df.sort_values(by=['date'], ascending=False)
            except Exception as e:
                pass
            sub_df = sub_df.reset_index(drop=True)
            sub_df['fileUrl'] = sub_df['fileUrl'].apply(lambda x: '<a href="{0}" target="_blank">{0}</a>'.format(x))
            sub_df['documentUrl'] = sub_df['documentUrl'].apply(
                lambda x: '<a href="{0}" target="_blank">{0}</a>'.format(x))
            # with custom_formatting():
            display(HTML(sub_df.to_html(escape=False)))


# -------------------------------------------------------
def links(symbol):
    print('USEFUL LINKS')
    print('')
    symbols = symbol.split(',')
    # ticker = Ticker(symbols, asynchronous=True)
    for b in symbols:
        print("Company Website")
        web(symbol)
        print("Insider trading:")
        url1 = 'https://www.marketwatch.com/investing/stock/' + str(b) + '/insideractions'
        print(url1)
        url2 = 'https://www.nasdaq.com/market-activity/stocks/' + str(b) + '/insider-activity'
        print(url2)
        print("Reports:")
        url3 = "https://www.sec.gov/cgi-bin/browse-edgar?CIK=" + str(b) + "&owner=exclude&action=getcompany&Find=Search"
        print(url3)
        print("Catalysts:")
        url4 = "https://www.biopharmcatalyst.com/company/" + str(b)
        print(url4)
        print("Transcripts:")
        url5 = "https://seekingalpha.com/symbol/" + str(b) + "/earnings/transcripts"
        print(url5)


# -------------------------------------------------------
def stock_info(symbol):
    print('')
    string = "Stock Report"
    new_string = (symbol + " - " + string).center(70)
    print(new_string)
    print('')
    print(web(symbol))
    print('')
    summary(symbol)
    print('')
    print('STOCK INFO:')
    trend(symbol)
    print(pctchange(symbol))
    print(pcs(symbol))
    print(sps(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('EV AND SHARES SHORT:')
    print(kss_new(symbol))
    print(kss_old(symbol))


def finances(symbol):
    print('-' * 60)
    print('-' * 60)
    print('')
    print('DILUTION:')
    dilution(symbol)
    print('-' * 60)
    print('-' * 60)
    print('')
    print('BALANCE SHEET:')
    print(bss(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('FINANCIAL STATEMENT:')
    print(fss(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('CASH FLOWS:')
    print(cfs(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('CASH BURN:')
    print(cash(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('SALARIES:')
    print(salaries(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('MAJOR HOLDERS:')
    try:
        print(mhs(symbol))
    except Exception as e:
        print(e)
        pass


# -------------------------------------------------------

# df_all = df_bss.join(df_iss, on="Date", how='right')

# def all_s1():
#     df_all_s1 = df_bss1.merge(df_iss1, left_index=True, right_index=True).merge(df_cfs1, left_index=True, right_index=True).merge(df_kss, left_index=True, right_index=True).merge(df_mhs, left_index=True, right_index=True)
#     df_all_s1=df_all_s1.sort_index()
#     return (df_all_s1)


# Gets the list of new ORphan Drug Designations from the FDA
def ODD():
    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        df_ODD = pd.read_sql_query("select * from [*ODD_sorted] ORDER BY [Designation Date] DESC;", conn)

    except sqlite3.Error as error:
        print("Failed to select from biotech", error)
    finally:
        if (conn):
            conn.close()
    return df_ODD.head(10)


def nasdaq(symbol):
    from selenium import webdriver
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support import expected_conditions as EC
    import time
    from time import sleep
    from bs4 import BeautifulSoup
    import pandas as pd

    try:
        options = webdriver.ChromeOptions()
        options.add_argument("start-maximized")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        driver = webdriver.Chrome(options=options, executable_path='/Users/ralph/Biotech/chromedriver')
        driver.minimize_window()
        driver.get("https://www.nasdaq.com/market-activity/stocks/" + symbol + "/insider-activity")
        sleep(4)
        driver.find_element_by_id("_evidon-decline-button").click()
        driver.find_element_by_xpath(
            "/html/body/div[2]/div/main/div[2]/div[4]/div[3]/div/div[1]/div/div[1]/div[3]/div[2]/div[2]/div/table/thead/tr/th[3]/button/span[1]").click()
        sleep(1)
        driver.find_element_by_xpath(
            "/html/body/div[2]/div/main/div[2]/div[4]/div[3]/div/div[1]/div/div[1]/div[3]/div[2]/div[2]/div/table/thead/tr/th[3]/button/span[1]").click()
        sleep(1)

        # WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.CSS_SELECTOR, "h1.h1")))
        soup = BeautifulSoup(driver.page_source, 'lxml')
        # Always quit at the end of scrapin

        table = soup.find_all('table')
        driver.quit()

        trades_df = pd.read_html(str(table))[0]
        volume_df = pd.read_html(str(table))[1]
        transactions_df = pd.read_html(str(table))[2]

        display(trades_df)
        display(volume_df)
        display(transactions_df)
    except Exception as e:
        print('No insider transactions found')
        driver.quit()
        pass


def report_hf(hf):
    import sqlite3
    import pandas as pd

    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
        query_string = "select * from hf_" + hf + ";"
        hf_df = pd.read_sql_query(query_string, conn)
        hf_df
    except sqlite3.Error as error:
        print("Failed to access the BiotechDatabase file", error)
    finally:
        if (conn):
            conn.close()

    hf_df['DATE'] = hf_df['DATE'].astype('datetime64[ns]')
    hf_df.sort_values(by=['DATE'], inplace=True, ascending=False)
    # Select the most recent 2 dates in the hedge fund table (i.e most recent 2 quarters reported)
    top_dates = list(hf_df['DATE'].unique()[0:2])
    new_date = top_dates[0]
    old_date = top_dates[1]

    # Select the last 2 quarters holdings
    hf_df = hf_df[hf_df['DATE'].isin(top_dates)]
    hf_df

    holdings_df = hf_df[hf_df['DATE'] == new_date]

    hf_df_new_list = hf_df['CUSIP'][hf_df['DATE'] == new_date].to_list()
    hf_df_old_list = hf_df['CUSIP'][hf_df['DATE'] == old_date].to_list()

    diff = list(set(hf_df_new_list) - set(hf_df_old_list))
    diff

    hf_new_positions_df = hf_df[(hf_df['DATE'] == new_date) & (hf_df['CUSIP'].isin(diff))]
    hf_new_positions_df = hf_new_positions_df.sort_values('VALUE', ascending=False)
    hf_new_positions_df = hf_new_positions_df.reset_index(drop=True)
    hf_new_positions_df

    diff2 = list(set(hf_df_old_list) - set(hf_df_new_list))
    diff2

    hf_closed_positions_df = hf_df[(hf_df['DATE'] == old_date) & (hf_df['CUSIP'].isin(diff2))]
    hf_closed_positions_df = hf_closed_positions_df.sort_values('VALUE', ascending=False)
    hf_closed_positions_df = hf_closed_positions_df.reset_index(drop=True)
    hf_closed_positions_df

    common = list(set(hf_df_new_list).intersection(hf_df_old_list))
    common

    increased_list = []
    for cusip in common:
        df = hf_df[hf_df['CUSIP'] == cusip]
        #     increased_list = []
        try:
            if (df['SHARES'][df['DATE'] == new_date].values.sum() > df['SHARES'][
                df['DATE'] == old_date].values.sum()) == True:
                increased_list.append(cusip)
            else:
                pass
        except Exception as e:
            print(e)
            pass

    hf_increased_positions_df = hf_df[(hf_df['DATE'].isin(top_dates)) & (hf_df['CUSIP'].isin(increased_list))]
    hf_increased_positions_df1 = hf_increased_positions_df[(hf_increased_positions_df['DATE'] == new_date)]
    hf_increased_positions_df2 = hf_increased_positions_df[(hf_increased_positions_df['DATE'] == old_date)]

    for symbol in hf_increased_positions_df1['SYMBOL'].to_list():
        try:
            new_shares = hf_increased_positions_df1.loc[hf_increased_positions_df1['SYMBOL'] == symbol, 'SHARES'].values
            old_shares = hf_increased_positions_df2.loc[hf_increased_positions_df2['SYMBOL'] == symbol, 'SHARES'].values
            pct_change = (new_shares - old_shares) / old_shares
            hf_increased_positions_df1 = hf_increased_positions_df1.copy()
            hf_increased_positions_df1.loc[hf_increased_positions_df1['SYMBOL'] == symbol, 'PCT_CHANGE'] = pct_change
        except Exception as e:
            print(e)
            pass

    hf_increased_positions_df1 = hf_increased_positions_df1.copy()
    hf_increased_positions_df1 = hf_increased_positions_df1.reset_index(drop=True)
    hf_increased_positions_df1['PCT_CHANGE'] = hf_increased_positions_df1['PCT_CHANGE'].apply('{:.2%}'.format)
    hf_increased_positions_df1 = hf_increased_positions_df1.sort_values('VALUE', ascending=False)
    hf_increased_positions_df1

    decreased_list = []
    for cusip in common:
        df = hf_df[hf_df['CUSIP'] == cusip]
        #     decreased_list = []
        try:
            if (df['SHARES'][df['DATE'] == new_date].values.sum() < df['SHARES'][
                df['DATE'] == old_date].values.sum()) == True:
                decreased_list.append(cusip)
            else:
                pass
        except Exception as e:
            print(e)
            pass

    hf_decreased_positions_df = hf_df[(hf_df['DATE'].isin(top_dates)) & (hf_df['CUSIP'].isin(decreased_list))]
    hf_decreased_positions_df1 = hf_decreased_positions_df[(hf_decreased_positions_df['DATE'] == new_date)]
    hf_decreased_positions_df2 = hf_decreased_positions_df[(hf_decreased_positions_df['DATE'] == old_date)]

    for symbol in hf_decreased_positions_df1['SYMBOL'].to_list():
        try:

            new_shares = hf_decreased_positions_df1.loc[hf_decreased_positions_df1['SYMBOL'] == symbol, 'SHARES'].values
            old_shares = hf_decreased_positions_df2.loc[hf_decreased_positions_df2['SYMBOL'] == symbol, 'SHARES'].values
            pct_change = (new_shares - old_shares) / old_shares
            hf_decreased_positions_df1 = hf_decreased_positions_df1.copy()
            hf_decreased_positions_df1.loc[hf_decreased_positions_df1['SYMBOL'] == symbol, 'PCT_CHANGE'] = pct_change
        except Exception as e:
            print(e)
            pass

    hf_decreased_positions_df1 = hf_decreased_positions_df1.copy()
    hf_decreased_positions_df1 = hf_decreased_positions_df1.reset_index(drop=True)
    hf_decreased_positions_df1['PCT_CHANGE'] = hf_decreased_positions_df1['PCT_CHANGE'].apply('{:.2%}'.format)
    hf_decreased_positions_df1 = hf_decreased_positions_df1.sort_values('VALUE', ascending=False)
    hf_decreased_positions_df1

    unchanged_list = []
    for cusip in common:
        df = hf_df[hf_df['CUSIP'] == cusip]
        #     decreased_list = []
        try:
            if (df['SHARES'][df['DATE'] == new_date].values.sum() == df['SHARES'][
                df['DATE'] == old_date].values.sum()) == True:
                unchanged_list.append(cusip)
            else:
                pass
        except Exception as e:
            print(e)
            pass

    hf_unchanged_positions_df = hf_df[(hf_df['DATE'] == old_date) & (hf_df['CUSIP'].isin(unchanged_list))]
    hf_unchanged_positions_df = hf_unchanged_positions_df.sort_values('VALUE', ascending=False)
    hf_unchanged_positions_df = hf_unchanged_positions_df.reset_index(drop=True)
    hf_unchanged_positions_df

    hf_df_new_list = hf_df['CUSIP'][hf_df['DATE'] == new_date].to_list()
    hf_df_old_list = hf_df['CUSIP'][hf_df['DATE'] == old_date].to_list()

    # diff = list(set(hf_df_new_list) - set(hf_df_old_list))
    # diff

    # hf_new_positions_df = hf_df[(hf_df['DATE'] == new_date) & (hf_df['CUSIP'].isin(diff)) ]
    # hf_new_positions_df = hf_new_positions_df.sort_values('VALUE', ascending=False)
    # hf_new_positions_df = hf_new_positions_df.reset_index(drop=True)
    # hf_new_positions_df

    # diff2 = list(set(hf_df_old_list) - set(hf_df_new_list))
    # diff2

    # hf_closed_positions_df = hf_df[(hf_df['DATE'] == old_date) & (hf_df['CUSIP'].isin(diff2)) ]
    # hf_closed_positions_df = hf_closed_positions_df.sort_values('VALUE', ascending=False)
    # hf_closed_positions_df = hf_closed_positions_df.reset_index(drop=True)
    # hf_closed_positions_df

    # common = list(set(hf_df_new_list).intersection(hf_df_old_list))
    # common

    # increased_list = []
    # for cusip in common:
    #     df = hf_df[hf_df['CUSIP']== cusip]
    # #     increased_list = []
    #     try:
    #         if (df['SHARES'][df['DATE']== new_date].values.sum() > df['SHARES'][df['DATE']== old_date].values.sum())==True:
    #             increased_list.append(cusip)
    #         else:
    #               pass
    #     except Exception as e: 
    #         print(e)
    #         pass

    # hf_increased_positions_df = hf_df[(hf_df['DATE']== new_date) & (hf_df['CUSIP'].isin(increased_list)) ]
    # hf_increased_positions_df = hf_increased_positions_df.sort_values('VALUE', ascending=False)
    # hf_increased_positions_df = hf_increased_positions_df.reset_index(drop=True)
    # hf_increased_positions_df

    hf_new_positions_list = sorted(hf_new_positions_df['SYMBOL'].to_list())
    hf_new_positions_list_tweet = ', $'.join(hf_new_positions_list)
    hf_new_positions_list_tweet = "$" + hf_new_positions_list_tweet

    hf_closed_positions_list = sorted(hf_closed_positions_df['SYMBOL'].to_list())
    hf_closed_positions_list_tweet = ', $'.join(hf_closed_positions_list)
    hf_closed_positions_list_tweet = "$" + hf_closed_positions_list_tweet

    hf_increased_positions_list = sorted(hf_increased_positions_df1['SYMBOL'].to_list())
    hf_increased_positions_list_tweet = ', $'.join(hf_increased_positions_list)
    hf_increased_positions_list_tweet = "$" + hf_increased_positions_list_tweet

    hf_decreased_positions_list = sorted(hf_decreased_positions_df1['SYMBOL'].to_list())
    hf_decreased_positions_list_tweet = ', $'.join(hf_decreased_positions_list)
    hf_decreased_positions_list_tweet = "$" + hf_decreased_positions_list_tweet

    hf_unchanged_positions_list = sorted(hf_unchanged_positions_df['SYMBOL'].to_list())
    hf_unchanged_positions_list_tweet = ', $'.join(hf_unchanged_positions_list)
    hf_unchanged_positions_list_tweet = "$" + hf_unchanged_positions_list_tweet

    print('')
    string = " Report"
    new_string = (hf.capitalize() + string).center(70)
    print(new_string)
    print('')
    top_40 = holdings_df.sort_values(by="VALUE", ascending=False)[["SYMBOL", "VALUE"]][:40]
    a = top_40.SYMBOL
    b = top_40.VALUE
    c = range(len(b))

    fig = plt.figure(figsize=(15, 5))
    ax = fig.add_subplot(111)
    ax.bar(c, b)

    plt.xticks(c, a, rotation=90)
    plt.title('Top 40 Stock Holdings by Value')
    plt.xlabel('Stock Ticker')
    plt.ylabel('USD (10 MM))')
    plt.show()

    print('')
    print("New Positions")
    display(hf_new_positions_df)
    print(hf.capitalize() + ' opened new positions in ' + hf_new_positions_list_tweet)
    print('-' * 60)
    print('-' * 60)
    print('')
    print("Increased Positions")
    display(hf_increased_positions_df1)
    print(hf.capitalize() + ' increased its positions in ' + hf_increased_positions_list_tweet)
    print('-' * 60)
    print('-' * 60)
    print('')
    print("Closed Positions")
    display(hf_closed_positions_df)
    print(hf.capitalize() + ' closed its positions in ' + hf_closed_positions_list_tweet)
    print('')
    print("Decreased Positions")
    display(hf_decreased_positions_df1)
    print(hf.capitalize() + ' decreased its positions in ' + hf_decreased_positions_list_tweet)
    print('-' * 60)
    print('-' * 60)
    print('')
    print("Unchanged Positions")
    print(hf.capitalize() + ' did not change its positions in ' + hf_unchanged_positions_list_tweet)
    display(hf_unchanged_positions_df)
    print('-' * 60)
    print('-' * 60)


def biotech_hf(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    # ticker = Ticker(symbols, asynchronous=True)
    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        cur = conn.cursor()
        sql_select_query = "select SYMBOL,DATE,SHARES,VALUE,FUND from HF_cumulative_holdings where symbol = ?"
        cur.execute(sql_select_query, (symbol,))
        #     db = pd.read_sql_query(sql_select_query, conn)
        rows = cur.fetchall()
        num_fields = len(cur.description)
        field_names = [i[0] for i in cur.description]
        conn.commit()
        cur.close()
    except sqlite3.Error as error:
        print("Failed to select symbol from HF_cumulative_holdings", error)
    finally:
        if (conn):
            conn.close()

    if not rows:
        print(symbol + " is not in the HF_cumulative_holdings database")
    else:
        try:
            df = pd.DataFrame(rows, columns=field_names)
            df['DATE'] = df['DATE'].astype('datetime64[ns]')
            funds = df['FUND'].unique().tolist()

            for fund in funds:
                df_fund = df.loc[df.FUND == fund].copy()
                df_fund = df_fund.reset_index(drop=True)
                display(df_fund)
        except Exception as e:
            print(e)
            pass


# -------------------------------------------------------


def stock_info(symbol):
    print('')
    string = "Stock Report"
    new_string = (symbol + " - " + string).center(70)
    print(new_string)
    print('')
    print(web(symbol))
    print('')
    summary(symbol)
    print('')
    print('STOCK INFO:')
    trend(symbol)
    print(pctchange(symbol))
    print(pcs(symbol))
    print(sps(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('EV AND SHARES SHORT:')
    print(kss_new(symbol))
    print(kss_old(symbol))


def finances(symbol):
    print('-' * 60)
    print('-' * 60)
    print('')
    print('DILUTION:')
    display(dilution(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('BALANCE SHEET:')
    print(bss(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('FINANCIAL STATEMENT:')
    print(fss(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('CASH FLOWS:')
    print(cfs(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('CASH BURN:')
    print(cash(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('SALARIES:')
    print(salaries(symbol))
    print('-' * 60)
    print('-' * 60)
    print('')
    print('MAJOR HOLDERS:')
    try:
        print(mhs(symbol))
    except Exception as e:
        print(e)
        pass


# -------------------------------------------------------

def insiders_buy():
    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        df_insiders_bio = pd.read_sql_query("select * from [*Insiders_bio_buyers_sorted] ORDER BY [SEC Form 4] DESC;",
                                            conn)

    except sqlite3.Error as error:
        print("Failed to select from biotech", error)
    finally:
        if (conn):
            conn.close()
    display(df_insiders_bio.head(100))


# -------------------------------------------------------

def insiders_all():
    try:
        conn = sqlite3.connect("BiotechDatabase.db")
        df_insiders_bio = pd.read_sql_query("select * from [*Insiders_bio_all_sorted] ORDER BY [SEC Form 4] DESC;",
                                            conn)

    except sqlite3.Error as error:
        print("Failed to select from biotech", error)
    finally:
        if (conn):
            conn.close()
    display(df_insiders_bio.head(100))
