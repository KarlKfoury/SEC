import pandas as pd 
import datetime
from datetime import date
from bs4 import BeautifulSoup
import time
import sqlite3

def update_pipeline():
    import re
    from bs4 import BeautifulSoup
    import requests, lxml
    import pandas as pd
    url1 = 'https://www.biopharmcatalyst.com/biotech-stocks/company-pipeline-database' 
    res1 = requests.get(url1) 
    soup1 = BeautifulSoup(res1.text, 'html.parser') 
    soup2 = soup1.find('div', class_='filter-table__body list')
    rows = soup2.findAll('div', class_='filter-table__row js-tr'.split())
    complete_pipeline_list = []
    for row in rows:
        ticker_list = []
        tickers = row.findAll(['span'], class_='ticker--small') 
        companies = row.findAll(['a'], class_='company-name') 
    #     prices = row.findAll(['div'], class_='filter-table__td js-td js-td--price price text-right') 
    #     changes = row.findAll(['div'], class_='filter-table__td js-td js-td--change text-right') 
        drug_counts = row.findAll(['span'], class_='js-drugs-count')
        for ticker in tickers:
            ticker = ticker.text
        for company in companies:
            company = company.text
    #     for price in prices:
    #         price = price.get_text(strip=True)
    #     for change in changes:
    #         change = change.get_text(strip=True)
        for drug_count in drug_counts:
            drug_count = drug_count.get_text(strip=True) 
        ticker_list=[ticker,company,drug_count]     

        for ticker in ticker_list:      
            drug_list = []
            drug_list_table=row.find(['div'], class_='company__drugs') 
            drug_rows = drug_list_table.find_all('tr')
            for drug_row in drug_rows:
                company_drug_list=[]
                drug_cells = drug_row.find_all(['td', 'th'])
                for drug_cell in drug_cells:
                    drug_cell = drug_cell.get_text(strip=True)
                    company_drug_list.append(drug_cell)
                try:
                    news_link=drug_row.find('a', href=True)
                    news_link = news_link.get('href')
                    company_drug_list.append(news_link)
                except:
                     company_drug_list.append('No Link Found')       
                drug_list.append(company_drug_list)
            del drug_list[:1]


            company_drug_list_with_ticker = []
            for a in drug_list:
                company_drug_with_ticker = ticker_list+a
                company_drug_list_with_ticker.append (company_drug_with_ticker)
            for b in company_drug_list_with_ticker:
                complete_pipeline_list.append(b)


    cols = {0:'symbol',1:'Company', 2:'Drugs',3:'Drug', 4:'Indication', 5:'Phase', 6:'News', 7:'Link'}
    complete_pipeline_df = pd.DataFrame(complete_pipeline_list)
    complete_pipeline_df.rename(columns=cols, 
                     inplace=True)
    #     complete_pipeline_df = complete_pipeline_df.set_index ('symbol')

    complete_pipeline_df = complete_pipeline_df.sort_values(by = ['symbol', 'Drug'], ascending = [True, True])
    complete_pipeline_df = complete_pipeline_df.drop_duplicates()
    complete_pipeline_df = complete_pipeline_df.reset_index(drop=True)

    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")   
        complete_pipeline_df.to_sql('pipeline_bfc', conn, if_exists='replace', index = False)
    except sqlite3.Error as error:
        print("Failed to add pctchange", error)                                
    finally:
        if (conn):
            conn.close()



def update_catalysts():
#Tutorial here: https://www.scrapingbee.com/blog/selenium-python/
    from selenium import webdriver
    DRIVER_PATH = '/Users/ralph/Biotech/chromedriver'
    #This will launch Chrome in headfull mode (like a regular Chrome, which is controlled by your Python code). 
    #You should see a message stating that the browser is controlled by an automated software.
    # driver = webdriver.Chrome(executable_path=DRIVER_PATH)

    #In order to run Chrome in headless mode (without any graphical user interface), 
    #to run it on a server for example, add the code below and replace driver above with the one below:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    options = Options()
    options.headless = True
    # options.add_argument("--window-size=1920,1200")
    driver = webdriver.Chrome(options=options, executable_path=DRIVER_PATH)

    #Tutorial here:
    driver.get("https://www.biopharmcatalyst.com/account/login")
    username = driver.find_element_by_id("loginName")
    username.clear()
    username.send_keys("ralphdaher@hotmail.com")

    password = driver.find_element_by_name("password")
    password.clear()
    password.send_keys("Alphy2000$")
    driver.find_element_by_xpath("//section/form/p/input").click()

    driver.get("https://www.biopharmcatalyst.com/calendars/fda-calendar")
    time.sleep(5)

    soup = BeautifulSoup(driver.page_source, 'lxml')
    #Always quit at the end of scraping
    driver.quit()

    table = soup.find_all('table')
    catalysts_df = pd.read_html(str(table))[0] 
    catalysts_df.rename(columns={'Ticker':'symbol','Catalyst':'Catalyst_Date','burn(mthly)':'Burn(mthly)',
                                'net cash':'Net Cash','ent value':'EV',
                               'last updated':'Catalyst Last Updated'}, inplace=True) 
    catalysts_df['Catalyst'] = catalysts_df.Catalyst_Date.str.split('[2][0][2-9][0-9] ',1).str[1]
    catalysts_df['Catalyst_Date'] = catalysts_df.apply(lambda row : row['Catalyst_Date'].replace(str(row['Catalyst']), ''), axis=1)
    catalysts_df.loc[catalysts_df['Catalyst_Date'].str.contains('Adcom'), 'Adcom'] = 'Adcom'
    catalysts_df['Catalyst_Date'] = catalysts_df.apply(lambda row : row['Catalyst_Date'].replace(str(row['Adcom']), ''), axis=1)
    catalysts_df['Last Updated'] = date.today()
    catalysts_df= catalysts_df[['symbol','Price', 'Catalyst_Date', 'Stage', 'Drug', 'Catalyst', 'Adcom','No Of Shares','Market Cap',
    'Burn(mthly)','Net Cash','EV', 'Insider Holding %', 'Catalyst Last Updated','Last Updated']]
    catalysts_df.rename(columns={'Catalyst_Date':'Catalyst Date'}, inplace=True) 


    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")   
        catalysts_df.to_sql('catalysts_bfc', conn, if_exists='replace', index = False)
    except sqlite3.Error as error:
        print("Failed to connect to catalysts_bfc", error)                                
    finally:
        if (conn):
            conn.close()



update_pipeline()
update_catalysts()
