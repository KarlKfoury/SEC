$(document).ready(function() {
    //connect to the socket server.

    var socket = io.connect(
        "http://45.91.93.233:80/test"
    );
    var notifications_received = [];
    // $("#contents").css("visibility", "hidden");
    // $("#load").html('<img src="static/loading.gif" alt="Wait" />');
    //receive details from server
    socket.on("newnumber", function(msg) {
        console.log("Received number" + msg.number);
        //maintain a list of ten numbers
        if (!notifications_received.includes(msg.number)) {
            // $("#load").css("visibility", "hidden");
            // $("#contents").css("visibility", "visible");
            notifications_received.push(msg.number);
        }
        notifications_string = "";
        for (var i = 0; i < notifications_received.length; i++) {
            notifications_string =
                notifications_string +
                "<h3>" +
                notifications_received[i].toString() +
                "</h3>";
        }
        $("#log").html(notifications_string);
    });
});