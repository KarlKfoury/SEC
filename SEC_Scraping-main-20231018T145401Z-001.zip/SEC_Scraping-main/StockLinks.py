from yahooquery import Ticker
from Definitions import web
def links(symbol):
    print('-'*60)
    print('-'*60)
    print('')
    print('USEFUL LINKS')
    print('')
    symbols = symbol.split(',')
    #ticker = Ticker(symbols, asynchronous=True)
    for b in symbols:
        print("Company Website")
        web(symbol)
        print("Insider trading:")
        url1 = 'https://www.marketwatch.com/investing/stock/'+str(b)+'/insideractions'
        print(url1)
        url2= 'https://www.nasdaq.com/market-activity/stocks/'+str(b)+'/insider-activity'
        print(url2) 
        print("Reports:")
        url3="https://www.sec.gov/cgi-bin/browse-edgar?CIK="+str(b)+"&owner=exclude&action=getcompany&Find=Search"
        print(url3)
        print("Catalysts:")
        url4="https://www.biopharmcatalyst.com/company/"+str(b)
        print(url4)
        print("Transcripts:")
        url5="https://seekingalpha.com/symbol/"+str(b)+"/earnings/transcripts"
        print(url5)