import requests
import sqlite3
from yahooquery import Ticker
from bs4 import BeautifulSoup
import pandas as pd

import time

def doGet(url):
    s = requests.Session()
    headers = {
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
        'Sec-CH-UA': 'Examplary Browser',
        'Sec-CH-UA-Mobile': '?0',
        'Sec-CH-UA-Platform': "Windows",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "authority": "www.sec.gov",
        "method": "GET",
        "path": "/Archives/edgar/data/59478/000120919121046268/0001209191-21-046268-index.htm",
        "scheme": "https",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip deflate br",
        "accept-language": "en-US,en;q=0.9,ar-LB;q=0.8,ar;q=0.7",
        "cache-control": "max-age=0"}


    r = None
    proxies = {
        'http': 'socks5://127.0.0.1:9050',
        'https': 'socks5://127.0.0.1:9050'
    }
    try:
        r = s.get(url, headers=headers)

        if r.status_code == 403:
            i = 1
            while r.status_code == 403 and i <= 10:
                print("Status code: " + str(r.status_code) + "  for : " + url)
                time.sleep(1)
                r = s.get(url, headers=headers, proxies = proxies)
                i += 1
        print("Status code: " + str(r.status_code) + "  for : " + url)
        # r.raise_for_status()
    except requests.exceptions.HTTPError as errh:
        print("Http Error: " + errh + " for url: " + url)
        if r.get_status_code == 403:
            i = 1
            while r.status_code == 403 and i <= 10:
                time.sleep(i)
                r = s.get(url, headers=headers)
                i += 1
    except requests.exceptions.ConnectionError as errc:
        print("Error Connecting: " + str(errc) + "  for : " + url)
    except requests.exceptions.Timeout as errt:
        print("Timeout Error: " + str(errt) + "  for : " + url)
    except requests.exceptions.RequestException as err:
        print("OOps: Something Else" + str(err) + "  for : " + url)

    return r



def sec(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')

    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
        cur = conn.cursor()
        sql_select_query = "select CIK from biotech where symbol = ?"
        cur.execute(sql_select_query,(symbol,))
        cik = str(cur.fetchone()[0])
        conn.commit()
        cur.close()

        if cik == 'None':
            ticker = Ticker(symbols, asynchronous=True)
            df_secfilings = ticker.sec_filings
            if type(df_secfilings) is dict:
                print('No SEC Filings data available')
            else:
                df_secfilings = df_secfilings.drop(['maxAge', 'epochDate'], axis = 1)
                df_secfilings = df_secfilings.reset_index(level='row', drop = True)
                df_secfilings['edgarUrl'] = df_secfilings['edgarUrl'].apply(lambda x: '<a href="{0}" target="_blank">{0}</a>'.format(x))
                # display(HTML(df_secfilings.to_html(escape=False)))

        else:
            # Obtain HTML for search page
            base_url = "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={}&count=100" #&type={}&dateb={}"
            headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
            # edgar_resp = requests.get(base_url.format(cik), headers = headers)
            print(base_url.format(cik))
            edgar_resp = doGet(base_url.format(cik))
            edgar_str = edgar_resp.text


            # Find the document link
            doc_link = ''
            soup = BeautifulSoup(edgar_str, 'html.parser')
            table_tag = soup.find('table', class_='tableFile2')
            rows = table_tag.find_all('tr')

            #Table of all recent listings
            table = soup.find_all('table')
            filings_df = pd.read_html(str(table))[2]
            filings_df['URL']=''

            for index,row in zip(filings_df.index.to_list(),rows[1:]):

                cells = row.find_all('td')
                if len(cells) > 3:
            # #         if '2020' in cells[3].text:

                    try:
                        doc_link = 'https://www.sec.gov' + cells[1].a['href']
                        filings_df.loc[index,'URL']=doc_link
                    except:
                        continue
            filings_df = filings_df.groupby('Filings').head(2).reset_index(drop=True)
            filings_df['URL'] = filings_df['URL'].apply(lambda x: '<a href="{0}" target="_blank">{0}</a>'.format(x))
            # display(HTML(filings_df.to_html(escape=False)))
    except sqlite3.Error as error:
         print("Failed to select symbol from biotech", error)




if __name__=="__main__":
    sec('AAPL,MSFT')
