#!/usr/bin/env python3.8 -*- coding: utf-8 -*-
"""
Created on Wed Apr 21 00:35:31 2021

@author: maroun antoun
"""

from bs4 import BeautifulSoup
from yahooquery import Ticker
import pandas as pd

import requests
import traceback
import time
import unidecode
import re
import logging
import pymongo
from fake_useragent import UserAgent


def doGetForm(url, referer):
    s = requests.Session()
    headers = {
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
        'referrer': referer,
        'Sec-CH-UA': 'Examplary Browser',
        'Sec-CH-UA-Mobile': '?0',
        'Sec-CH-UA-Platform': "Windows",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "authority": "www.sec.gov",
        "method": "GET",
        "path": "/Archives/edgar/data/59478/000120919121046268/0001209191-21-046268-index.htm",
        "scheme": "https",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip deflate br",
        "accept-language": "en-US,en;q=0.9,ar-LB;q=0.8,ar;q=0.7",
        "cache-control": "max-age=0"}

    r = None

    proxies = {
        'http': 'socks5://127.0.0.1:9050',
        'https': 'socks5://127.0.0.1:9050'
    }
    try:
        r = s.get(url, headers=headers)

        if r.status_code == 403:
            i = 1
            while r.status_code == 403 and i <= 10:
                print("Status code: " + str(r.status_code) + "  for : " + url)
                logging.debug("Status code: " + str(r.status_code) + "  for : " + url)
                time.sleep(1)
                r = s.get(url, headers=headers)
                i += 1
        print("Status code: " + str(r.status_code) + "  for : " + url)
        logging.debug("Status code: " + str(r.status_code) + "  for : " + url)
        # r.raise_for_status()
    except requests.exceptions.HTTPError as errh:
        print("Http Error: " + errh + " for url: " + url)
        logging.error("Http Error: " + errh + " for url: " + url)
        if r.get_status_code == 403:
            i = 1
            while r.status_code == 403 and i <= 10:
                time.sleep(i)
                r = requests.get(url, headers=headers)
                i += 1
    except requests.exceptions.ConnectionError as errc:
        print("Error Connecting: " + str(errc) + "  for : " + url)
        logging.error("Error Connecting: " + str(errc) + "  for : " + url)
    except requests.exceptions.Timeout as errt:
        print("Timeout Error: " + str(errt) + "  for : " + url)
        logging.error("Timeout Error: " + str(errt) + "  for : " + url)
    except requests.exceptions.RequestException as err:
        print("OOps: Something Else" + str(err) + "  for : " + url)
        logging.error("OOps: Something Else" + str(err) + "  for : " + url)

    return r


def doGet(url):
    s = requests.Session()
    headers = {
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
        'Sec-CH-UA': 'Examplary Browser',
        'Sec-CH-UA-Mobile': '?0',
        'Sec-CH-UA-Platform': "Windows",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "authority": "www.sec.gov",
        "method": "GET",
        "path": "/Archives/edgar/data/59478/000120919121046268/0001209191-21-046268-index.htm",
        "scheme": "https",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip deflate br",
        "accept-language": "en-US,en;q=0.9,ar-LB;q=0.8,ar;q=0.7",
        "cache-control": "max-age=0"}

    import random

    proxies_list = ["144.48.149.26:8080", "202.53.171.114:80", "103.60.173.114:8080", "103.78.254.78:80",
                    "119.18.151.49:8080", "182.160.108.188:8090", "49.0.39.10:8080", "203.80.190.186:8080"]

    r = None
    # http_proxy_url = random.choice(proxies_list)
    http_proxy_url = "41.234.66.33:80"  # HTTP
    https_proxy_url = "149.56.86.231:80"

    # proxies={'http': http_proxy_url, 'https':https_proxy_url }
    proxies = {
        'http': 'socks5://127.0.0.1:9050',
        'https': 'socks5://127.0.0.1:9050'
    }
    try:
        r = s.get(url, headers=headers)

        if r.status_code == 403:
            i = 1
            while r.status_code == 403 and i <= 10:
                print("Status code: " + str(r.status_code) + "  for : " + url)
                logging.debug("Status code: " + str(r.status_code) + "  for : " + url)
                time.sleep(1)
                r = s.get(url, headers=headers)
                i += 1
        print("Status code: " + str(r.status_code) + "  for : " + url)
        logging.debug("Status code: " + str(r.status_code) + "  for : " + url)
        # r.raise_for_status()
    except requests.exceptions.HTTPError as errh:
        print("Http Error: " + errh + " for url: " + url)
        logging.error("Http Error: " + errh + " for url: " + url)
        if r.get_status_code == 403:
            i = 1
            while r.status_code == 403 and i <= 10:
                time.sleep(i)
                r = s.get(url, headers=headers)
                i += 1
    except requests.exceptions.ConnectionError as errc:
        print("Error Connecting: " + str(errc) + "  for : " + url)
        logging.error("Error Connecting: " + str(errc) + "  for : " + url)
    except requests.exceptions.Timeout as errt:
        print("Timeout Error: " + str(errt) + "  for : " + url)
        logging.error("Timeout Error: " + str(errt) + "  for : " + url)
    except requests.exceptions.RequestException as err:
        print("OOps: Something Else" + str(err) + "  for : " + url)
        logging.error("OOps: Something Else" + str(err) + "  for : " + url)

    return r


def createTickerCIKMap():
    response = doGet("https://www.sec.gov/include/ticker.txt")
    soup = BeautifulSoup(response.text, 'html.parser')
    with open("CIK-Ticker-Map", "w+") as file:
        file.write(str(soup))


def getNameOfReportingPerson(url):
    try:
        response = doGet(url)
        try:
            soup = BeautifulSoup(response.text, "html.parser")
        except:
            soup = BeautifulSoup(response.text, "lxml")
        table_rows_list = soup.find_all('tr')
        table_rows_text_list = []
        name_of_reporting_person_list = []
        for table_row in table_rows_list:
            table_rows_text_list.append(str(table_row.text))
        for text_table_row in table_rows_text_list:
            text_table_row = unidecode.unidecode(text_table_row.replace("\n", "").upper().replace("   ", ""))
            if 'NAME OF REPORTING PERSON' in text_table_row:
                name_of_reporting_person_list = text_table_row.split(":")

            elif 'NAMES OF REPORTING PERSONS' in text_table_row:
                first_reporting_name = text_table_row.split("\n")
                return first_reporting_name[-1].replace("NAMES OF REPORTING PERSONS", "").replace("1", "")

        if len(name_of_reporting_person_list) >= 2:
            return name_of_reporting_person_list[1]
        elif len(name_of_reporting_person_list) == 1:
            return name_of_reporting_person_list[0].replace("NAME OF REPORTING PERSON", "").replace("1", "")

        else:
            return 'Unknown'
    except:
        traceback.print_exc()
        raise


def createAndConnectForm4FeedDB(records):
    mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
    FeedDB = mongo_client["FeedDB"]
    dblist = mongo_client.list_database_names()
    if "FeedDB" in dblist:
        print("The database exists.")
        logging.debug("The database exists.")
    forms4FeedCollection = FeedDB["forms4FeedCollection"]
    collist = FeedDB.list_collection_names()
    if "forms4FeedCollection" in collist:
        print("The collection exists.")
        logging.debug("The collection exists.")

    id_list = FeedDB.forms4FeedCollection.insert_many(records)
    return id_list


def createAndConnectForm13FeedDB(records):
    mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
    FeedDB = mongo_client["FeedDB"]
    dblist = mongo_client.list_database_names()
    if "FeedDB" in dblist:
        print("The database exists.")
        logging.debug("The database exists.")
    forms13FeedCollection = FeedDB["forms4FeedCollection"]
    collist = FeedDB.list_collection_names()
    if "forms4FeedCollection" in collist:
        print("The collection exists.")
        logging.debug("The collection exists.")

    id_list = FeedDB.forms13FeedCollection.insert_many(records)
    return id_list


def getSectorIndustrybyTicker(ticker):
    print('Getting sector and industry for: ' + ticker)
    logging.debug('Getting sector and industry for: ' + ticker)

    mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
    industrySectorDB = mongo_client["IndustrySectorDB"]
    print(mongo_client.list_database_names())
    logging.debug(mongo_client.list_database_names())
    dblist = mongo_client.list_database_names()
    if "IndustrySectorDB" in dblist:
        print("The database exists.")
        logging.debug("The database exists.")

    industrySectorCollection = industrySectorDB["IndustrySector"]
    collist = industrySectorDB.list_collection_names()
    if "IndustrySector" in collist:
        print("The collection exists.")
        logging.debug("The collection exists.")

    mongoObject = industrySectorCollection.find_one({"ticker": ticker})
    print(mongoObject)
    logging.debug(mongoObject)
    # print(ticker + '   ' + mongoObject)
    if mongoObject is None:
        sector = "Undefined"
        industry = "Undefined"
    else:
        sector = mongoObject["sector"]
        industry = mongoObject["industry"]
    return sector, industry


def mapTickerToCIK(CIK):
    data = pd.read_csv('CIK-Ticker-Map', sep="\t", header=None)
    data.columns = ["Ticker", "CIK"]
    try:
        ticker = data[data.CIK == CIK].values.tolist()[0][0]
        return "$" + str(ticker).upper()
    except:
        return ""


def getHTMLformLink(form_page_url):
    request = doGetForm(form_page_url, form_page_url)
    sec_gov = 'https://sec.gov/'
    final_link_list = []
    try:
        soup = BeautifulSoup(request.text, "html.parser")
        href_list = soup.find_all('a', href=True)
        for i in href_list:
            if ('Archives' in i["href"].split("/")):
                final_link_list.append(sec_gov + i["href"])
        return final_link_list[0]
    except:
        traceback.print_exc()
        return form_page_url
