# -*- coding: utf-8 -*-
"""
Created on Sun Feb 28 17:33:00 2021
@author: Anthony Aoun
@modified by: Maroun  Antoun
@modified date: 1/5/2021
"""

from bs4 import BeautifulSoup
import utils
import sys


def replaceFootnotes(soup):

    footnotes = soup.find_all("footnoteid")
    for elt in footnotes:
        elt.replaceWith(" footnote {}".format(elt["id"]))


def getNonDerivativeTransactions(nonDerivativeTransactions, nonDerivativeTable):

    for elt in nonDerivativeTransactions:
        nonDerivativeTransaction = dict()
        securitiesAcquiredOrDisposedOf = dict()

        try:
            nonDerivativeTransaction["Title of Security"] = elt.find(
                "securitytitle").text.replace("\n", "")
        except:
            nonDerivativeTransaction["Title of Security"] = ""

        try:
            nonDerivativeTransaction["Transaction Date"] = elt.find(
                "transactiondate").text.replace("\n", "")
        except:
            nonDerivativeTransaction["Transaction Date"] = ""

        try:
            nonDerivativeTransaction["Deemed Execution Date"] = elt.find(
                "deemedexecutiondate").text.replace("\n", "")
        except:
            nonDerivativeTransaction["Deemed Execution Date"] = ""

        try:
            nonDerivativeTransaction["Transaction Code"] = elt.find(
                "transactioncode").text.replace("\n", "")
        except:
            nonDerivativeTransaction["Transaction Code"] = ""

        try:
            securitiesAcquiredOrDisposedOf["Amount"] = elt.find(
                "transactionshares").find("value").text.replace("\n", "")
        except:
            securitiesAcquiredOrDisposedOf["Amount"] = ""

        try:
            securitiesAcquiredOrDisposedOf["(A) or (D)"] = elt.find(
                "transactionacquireddisposedcode").text.replace("\n", "")
        except:
            securitiesAcquiredOrDisposedOf["(A) or (D)"] = ""

        try:
            securitiesAcquiredOrDisposedOf["Price"] = elt.find(
                "transactionpricepershare").find("value").text.replace("\n", "")
        except:
            securitiesAcquiredOrDisposedOf["Price"] = ""

        nonDerivativeTransaction["Securities Acquired (A) or Disposed Of (D)"] = securitiesAcquiredOrDisposedOf

        try:
            nonDerivativeTransaction["Amount of Securities Beneficially Owned Following Reported Transaction"] = elt.find(
                "sharesownedfollowingtransaction").text.replace("\n", "")
        except:
            nonDerivativeTransaction["Amount of Securities Beneficially Owned Following Reported Transaction"] = ""

        try:
            nonDerivativeTransaction["Ownership Form: Direct (D) or Indirect (I)"] = elt.find(
                "directorindirectownership").text.replace("\n", "")
        except:
            nonDerivativeTransaction["Ownership Form: Direct (D) or Indirect (I)"] = ""

        try:
            nonDerivativeTransaction["Nature of Indirect Beneficial Ownership"] = elt.find(
                "natureofownership").text.replace("\n", "")
        except:
            nonDerivativeTransaction["Nature of Indirect Beneficial Ownership"] = ""

        nonDerivativeTable.append(nonDerivativeTransaction)


def getDerivativeTransactions(DerivativeTransactions, DerivativeTable):

    for elt in DerivativeTransactions:
        DerivativeTransaction = dict()
        securitiesAcquiredOrDisposedOf = dict()
        underlyingSecurity = dict()

        try:
            DerivativeTransaction["Title of Derivative Security"] = elt.find(
                "securitytitle").text.replace("\n", "")
        except:
            DerivativeTransaction["Title of Derivative Security"] = ""

        try:
            DerivativeTransaction["Conversion or Exercise Price of Derivative Security"] = elt.find(
                "conversionorexerciseprice").text.replace("\n", "")
        except:
            DerivativeTransaction["Conversion or Exercise Price of Derivative Security"] = ""

        try:
            DerivativeTransaction["Transaction Date"] = elt.find(
                "transactiondate").text.replace("\n", "")
        except:
            DerivativeTransaction["Transaction Date"] = ""

        try:
            DerivativeTransaction["Deemed Execution Date"] = elt.find(
                "deemedexecutiondate").text.replace("\n", "")
        except:
            DerivativeTransaction["Deemed Execution Date"] = ""

        try:
            DerivativeTransaction["Transaction Code"] = elt.find(
                "transactioncode").text.replace("\n", "")
        except:
            DerivativeTransaction["Transaction Code"] = ""

        try:
            securitiesAcquiredOrDisposedOf["Amount"] = elt.find(
                "transactionshares").text.replace("\n", "")
        except:
            securitiesAcquiredOrDisposedOf["Amount"] = ""

        try:
            securitiesAcquiredOrDisposedOf["(A) or (D)"] = elt.find(
                "transactionacquireddisposedcode").text.replace("\n", "")
        except:
            securitiesAcquiredOrDisposedOf["(A) or (D)"] = ""

        DerivativeTransaction["Number of Derivative Securities Acquired (A) or Disposed of (D)"] = securitiesAcquiredOrDisposedOf

        try:
            DerivativeTransaction["Date Exercisable"] = elt.find(
                "exercisedate").text.replace("\n", "")
        except:
            DerivativeTransaction["Date Exercisable"] = ""

        try:
            DerivativeTransaction["Expiration Date"] = elt.find(
                "expirationdate").text.replace("\n", "")
        except:
            DerivativeTransaction["Expiration Date"] = ""

        try:
            underlyingSecurity["Title"] = elt.find(
                "underlyingsecuritytitle").text.replace("\n", "")
        except:
            underlyingSecurity["Title"] = ""

        try:
            underlyingSecurity["Amount or Number of Shares"] = elt.find(
                "underlyingsecurityshares").text.replace("\n", "")
        except:
            underlyingSecurity["Amount or Number of Shares"] = ""

        DerivativeTransaction["Title and Amount of Securities Underlying Derivative Security"] = underlyingSecurity

        try:
            DerivativeTransaction["Price of Derivative Security"] = elt.find(
                "transactionpricepershare").text.replace("\n", "")
        except:
            DerivativeTransaction["Price of Derivative Security"] = ""

        try:
            DerivativeTransaction["Number of derivative Securities Beneficially Owned Following Reported Transaction"] = elt.find(
                "sharesownedfollowingtransaction").text.replace("\n", "")
        except:
            DerivativeTransaction["Number of derivative Securities Beneficially Owned Following Reported Transaction"] = ""

        try:
            DerivativeTransaction["Ownership Form: Direct (D) or Indirect (I)"] = elt.find(
                "directorindirectownership").text.replace("\n", "")
        except:
            DerivativeTransaction["Ownership Form: Direct (D) or Indirect (I)"] = ""

        try:
            DerivativeTransaction["Nature of Indirect Beneficial Ownership"] = elt.find(
                "natureofownership").text.replace("\n", "")
        except:
            DerivativeTransaction["Nature of Indirect Beneficial Ownership"] = ""

        DerivativeTable.append(DerivativeTransaction)


def getAllFootnotes(footnotesFound, footnotes):

    for elt in footnotesFound:

        try:
            footnotes["footnote {}".format(elt["id"])] = elt.text
        except:
            continue


def Scrape_Form_4(url):
    text_form_link = url.replace(".txt", "-index.htm" )
    result = dict()
    req = utils.doGetForm(url, text_form_link)
    soup = BeautifulSoup(req.content, 'lxml')
    replaceFootnotes(soup)

    reportingOwner = dict()
    Issuer = dict()
    periodOfReport = dict()
    reportingOwnerRelationship = dict()

    nonDerivativeTable = list()
    DerivativeTable = list()
    footnotes = dict()

    # reportingOwner["Name of Reporting Person"] = soup.find("rptownername").text
    # reportingOwner["Reporting Owner CIK"] = soup.find("rptownercik").text

    try:
        reportingOwner["Name of Reporting Person"] = soup.find(
            "rptownername").text
    except:
        reportingOwner["Name of Reporting Person"] = ""

    try:
        reportingOwner["Reporting Owner CIK"] = soup.find("rptownercik").text
    except:
        reportingOwner["Reporting Owner CIK"] = ""

    try:
        reportingOwner["Address of Reporting Person"] = dict()
        reportingOwner["Address of Reporting Person"]["Street 1"] = soup.find(
            "rptownerstreet1").text
        reportingOwner["Address of Reporting Person"]["Street 2"] = soup.find(
            "rptownerstreet2").text
        reportingOwner["Address of Reporting Person"]["City"] = soup.find(
            "rptownercity").text
        reportingOwner["Address of Reporting Person"]["State"] = soup.find(
            "rptownerstate").text
        reportingOwner["Address of Reporting Person"]["Zip Code"] = soup.find(
            "rptownerzipcode").text
        reportingOwner["Address of Reporting Person"]["State Description"] = soup.find(
            "rptownerstatedescription").text
    except:
        reportingOwner["Address of Reporting Person"] = dict()
        reportingOwner["Address of Reporting Person"]["Street 1"] = ""
        reportingOwner["Address of Reporting Person"]["Street 2"] = ""
        reportingOwner["Address of Reporting Person"]["City"] = ""
        reportingOwner["Address of Reporting Person"]["State"] = ""
        reportingOwner["Address of Reporting Person"]["Zip Code"] = ""
        reportingOwner["Address of Reporting Person"]["State Description"] = ""

    try:
        Issuer["Issuer Name"] = soup.find("issuername").text
        Issuer["Issuer CIK"] = soup.find("issuercik").text
        Issuer["Issuer Trading Symbol"] = soup.find("issuertradingsymbol").text
    except:
        Issuer["Issuer Name"] = ""
        Issuer["Issuer CIK"] = ""
        Issuer["Issuer Trading Symbol"] = ""

    try:
        periodOfReport["Period of Report"] = soup.find("periodofreport").text
    except:
        periodOfReport["Period of Report"] = ""

    try:
        reportingOwnerRelationship["Director"] = soup.find("isdirector").text
    except:
        reportingOwnerRelationship["Director"] = ""
    try:
        reportingOwnerRelationship["Officer (give title below)"] = soup.find(
            "isofficer").text
    except:
        reportingOwnerRelationship["Officer (give title below)"] = ""
    try:
        reportingOwnerRelationship["10% Owner"] = soup.find(
            "istenpercentowner").text
    except:
        reportingOwnerRelationship["10% Owner"] = ""
    try:
        reportingOwnerRelationship["Other (give title below)"] = soup.find(
            "isother").text
    except:
        reportingOwnerRelationship["Other (give title below)"] = ""

    try:
        reportingOwnerRelationship["Officer Title"] = soup.find(
            "officertitle").text.replace("\n", "")
        reportingOwnerRelationship["Other Text"] = soup.find(
            "othertext").text.replace("\n", "")
    except:
        reportingOwnerRelationship["Officer Title"] = ""
        reportingOwnerRelationship["Other Text"] = ""

    nonDerivativeTransactions = soup.find_all("nonderivativetransaction")
    getNonDerivativeTransactions(nonDerivativeTransactions, nonDerivativeTable)

    nonDerivativeTransactions = soup.find_all("nonderivativeholding")
    getNonDerivativeTransactions(nonDerivativeTransactions, nonDerivativeTable)

    DerivativeTransactions = soup.find_all("derivativetransaction")
    getDerivativeTransactions(DerivativeTransactions, DerivativeTable)

    DerivativeTransactions = soup.find_all("derivativeholding")
    getDerivativeTransactions(DerivativeTransactions, DerivativeTable)

    footnotesFound = soup.find_all("footnote")
    getAllFootnotes(footnotesFound, footnotes)

    salesAverageList = []
    if(len(nonDerivativeTable) > 0):
        salesAverage = 0
        numberOfSales = 0

        for elt in nonDerivativeTable:
            numberOfShares = int(float(elt["Securities Acquired (A) or Disposed Of (D)"]["Amount"])
                                 ) if elt["Securities Acquired (A) or Disposed Of (D)"]["Amount"] != '' else 0
            oneSharePrice = int(float(elt["Securities Acquired (A) or Disposed Of (D)"]["Price"])
                                ) if elt["Securities Acquired (A) or Disposed Of (D)"]["Price"] != '' else 0
            if(elt["Transaction Date"]):
                if(numberOfSales > 0):
                    salesAverageList.append({"Date": elt["Transaction Date"], "Sales Average": salesAverage /
                                             numberOfSales, "Number of shares": numberOfShares, "One share price": oneSharePrice})
                transactionDate = elt["Transaction Date"]
                salesAverage = 0
                numberOfSales = 0

            if(elt["Transaction Code"] != "" and elt["Transaction Code"] == "S"):
                numberOfSales += 1
                try:
    
                    salesAverage += float(elt["Securities Acquired (A) or Disposed Of (D)"]["Amount"]) * float(
                        elt["Securities Acquired (A) or Disposed Of (D)"]["Price"])
                    if(len(nonDerivativeTable) == 1):
                        salesAverageList.append({"Date": transactionDate, "Sales Average": salesAverage,
                                                    "Number of shares": numberOfShares, "One share price": oneSharePrice})
                except:
                    print("Unexpected error:", sys.exc_info()[0])
                    raise
                    salesAverage += 0

    result["Sales Averages"] = salesAverageList
    result["Name and Address of Reporting Person"] = reportingOwner
    result["Issuer Name and Ticker or Trading Symbol"] = Issuer
    result["Date of Earliest Transaction"] = periodOfReport
    result["Relationship of Reporting Person(s) to Issuer"] = reportingOwnerRelationship
    result["Non-Derivative Securities Acquired, Disposed of, or Beneficially Owned"] = nonDerivativeTable
    result["Derivative Securities Acquired, Disposed of, or Beneficially Owned"] = DerivativeTable
    result["footnotes"] = footnotes
    result["txt_link"] = url

    return result

if __name__ == '__main__':
    txt_link ="https://www.sec.gov/Archives/edgar/data/1289419/000128941921000090/0001289419-21-000090.txt"
    formData = Scrape_Form_4(txt_link)
