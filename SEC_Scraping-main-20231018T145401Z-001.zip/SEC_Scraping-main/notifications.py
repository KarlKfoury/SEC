
# Start with a basic flask app webpage.
from flask import Flask, request, Response
import json
from flask_cors import CORS, cross_origin
from feedParserUpdate import FeedParser
from pywebpush import webpush, WebPushException
from pymongo.errors import DuplicateKeyError

import pymongo
import sys
import time

myclient = pymongo.MongoClient("mongodb://localhost:27017/")

sub_users = myclient["sub_users"]
sub_users_auth = sub_users["sub_users_auth"]

subscriptions = []
__author__ = 'slynn'

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
# app.config['DEBUG'] = False
app.config['CORS_HEADERS'] = 'Content-Type'
cors = CORS(app,  resources={r"/api/*": {"origins": "*"}})


VAPID_PRIVATE_KEY = "tDc0qjRC4DLqqKoRpWlEdM8YDivuvC9OrKagnC97tIk"
VAPID_PUBLIC_KEY = "BDbSrhMxREV7Ryotl2_otvuPqaegMv6ZyzAK5CId93GdFqLxCUHrEyITgy-C_HB2_9dISYJaNMpjxEOyWWzmjy4"
VAPID_CLAIMS = {
    "sub": "mailto:marounantoun97@gmail.com"
}

feedParser = FeedParser(
    'https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&CIK=&type=SC%2013&company=&&owner=include&start=0&count=100&output=atom', set())

feedParserForm4 = FeedParser(
    'https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&CIK=&type=4&company=&dateb=&owner=only&start=0&count=100&output=atom', set())

notif_array = []


@app.route("/api/newsletter", methods=["POST"])
@cross_origin()
def newsletterFunction():
    print("In NewsLetter Function")
    sub = request.get_json(force=True)
    print(sub)
    try:
        starttime = time.time()
        while True:

            feedParser.updateCurrentPosts()
            forms13G, forms13D = feedParser.createDataframe()

            feedParserForm4.updateCurrentPosts()
            forms4 = feedParserForm4.createDataframeForm4()

            if (not forms13G.empty):
                for index, row in forms13G.iterrows():
                    notif = row['Ticker'] + " " + row['Name of Reporting Person'] + " has filed Form SC 13G reporting " + \
                        row['Shares Amount'] + " ownership in " + \
                        row['Target']
                    if notif not in notif_array:
                        notif_array.append(notif)
                        sub_id = sub["keys"]["auth"]
                        sub_list = sub_users_auth.find({"_id": sub_id})
                        print(sub_list)
                        print("Sending  Notifications")
                        for subscriber in sub_list:
                            del subscriber['_id']
                            webpush(
                                subscription_info=subscriber,
                                data="""{"notification": {"title": "13G", "body": " """ + notif + """ "}}""",
                                vapid_private_key=VAPID_PRIVATE_KEY,
                                vapid_claims=VAPID_CLAIMS
                            )

            if (not forms13D.empty):
                for index, row in forms13D.iterrows():
                    notif = row['Ticker'] + " " + row['Name of Reporting Person'] + " has filed Form SC 13D reporting " + \
                        row['Shares Amount'] + " ownership in" + \
                        row['Target'] + " on " + row['Date']
                    if notif not in notif_array:
                        notif_array.append(notif)
                        sub_id = sub["keys"]["auth"]
                        sub_list = sub_users_auth.find({"_id": sub_id})
                        print(sub_list)
                        print("Sending  Notifications")
                        for subscriber in sub_list:
                            del subscriber['_id']
                            webpush(
                                subscription_info=subscriber,
                                data="""{"notification": {"title": "13D", "body": " """ + notif + """ "}}""",
                                vapid_private_key=VAPID_PRIVATE_KEY,
                                vapid_claims=VAPID_CLAIMS
                            )

            try:
                if (not forms4.empty):
                    for index, row in forms4.iterrows():
                        notif = row['Ticker'] + " " + row['Reporting Person'] + " has filed Form 4 reporting " + " ownership in " +  row['Target'] 
                        if notif not in notif_array:
                            notif_array.append(notif)
                            sub_id = sub["keys"]["auth"]
                            sub_list = sub_users_auth.find({"_id": sub_id})
                            print(sub_list)
                            print("Sending  Notifications")
                            for subscriber in sub_list:
                                del subscriber['_id']
                                webpush(
                                    subscription_info=subscriber,
                                    data="""{"notification": {"title": "Form 4", "body": " """ + notif + """ "}}""",
                                    vapid_private_key=VAPID_PRIVATE_KEY,
                                    vapid_claims=VAPID_CLAIMS
                                )

            except:
                print("Unexpected error in form 4 notifications:",
                      sys.exc_info()[0])
                raise

            time.sleep(60.0 - ((time.time() - starttime) % 60.0))
    except WebPushException as ex:
        print("I'm sorry, Antoun, but I can't do that: {}", repr(ex))
        # Mozilla returns additional information in the body of the response.
        if ex.response and ex.response.json():
            extra = ex.response.json()
            print("Remote service replied with a {}:{}, {}",
                  extra.code,
                  extra.errno,
                  extra.message
                  )
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise


@app.route("/api/notifications", methods=["GET", "POST"])
@cross_origin()
def notificationsFunction():
    """
        POST creates a subscription
        GET returns vapid public key which clients uses to send around push notification
    """

    if request.method == "GET":
        return Response(response=json.dumps({"public_key": VAPID_PUBLIC_KEY}),
                        headers={"Access-Control-Allow-Origin": "*"}, content_type="application/json")

    sub = request.get_json(force=True)
    print("Sub: ")
    print(sub)

    sub["_id"] = sub["keys"]["auth"]

    try:
        sub_users_auth.delete_one(sub)
        sub_ID = sub_users_auth.insert_one(sub)
        print("sub_ID")
        print(sub_ID)
        return Response(status=200, mimetype="application/json")
    except DuplicateKeyError:
        print("Duplicate key found")
        return Response(status=200, mimetype="application/json")
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise


if __name__ == '__main__':
    # Configuration to run on server
    app.run(host='0.0.0.0', port='6000')
