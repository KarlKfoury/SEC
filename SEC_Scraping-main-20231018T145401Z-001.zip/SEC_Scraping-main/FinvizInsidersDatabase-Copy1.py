#Tutorial here: https://www.scrapingbee.com/blog/selenium-python/
import datetime
today = datetime.datetime.now()
import time
from selenium import webdriver
from bs4 import BeautifulSoup
import pandas as pd


DRIVER_PATH = '/Users/ralph/Biotech/chromedriver'
#This will launch Chrome in headfull mode (like a regular Chrome, which is controlled by your Python code). 
#You should see a message stating that the browser is controlled by an automated software.
# driver = webdriver.Chrome(executable_path=DRIVER_PATH)

#In order to run Chrome in headless mode (without any graphical user interface), 
#to run it on a server for example, add the code below and replace driver above with the one below:
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
options = Options()
options.headless = True
# options.add_argument("--window-size=1920,1200")
driver = webdriver.Chrome(options=options, executable_path=DRIVER_PATH)

#Tutorial here:
driver.get("https://finviz.com/insidertrading.ashx") #for all insider activities
#driver.get("https://finviz.com/insidertrading.ashx?tc=1") #for buyers
#driver.get("https://finviz.com/insidertrading.ashx?tc=2") #for sellers
#driver.get("https://finviz.com/insidertrading.ashx?tc=4") #for options
time.sleep(2)

soup = BeautifulSoup(driver.page_source, 'lxml')
#Always quit at the end of scraping
driver.quit()

table = soup.find_all('table')

finviz_df = pd.read_html(str(table))[7] 
headers = ['symbol','Owner','Relationship','Date','Transaction','Cost','#Shares','Value ($)','#Shares Total','SEC Form 4']
finviz_df  = pd.DataFrame(finviz_df.values[1:], columns=headers)
finviz_df = finviz_df.set_index('symbol')
finviz_df

def database_file():
    filename = 'BiotechDatabase.csv'
    fields = ['symbol','Company', 'My Notes Date','My Notes','Revisit Date','Score (1-10)','Last Updated','Exchange','First Traded','Industry','Sector','Phone',
                  'Web','Summary','Mkt. Cap','Price','Percent Change','Volume',
                  '1 Month Percentage Change','3 Month Percentage Change',
                  '1 Year Percentage Change','Date_BS','Cash/Short Term Inv.',
                  'Tot.Assets','Tot.Liabilities','Tot.Equity','Date_FS',
                  'Tot.Revenue','Net Income','Date_CF','Free Cash Flow',
                  'Date_CB','CashBurnPerDay','CashLeftToday','Months to 0$',
                  'Date of Short Report','EV','Shares Outst.','Float',
                  'Shares Short','Short % of Float','Short Ratio',
                  'Previous Date of Report','Prior Shares Short',
                  'Insiders % Held','Institutions Count',
                  'Institutions Float % Held','Institutions % Held',
                  'Buy (3M)','Buy (6M)','Buy (12M)','Sell (3M)','Sell (6M)',
                  'Sell (12M)','Shares Bought (3M)','Shares Bought (6M)',
                  'Shares Bought (12M)','Shares Sold (3M)','Shares Sold (6M)',
                  'Shares Sold (12M)']
    return filename,fields

def finviz_file():
    finviz_filename = 'FinvizInsiders.csv'
    finviz_fields = ['symbol','Owner', 'Relationship','Date','Transaction','Cost','#Shares','Value ($)','#Shares Total','SEC Form 4']
    return finviz_filename,finviz_fields

global df_bio
filename,fields = database_file()
finviz_filename,finviz_fields = finviz_file()

# Reading csv from file with names as fields
df_bio = pd.read_csv(filename, names=fields, header=0, index_col='symbol')
symbols_db = df_bio.index.tolist()

#Making a list of the new insiders symbols
symbols_finviz=finviz_df.index.tolist()

#Isolating the biotech new insiders symbols dataframe
biotech_finviz = sorted(list(set(symbols_db).intersection(symbols_finviz)))
biotech_finviz_new_df= finviz_df.loc[biotech_finviz]
biotech_finviz_new_df['SEC Form 4'] = str(today.year) +' '+ biotech_finviz_new_df['SEC Form 4'].astype(str)
biotech_finviz_new_df['SEC Form 4'] = biotech_finviz_new_df['SEC Form 4'].astype('datetime64[ns]')
biotech_finviz_new_df['Date'] = str(today.year) +' '+ biotech_finviz_new_df['Date'].astype(str)
biotech_finviz_new_df['Date'] = biotech_finviz_new_df['Date'].astype('datetime64[ns]')
biotech_finviz_new_df['Cost'] = biotech_finviz_new_df['Cost'].apply(pd.to_numeric, errors='ignore', downcast='float')
biotech_finviz_new_df['#Shares'] = biotech_finviz_new_df['#Shares'].fillna(0).astype(int)
biotech_finviz_new_df['#Shares Total'] = biotech_finviz_new_df['#Shares Total'].fillna(0).astype(int)
biotech_finviz_new_df['Value ($)'] = biotech_finviz_new_df['Value ($)'].fillna(0).astype(int)
biotech_finviz_new_df['Cost'] = biotech_finviz_new_df['Cost'].apply(lambda x: round(x, 2))
biotech_finviz_new_df = biotech_finviz_new_df.sort_values(['SEC Form 4'], ascending = False)
biotech_finviz_new_df = biotech_finviz_new_df.reset_index()


# Reading csv from file with names as finviz_fields
finviz_db= pd.read_csv(finviz_filename, names=finviz_fields, header=0, index_col='symbol')
finviz_db['SEC Form 4'] = finviz_db['SEC Form 4'].astype('datetime64[ns]')
finviz_db['Date'] = finviz_db['Date'].astype('datetime64[ns]')
finviz_db = finviz_db.reset_index()

def dataframe_difference(finviz_db, biotech_finviz_new_df, which='right_only'):
#    """Find rows which are different between two DataFrames."""
    global comparison_df
    comparison_df = finviz_db.merge(biotech_finviz_new_df, indicator=True, how='outer')

    if which is None:
        diff_df = comparison_df[comparison_df['_merge'] != 'both']
    else:
        diff_df = comparison_df[comparison_df['_merge'] == which]
   # diff_df.to_csv('data/diff.csv')
    return diff_df

diff_df = dataframe_difference(finviz_db, biotech_finviz_new_df, which='right_only')
diff_df = diff_df.drop(columns=['_merge'])

new_finviz_db = comparison_df.drop(columns=['_merge'])
new_finviz_db = new_finviz_db.sort_values(['SEC Form 4'], ascending = False)
new_finviz_db = new_finviz_db.set_index('symbol')

# Saving back to filename and overwrites it - Be careful!
new_finviz_db.to_csv(finviz_filename, index=True, header = True)

