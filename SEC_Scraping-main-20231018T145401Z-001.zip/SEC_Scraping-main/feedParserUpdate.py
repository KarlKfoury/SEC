#!/usr/bin/env python3.8 -*- coding: utf-8 -*-
"""
Created on Sat Jan 30 13:05:26 2021

@author: maroun antoun
"""
# mongod --dbpath=yourdirectory\data\db

# Updating the feed parser using sched in python

import feedparser
import pandas as pd

from multiprocessing import Pool

from bs4 import BeautifulSoup

from Form_4_Scraping import Scrape_Form_4
from utils import getNameOfReportingPerson

import utils

import traceback
import sys
import time

timestr = time.strftime("%Y%m%d")

# importing the module
import logging

# now we will Create and configure logger
logging.basicConfig(filename="feedParserLog" + timestr + ".log",
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    filemode='w+')

# Let us Create an object
logger = logging.getLogger()

# Now we are going to Set the threshold of logger to DEBUG
logger.setLevel(logging.DEBUG)

pd.set_option("display.max_rows", None, "display.max_columns", None)
pd.set_option("display.max_colwidth", 10000)


class FeedParser:
    def __init__(self, feedUrl, posts):
        self.url = feedUrl
        logger.debug("URL: " + self.url)
        logger.debug('Started creating the CIK-Ticker Map')
        utils.createTickerCIKMap()
        logger.debug('Finished creating the CIK-Ticker Map')
        self.posts = posts

    def getFeedPosts(self):
        print('Started getting posts')
        logger.debug('Started getting posts')
        post_list = []
        feed = feedparser.parse(self.url)
        # print(feed)

        i = 1
        while len(feed.entries) == 0 and i <= 10:
            time.sleep(i)
            feed = feedparser.parse(self.url)
            i += 1
        try:
            for post in feed.entries:
                # print(post)
                post_list.append(
                    (post.title, post.link, post.summary, post.updated))
            # print(postList)
            print('Finished getting posts without errors')
            logger.debug('Finished getting posts without errors')

            return post_list
        except:
            traceback.print_exc()

    def updateCurrentPosts(self):
        print('Started updating current posts')
        logger.debug('Started updating current posts')

        allPosts = []
        self.posts = set()
        newPosts = self.getFeedPosts()
        # print(newPosts)
        try:
            if newPosts:
                for post in newPosts:
                    if (post not in allPosts):
                        # print(post)
                        allPosts.append(post)
                self.posts.update(allPosts)
            else:
                print("No recent changes")
                logger.debug('No recent changes')

            print('Finished updating current posts')
            logger.debug('Finished updating current posts')

        except:
            traceback.print_exc()

    @staticmethod
    def getSharesAmount(url):
        try:
            response = utils.doGet(url)
            soup = BeautifulSoup(response.text, "html.parser")
        except:
            traceback.print_exc()
        finally:
            import re
            response = utils.doGet(url)
            soup = BeautifulSoup(response.text, "html.parser")
            scores_string = soup.find_all(text=re.compile('\%'))
            scores = [score_string.split()[-1]
                      for score_string in scores_string]
            r = re.compile(r"^(?=.*?\d)\d*[.,]?\d*\%$")
            if scores and r.match(scores[0]):
                print("For " + url + " we have " + scores[0])
                logger.debug("For " + url + " we have " + scores[0])

                return scores[0]
            elif scores:
                scores_string = soup.find_all(text=re.compile('\%'))
                scores = scores_string[0].split()[0]
                r = re.compile(r"^(?=.*?\d)\d*[.,]?\d*\%$")
                if r.match(scores):
                    return scores
                else:
                    try:
                        scores_string = soup.find_all(text=re.compile('\%'))
                        scores = scores_string[1].split()[0]
                        print("else:" + url + " we have " + scores)
                        logger.debug("else:" + url + " we have " + scores)

                        return scores
                    except:
                        traceback.print_exc()
                        pass
            elif not scores:

                scores_string = soup.find_all(
                    text=re.compile(r"^(?=.*?\d)\d*[.,]?\d*$"))
                if scores_string:
                    scores = scores_string[1]
                    print("Not normal 1 for: " + url + " but we have " + scores)
                    logger.debug("Not normal 1 for: " + url + " but we have " + scores)
                    return scores
            return "Unknown"

    @staticmethod
    def mapTickerToCIK(CIK):
        data = pd.read_csv('CIK-Ticker-Map', sep="\t", header=None)
        data.columns = ["Ticker", "CIK"]
        try:
            ticker = data[data.CIK == CIK].values.tolist()[0][0]
            return "$" + str(ticker).upper()
        except:
            return ""

    def createDataframe(self):
        print("Length of self posts: " + str(len(self.posts)))
        logger.debug("Length of self posts: " + str(len(self.posts)))

        i = 1
        while len(self.posts) == 0 and i <= 10:
            import time
            time.sleep(i)
            self.updateCurrentPosts()
            i += 1
        try:
            # pass data to init
            df = pd.DataFrame(self.posts, columns=[
                'title', 'link', 'summary', 'Time'])
            df = df[~df.title.str.contains("Filed by")]
            df["Issue Time"] = ""
            df["Issue Date"] = ""

            for time_date in df['Time']:
                time_list = time_date.split('T')
                df.loc[df['Time'] == time_date,
                       'Issue Time'] = time_list[1].split('-')[0]
                df.loc[df['Time'] == time_date, 'Issue Date'] = time_list[0]

            df.sort_values(by=['Issue Date', 'Issue Time'],
                           inplace=True, ascending=False)

            try:
                df['Form'] = df["title"].str.split(" - ", n=-1, expand=True)[0]
            except:
                df['Form'] = ""
            try:
                df["Target"] = df["title"].apply(
                    lambda st: st[st.find("- ") + 1:st.find("(")])
            except:
                df["Target"] = ""
            try:
                df['Date'] = df["summary"].apply(
                    lambda st: st[st.find("> ") + 2:st.find(" <b")])
            except:
                df['Date'] = ""
            try:
                df["CIK"] = df["title"].str.extract('\((\d+)\)')
            except:
                df["CIK"] = ""
            try:
                df["CIK"] = df["CIK"].fillna(0).astype(int)
            except:
                df["CIK"] = ""

            df = df.drop(columns=['summary'])
            df['Lead_Investor'] = ''
            df["Form_Link"] = ""
            df["Name of Reporting Person"] = ""
            df["HTML_Form_Link"] = ""

            cols = list(df)
            # move the column to head of list using index, pop and insert
            cols.insert(0, cols.pop(cols.index('Date')))
            cols.insert(1, cols.pop(cols.index('Form')))
            cols.insert(2, cols.pop(cols.index('Target')))
            cols.insert(3, cols.pop(cols.index('Lead_Investor')))
            cols.insert(4, cols.pop(cols.index('Form_Link')))
            df = df[cols]
            df = df.reset_index(drop=True)

            forms_13G = df.loc[df['Form'] == 'SC 13G']
            forms_13D = df.loc[df['Form'] == 'SC 13D']
            df = pd.concat([forms_13G, forms_13D], axis=0)

            print("Form 13G/D link: ")
            logger.debug("Form 13G/D link: ")

            for link in df['link']:
                html_link = utils.getHTMLformLink(link)
                df.loc[df['link'] == link, 'HTML_Form_Link'] = html_link
                text_form_link = link.replace("-index.htm", ".txt")
                df.loc[df['link'] == link, 'Form_Link'] = text_form_link

            # Get the name of the reporting person of a form 13
            for link in df["Form_Link"]:
                df.loc[df['Form_Link'] == link,
                       'Name of Reporting Person'] = getNameOfReportingPerson(link)

            # Get ticker from CIK for tradeable companies
            for CIK in df['CIK']:
                ticker = self.mapTickerToCIK(CIK)
                df.loc[df['CIK'] == CIK, 'Ticker'] = ticker

            for ticker in df["Ticker"]:
                if (ticker):
                    ticker_split = ticker.split("$")[1]
                    sector, industry = utils.getSectorIndustrybyTicker(
                        ticker_split)
                    df.loc[df['Ticker'] == ticker, 'Sector'] = sector
                    df.loc[df['Ticker'] == ticker, 'Industry'] = industry

                else:
                    df.loc[df['Ticker'] == ticker, 'Sector'] = 'Undefined'
                    df.loc[df['Ticker'] == ticker, 'Industry'] = "Undefined"

            forms13G = df.loc[df['Form'] == 'SC 13G']
            forms13D = df.loc[df['Form'] == 'SC 13D']

            forms13G = forms13G.loc[forms13G['Sector'] == 'Healthcare']
            # forms13G_undefined = forms13G.loc[forms13G['Sector'] == 'Undefined']
            # forms13G = pd.concat([forms13G_healthcare, forms13G_undefined], axis=0)

            for txt_link in forms13G["Form_Link"]:
                forms13G.loc[forms13G['Form_Link'] == txt_link,
                             'Shares Amount'] = self.getSharesAmount(txt_link)

            forms13D = forms13D.loc[forms13D['Sector'] == 'Healthcare']
            # forms13D_undefined = forms13D.loc[forms13D['Sector'] == 'Undefined']
            # forms13D = pd.concat([forms13D_healthcare, forms13D_undefined], axis=0)

            for txt_link in forms13D["Form_Link"]:
                forms13D.loc[forms13D['Form_Link'] == txt_link,
                             'Shares Amount'] = self.getSharesAmount(txt_link)

            import pytz

            tz = pytz.timezone('America/New_York')
            from datetime import datetime
            now = datetime.now(tz)

            current_time = now.strftime("%D %H:%M:%S")
            print("Current Time =", current_time)
            logger.debug("Current Time =" + str(current_time))

            forms13G['Current Time'] = current_time

            forms13D['Current Time'] = current_time

            import time
            timestr = time.strftime("%Y%m%d")
            with open(timestr + "-form13.txt", 'a+') as f:
                f.write(forms13G["Form_Link"].to_string())
                f.write(forms13D["Form_Link"].to_string())

            if (len(forms13G) > 0):
                import json
                records13G = json.loads(forms13G.T.to_json()).values()
                utils.createAndConnectForm13FeedDB(records13G)

            if (len(forms13D) > 0):
                import json
                records13D = json.loads(forms13D.T.to_json()).values()
                utils.createAndConnectForm13FeedDB(records13D)

            return forms13G, forms13D
        except:
            traceback.print_exc()

    def createDataframeForm4(self):
        print("Length of self posts: " + str(len(self.posts)))
        logger.debug('Started getting posts')

        i = 1
        while (len(self.posts) == 0 and i <= 10):
            import time
            time.sleep(i)
            self.updateCurrentPosts()
            i += 1

        Forms4 = pd.DataFrame(self.posts, columns=[
            'title', 'link', 'summary', 'Time'])
        Forms4['Form_Link'] = ""
        Forms4['Date'] = ""
        Forms4['Target'] = ""
        Forms4['Reporting Person'] = ""
        Forms4['Issuer'] = ""
        Forms4['Ticker'] = ""
        Forms4["HTML_Form_Link"] = ""
        Forms4["Transaction Code"] = ""
        Forms4["Purchase"] = ""

        Forms4["Issue Time"] = ""
        Forms4["Issue Date"] = ""

        for time_date in Forms4['Time']:
            time_list = time_date.split('T')
            Forms4.loc[Forms4['Time'] == time_date,
                       'Issue Time'] = time_list[1].split('-')[0]
            Forms4.loc[Forms4['Time'] == time_date,
                       'Issue Date'] = time_list[0]

        Forms4.sort_values(by=['Issue Date', 'Issue Time'],
                           inplace=True, ascending=False)

        for title in Forms4['title']:
            if ("Issuer" in title):
                Forms4.loc[Forms4['title'] == title, "Issuer"] = 'True'
            else:
                Forms4.loc[Forms4['title'] == title, "Issuer"] = "False"

        Forms4 = Forms4.loc[Forms4['Issuer'] == 'True']

        try:
            Forms4["CIK"] = Forms4["title"].str.extract('\((\d+)\)')
        except:
            Forms4["CIK"] = ""
        try:
            Forms4["CIK"] = Forms4["CIK"].fillna(0).astype(int)
        except:
            Forms4["CIK"] = ""
        try:
            Forms4['Form'] = Forms4["title"].str.split(
                " - ", n=-1, expand=True)[0]
        except:
            Forms4['Form'] = ""

        Forms4 = Forms4.loc[Forms4['Form'] == '4']

        for CIK in Forms4['CIK']:
            ticker = self.mapTickerToCIK(CIK)
            Forms4.loc[Forms4['CIK'] == CIK, 'Ticker'] = ticker

        for ticker in Forms4["Ticker"]:
            if (ticker):
                ticker_split = ticker.split("$")[1]
                # print(ticker)
                sector, industry = utils.getSectorIndustrybyTicker(
                    ticker_split)
                Forms4.loc[Forms4['Ticker'] == ticker, 'Sector'] = sector
                Forms4.loc[Forms4['Ticker'] == ticker, 'Industry'] = industry

            else:
                Forms4.loc[Forms4['Ticker'] == ticker, 'Sector'] = 'Undefined'
                Forms4.loc[Forms4['Ticker'] ==
                           ticker, 'Industry'] = "Undefined"

        Forms4 = Forms4.loc[Forms4['Sector'] == 'Healthcare']
        # Forms4_undefined = Forms4.loc[Forms4['Sector'] == 'Undefined']
        # Forms4 = pd.concat([Forms4_healthcare, Forms4_undefined], axis=0)

        Forms4 = Forms4.drop(columns=['summary'])
        print("Form 4 link:")
        logger.debug("Form 4 link:")
        for link in Forms4['link']:
            html_link = utils.getHTMLformLink(link)
            Forms4.loc[Forms4['link'] == link, 'HTML_Form_Link'] = html_link

            text_form_link = link.replace("-index.htm", ".txt")
            Forms4.loc[Forms4['link'] == link, 'Form_Link'] = text_form_link

        if (len(Forms4) != 0):
            p = Pool(16)
            formDataList = p.map(Scrape_Form_4, Forms4["Form_Link"])
            p.terminate()
            p.join()
            for formData in formDataList:
                # formData = Scrape_Form_4(txt_link)
                transaction_codes_list = []
                for i in formData['Non-Derivative Securities Acquired, Disposed of, or Beneficially Owned']:
                    transaction_codes_list.append(i['Transaction Code'])
                    if i['Transaction Code'] == 'P':
                        Forms4.loc[Forms4['Form_Link'] == formData["txt_link"], 'Purchase'] = "P"

                Forms4.loc[Forms4['Form_Link'] == formData["txt_link"], 'Transaction Code'] = "-".join(
                    transaction_codes_list)
                try:
                    Forms4.loc[Forms4['Form_Link'] == formData["txt_link"], 'Reporting Person'] = \
                        formData['Name and Address of Reporting Person']['Name of Reporting Person']

                except:
                    Forms4.loc[Forms4['Form_Link'] ==
                               formData["txt_link"], 'Reporting Person'] = "N/A"
                    print("Unexpected error:", sys.exc_info()[0])
                    logger.error("Unexpected error:" + str(sys.exc_info()[0]))

                    raise

                try:
                    Forms4.loc[Forms4['Form_Link'] == formData["txt_link"], 'Target'] = \
                        formData['Issuer Name and Ticker or Trading Symbol']['Issuer Name']
                except:
                    Forms4.loc[Forms4['Form_Link'] ==
                               formData["txt_link"], 'Target'] = "N/A"
                    print("Unexpected error:", sys.exc_info()[0])
                    logger.error("Unexpected error:" + str(sys.exc_info()[0]))

                    raise

                try:
                    Forms4.loc[Forms4['Form_Link'] == formData["txt_link"], 'Date'] = \
                        formData['Date of Earliest Transaction'][
                            'Period of Report']

                except:
                    Forms4.loc[Forms4['Form_Link']
                               == formData["txt_link"], 'Date'] = "N/A"
                    print("Unexpected error:", sys.exc_info()[0])
                    logger.error("Unexpected error:" + str(sys.exc_info()[0]))

                    raise

                Forms4.at[Forms4['Form_Link'] == formData["txt_link"], 'Sales Averages'] = pd.Series(
                    formData['Sales Averages'])

            Forms4 = Forms4.loc[Forms4["Purchase"] == "P"]

            import pytz

            tz = pytz.timezone('America/New_York')
            from datetime import datetime
            now = datetime.now(tz)

            current_time = now.strftime("%D %H:%M:%S")
            print("Current Time =", current_time)
            logger.debug("Current Time =" + str(current_time))

            Forms4['Current Time'] = current_time

            cols = list(Forms4)
            cols.insert(0, cols.pop(cols.index('Date')))
            cols.insert(1, cols.pop(cols.index('Form')))
            cols.insert(2, cols.pop(cols.index('Target')))
            cols.insert(3, cols.pop(cols.index('Reporting Person')))
            cols.insert(4, cols.pop(cols.index('Form_Link')))
            Forms4 = Forms4[cols]
            Forms4 = Forms4.reset_index(drop=True)
            import time
            timestr = time.strftime("%Y%m%d")
            with open(timestr + "-form4.txt", 'a+') as f:

                f.write(Forms4["Form_Link"].to_string())
        if (len(Forms4) > 0):
            import json
            records = json.loads(Forms4.T.to_json()).values()
            utils.createAndConnectForm4FeedDB(records)
        return Forms4


if __name__ == '__main__':
    feedParserForm4 = FeedParser(
        'https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&CIK=&type=4&company=&dateb=&owner=only&start=0&count=100&output=atom',
        set())
    feedParserForm4.updateCurrentPosts()
    forms4 = feedParserForm4.createDataframeForm4()

    feedParser = FeedParser(
        'https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&CIK=&type=SC%2013&company=&&owner=include&start=0&count=100&output=atom',
        set())
    feedParser.updateCurrentPosts()
    forms13G, forms13D = feedParser.createDataframe()
