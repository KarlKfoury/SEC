#updates the pipeline of drugs of all companies with their news links, phase of study, and status
import pandas as pd 
from IPython.display import HTML
import datetime
from datetime import date
from bs4 import BeautifulSoup
import time
import sqlite3

def pipeline_update():
    import re
    from bs4 import BeautifulSoup
    import requests, lxml
    import pandas as pd
    url1 = 'https://www.biopharmcatalyst.com/biotech-stocks/company-pipeline-database' 
    res1 = requests.get(url1) 
    soup1 = BeautifulSoup(res1.text, 'html.parser') 
    soup2 = soup1.find('div', class_='filter-table__body list')
    rows = soup2.findAll('div', class_='filter-table__row js-tr'.split())
    complete_pipeline_list = []
    for row in rows:
        ticker_list = []
        tickers = row.findAll(['span'], class_='ticker--small') 
        companies = row.findAll(['a'], class_='company-name') 
    #     prices = row.findAll(['div'], class_='filter-table__td js-td js-td--price price text-right') 
    #     changes = row.findAll(['div'], class_='filter-table__td js-td js-td--change text-right') 
        drug_counts = row.findAll(['span'], class_='js-drugs-count')
        for ticker in tickers:
            ticker = ticker.text
        for company in companies:
            company = company.text
    #     for price in prices:
    #         price = price.get_text(strip=True)
    #     for change in changes:
    #         change = change.get_text(strip=True)
        for drug_count in drug_counts:
            drug_count = drug_count.get_text(strip=True) 
        ticker_list=[ticker,company,drug_count]     

        for ticker in ticker_list:      
            drug_list = []
            drug_list_table=row.find(['div'], class_='company__drugs') 
            drug_rows = drug_list_table.find_all('tr')
            for drug_row in drug_rows:
                company_drug_list=[]
                drug_cells = drug_row.find_all(['td', 'th'])
                for drug_cell in drug_cells:
                    drug_cell = drug_cell.get_text(strip=True)
                    company_drug_list.append(drug_cell)
                try:
                    news_link=drug_row.find('a', href=True)
                    news_link = news_link.get('href')
                    company_drug_list.append(news_link)
                except:
                     company_drug_list.append('No Link Found')       
                drug_list.append(company_drug_list)
            del drug_list[:1]


            company_drug_list_with_ticker = []
            for a in drug_list:
                company_drug_with_ticker = ticker_list+a
                company_drug_list_with_ticker.append (company_drug_with_ticker)
            for b in company_drug_list_with_ticker:
                complete_pipeline_list.append(b)


    cols = {0:'symbol',1:'Company', 2:'Drugs',3:'Drug', 4:'Indication', 5:'Phase', 6:'News', 7:'Link'}
    complete_pipeline_df = pd.DataFrame(complete_pipeline_list)
    complete_pipeline_df.rename(columns=cols, 
                     inplace=True)
    #     complete_pipeline_df = complete_pipeline_df.set_index ('symbol')

    complete_pipeline_df = complete_pipeline_df.sort_values(by = ['symbol', 'Drug'], ascending = [True, True])
    complete_pipeline_df = complete_pipeline_df.drop_duplicates()
    complete_pipeline_df = complete_pipeline_df.reset_index(drop=True)

    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")   
        complete_pipeline_df.to_sql('pipeline_bfc', conn, if_exists='replace', index = False)
    except sqlite3.Error as error:
        print("Failed to connect to pipeline bfc", error)                                
    finally:
        if (conn):
            conn.close()


def search():
    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db") 
        # pd.read_sql_query("select * from biotech where symbol='MYOV';", conn)
        complete_pipeline_df = pd.read_sql_query("select * from pipeline_bfc ORDER BY symbol ASC;", conn)
    except sqlite3.Error as error:
        print("Failed to connect to pipeline_bfc", error)                                
    finally:
        if (conn):
            conn.close()
            
    def find():
        search = input("Insert your keyword here: ")
        print('Results: ')
        return search
    item = find()

    complete_ticker_list = []
    complete_ticker_df = pd.DataFrame()
    for field in fields_to_search:
        complete_ticker_df = complete_ticker_df.append(complete_pipeline_df[complete_pipeline_df[field].str.contains(item, case=False, na=False)])
        Ticker_list = complete_pipeline_df[complete_pipeline_df[field].str.contains(item, case=False, na=False)].symbol.tolist()
        Ticker_list_without_duplicates = sorted(list(set(Ticker_list)))
        for a in Ticker_list_without_duplicates:
            complete_ticker_list.append(a)

    complete_ticker_list = sorted(list(complete_ticker_list))
    if not complete_ticker_list:
        print('')
        print ('No stocks found')
    else:
        complete_ticker_list_tweet = ', $'.join(complete_ticker_list)
        complete_ticker_list_tweet = "$"+complete_ticker_list_tweet
        print('')
        print('Stocks mentioning '+ item+":")
        print(complete_ticker_list_tweet)

    complete_ticker_df =complete_ticker_df.drop_duplicates().reset_index(drop = True) 
    return(complete_ticker_df)
    
def pipeline(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')

    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db") 
        # pd.read_sql_query("select * from biotech where symbol='MYOV';", conn)
        complete_pipeline_df = pd.read_sql_query("select * from pipeline_bfc ORDER BY symbol ASC;", conn)
    except sqlite3.Error as error:
        print("Failed to connect to pipeline_bfc", error)                                
    finally:
        if (conn):
            conn.close()

    complete_pipeline_df['Link'] = complete_pipeline_df['Link'].apply(lambda x: '<a href="{0}" target="_blank">{0}</a>'.format(x))

    if (complete_pipeline_df.symbol.values.any() == symbol) == True:  
        pipeline_symbol_df = complete_pipeline_df.loc[complete_pipeline_df['symbol']==symbol]
        return(HTML(pipeline_symbol_df.to_html(escape=False)))
    else:
        print(symbol + ' not in the Pipeline Database')


def update_catalysts():
#Tutorial here: https://www.scrapingbee.com/blog/selenium-python/
    from selenium import webdriver
    DRIVER_PATH = '/Users/ralph/Biotech/chromedriver'
    #This will launch Chrome in headfull mode (like a regular Chrome, which is controlled by your Python code). 
    #You should see a message stating that the browser is controlled by an automated software.
    # driver = webdriver.Chrome(executable_path=DRIVER_PATH)

    #In order to run Chrome in headless mode (without any graphical user interface), 
    #to run it on a server for example, add the code below and replace driver above with the one below:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    options = Options()
    options.headless = True
    # options.add_argument("--window-size=1920,1200")
    driver = webdriver.Chrome(options=options, executable_path=DRIVER_PATH)

    #Tutorial here:
    driver.get("https://www.biopharmcatalyst.com/account/login")
    username = driver.find_element_by_id("loginName")
    username.clear()
    username.send_keys("ralphdaher@hotmail.com")

    password = driver.find_element_by_name("password")
    password.clear()
    password.send_keys("Alphy2000$")
    driver.find_element_by_xpath("//section/form/p/input").click()

    driver.get("https://www.biopharmcatalyst.com/calendars/fda-calendar")
    time.sleep(5)

    soup = BeautifulSoup(driver.page_source, 'lxml')
    #Always quit at the end of scraping
    driver.quit()

    table = soup.find_all('table')
    catalysts_df = pd.read_html(str(table))[0] 
    catalysts_df.rename(columns={'Ticker':'symbol','Catalyst':'Catalyst_Date','burn(mthly)':'Burn(mthly)',
                                'net cash':'Net Cash','ent value':'EV',
                               'last updated':'Catalyst Last Updated'}, inplace=True) 
    catalysts_df['Catalyst'] = catalysts_df.Catalyst_Date.str.split('[2][0][2-9][0-9] ',1).str[1]
    catalysts_df['Catalyst_Date'] = catalysts_df.apply(lambda row : row['Catalyst_Date'].replace(str(row['Catalyst']), ''), axis=1)
    catalysts_df.loc[catalysts_df['Catalyst_Date'].str.contains('Adcom'), 'Adcom'] = 'Adcom'
    catalysts_df['Catalyst_Date'] = catalysts_df.apply(lambda row : row['Catalyst_Date'].replace(str(row['Adcom']), ''), axis=1)
    catalysts_df['Last Updated'] = date.today()
    catalysts_df= catalysts_df[['symbol','Price','Last Updated','Drug', 'Stage', 'Catalyst_Date', 'Catalyst', 'Adcom',
     'No Of Shares','Market Cap','Burn(mthly)','Net Cash',
     'EV', 'Insider Holding %', 'Catalyst Last Updated']]
    catalysts_df.rename(columns={'Catalyst_Date':'Catalyst Date'}, inplace=True) 


    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")   
        catalysts_df.to_sql('catalysts_bfc', conn, if_exists='replace', index = False)
    except sqlite3.Error as error:
        print("Failed to connect to catalysts_bfc", error)                                
    finally:
        if (conn):
            conn.close()

def catalysts(symbol):
    symbol = symbol.upper()
    symbols = symbol.split(',')
    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db") 
        # pd.read_sql_query("select * from biotech where symbol='MYOV';", conn)
        catalysts_df = pd.read_sql_query("select * from catalysts_bfc;", conn)
    except sqlite3.Error as error:
        print("Failed to connect to catalysts_bfc", error)                                
    finally:
        if (conn):
            conn.close()

    catalysts_df_symbol = catalysts_df.loc[catalysts_df['symbol']==symbol]
    catalysts_df_symbol = catalysts_df_symbol.reset_index(drop = True)
    if catalysts_df_symbol.empty:
        print(symbol + ' not in the Catalysts Database')
    else:
        return(catalysts_df_symbol)

def allcatalysts():
    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db") 
        # pd.read_sql_query("select * from biotech where symbol='MYOV';", conn)
        catalysts_df = pd.read_sql_query("select * from catalysts_bfc;", conn)
    except sqlite3.Error as error:
        print("Failed to connect to catalysts_bfc", error)                                
    finally:
        if (conn):
            conn.close()
    return (catalysts_df)

def clinical_trials(drug):  
    #Tutorial here: https://www.scrapingbee.com/blog/selenium-python/
    from selenium import webdriver
    #This will launch Chrome in headfull mode (like a regular Chrome, which is controlled by your Python code). 
    #You should see a message stating that the browser is controlled by an automated software.
    DRIVER_PATH = '/Users/ralph/Biotech/chromedriver'
    #     driver = webdriver.Chrome(executable_path=DRIVER_PATH)

    #     In order to run Chrome in headless mode (without any graphical user interface), 
    #     to run it on a server for example, add the code below and replace driver above with the one below:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    options = Options()
    options.headless = True
#     options.add_argument("--window-size=1920,1200")
    driver = webdriver.Chrome(options=options, executable_path=DRIVER_PATH)

    driver.get("https://clinicaltrials.gov/ct2/results?cond="+drug+"&term=&cntry=&state=&city=&dist=")
    #Click on show/hide columns
    driver.find_element_by_xpath("//*[@id= 'theDataTable_wrapper']/div/button/span").click()
    #Add Study Phase column
    driver.find_element_by_xpath("//*[@id= 'theDataTable_wrapper']/div/div[2]/button[5]").click()
    #Add Last Updated Column
    driver.find_element_by_xpath("//*[@id='theDataTable_wrapper']/div/div[2]/button[20]/span").click()
    #Click on show/hide columns
    driver.find_element_by_xpath("//*[@id= 'theDataTable_wrapper']/div/button/span").click()
    #Add Study Completed
    driver.find_element_by_xpath("//*[@id='theDataTable_wrapper']/div/div[2]/button[18]/span").click()
    
    soup = BeautifulSoup(driver.page_source, 'lxml')
    driver.quit()


    table = soup.find_all('table')
    table_df = pd.read_html(str(table))[1]
    return table_df 