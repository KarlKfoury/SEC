#Imports the database and looks for the oldest 100 tickers and those showing NaN in the Last Updated section and updates those in the database taking 3-5 minute recess between every ticker

from yahooquery import Ticker
from csv import DictWriter
from bs4 import BeautifulSoup
from datetime import datetime
from IPython.display import HTML
import pandas as pd
import numpy as np
import sqlite3
import requests
import textwrap
import datetime
from datetime import date
import feedparser
from DatabaseQueries import remove
# from IPython.core.interactiveshell import InteractiveShell
# InteractiveShell.ast_node_interactivity = "all"
# pd.set_option('display.max_rows', 500)
# pd.set_option('display.max_columns', 500)
# pd.options.display.float_format = '{:,}'.format #To separate 000,000
#pd.set_option('display.float_format', lambda x: '%.1f' % x)
import random
from random import randint
from time import sleep
from Definitions import web,web2,summary2,pcs,sps,bss,fss,cfs,cash,kss_new,kss_old,mhs,pctchange,exchange
from InsiderActivity import insiders2
import Report

# def database_file():
#     filename = '/Users/ralph/biotech/BiotechDatabase.csv'
#     fields = ['symbol','Company', 'My Notes Date','My Notes','Revisit Date','Score (1-10)','Last Updated','Exchange','First Traded','Industry','Sector','Phone',
#                   'Web','Summary','Mkt. Cap','Price','Percent Change','Volume',
#                   '1 Month Percentage Change','3 Month Percentage Change',
#                   '1 Year Percentage Change','Date_BS','Cash/Short Term Inv.',
#                   'Tot.Assets','Tot.Liabilities','Tot.Equity','Date_FS',
#                   'Tot.Revenue','Net Income','Date_CF','Free Cash Flow',
#                   'Date_CB','CashBurnPerDay','CashLeftToday','Months to 0$',
#                   'Date of Short Report','EV','Shares Outst.','Float',
#                   'Shares Short','Short % of Float','Short Ratio',
#                   'Previous Date of Report','Prior Shares Short',
#                   'Insiders % Held','Institutions Count',
#                   'Institutions Float % Held','Institutions % Held',
#                   'Buy (3M)','Buy (6M)','Buy (12M)','Sell (3M)','Sell (6M)',
#                   'Sell (12M)','Shares Bought (3M)','Shares Bought (6M)',
#                   'Shares Bought (12M)','Shares Sold (3M)','Shares Sold (6M)',
#                   'Shares Sold (12M)']
#     return filename,fields


# global df_bio
# filename,fields = database_file()
# # Reading csv from file with names as fields
# df_bio = pd.read_csv(filename, names=fields, header=0, index_col='symbol')
# symbols = df_bio.index.tolist()


sleep(randint(1,720))

try:
    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db") 
    symbols = pd.read_sql_query("SELECT symbol from biotech ORDER BY [Last Updated] ASC LIMIT 20;", conn)
    symbols = symbols['symbol'].values.tolist()

except sqlite3.Error as error:
    print("Failed to select symbol from biotech", error)
finally:
    if (conn):
        conn.close()  

# ticker = Ticker(symbols, asynchronous=True, validate = True)
# invalid = ticker.invalid_symbols
# valid = ticker.symbols
# if invalid is None:
#     print('All symbols selected are valid')
#     pass
# elif invalid is not None:
#     print("Invalid ticker list: "+ str(invalid))
#     for i in invalid:
#         print('Removing '+ i)
#         remove(i)       
        
for symbol in symbols:
    print('updating '+ symbol)
    
    try:
        web2(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass
    try:
        summary2(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass
    try:
        pctchange(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass
    try:
        exchange(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass    
    try:
        pcs(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass    
    try:
        sps(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass    
    try:
        bss(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass    
    try:
        fss(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass    
    try:
        cfs(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass   
    try:
        cash(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass    
    try:
        kss_new(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass    
    try:
        kss_old(symbol)
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass     
    try:
        mhs(symbol)  
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass 
    try:
        insiders2(symbol) 
        sleep(randint(1,4))
    except Exception as e: 
        print(e)
        pass 

    datetime.date.today()
    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db") 
        cur = conn.cursor()
        cur.execute
        values = (symbol,datetime.date.today())
        # cur.execute("UPDATE biotech SET Web = ? WHERE symbol = ?", values )
        # cur.execute("update biotech set Web=? where symbol=?", values)
        cur.execute("""
        INSERT INTO biotech(symbol,[Last Updated]) 
        VALUES(?,?)
        ON CONFLICT(symbol) DO UPDATE SET [Last Updated]=excluded.`Last Updated`""",
        values 
        )
        conn.commit()
        cur.close()
    except sqlite3.Error as error:
        print("Failed to add Last updated", error)  
    finally:
        if (conn):
            conn.close()

    sleep(randint(1,4))
