import requests
from bs4 import BeautifulSoup
import pandas as pd
import sqlite3
import numpy as np
import datetime
    
def ipo():
    global ipo_bio_df
    url = 'https://www.iposcoop.com/current-year-pricings/'
    #print(url1)
    res = requests.get(url)
    #print(res1)
    soup = BeautifulSoup(res.text, 'html.parser')
    table = soup.find_all('table')

    ipo_all_df = pd.read_html(str(table))[0] 
    # ipo_df = ipo_df.loc[ipo_df['Industry'] == 'Health Care']
    ipo_all_df=ipo_all_df.set_index('Symbol')
    ipo_all_df = ipo_all_df.reset_index()
    ipo_all_df.rename(columns={'Symbol':'symbol', 'Shares (millions)':'Shares'}, inplace=True)
    ipo_all_df['Offer Date'] = pd.to_datetime(ipo_all_df['Offer Date'],yearfirst = True)
    del ipo_all_df['SCOOP Rating']
    del ipo_all_df['Return']
    del ipo_all_df['Current Price']
    ipo_all_df[ipo_all_df.columns[5:]] = ipo_all_df[ipo_all_df.columns[5:]].replace('[\$,]', '', regex=True).astype(float)
    ipo_all_df['Shares'] = ipo_all_df['Shares'] * 1000000

    ipo_all_df['Shares'] = ipo_all_df['Shares'].apply(np.int64)
    ipo_all_df

    ipo_bio_df = ipo_all_df.loc[ipo_all_df['Industry'] == 'Health Care']
    ipo_bio_df


    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
        ipo_bio_df.to_sql('temp_ipo_bio', conn, if_exists='replace', index=False)
        ipo_all_df.to_sql('temp_ipo_all', conn, if_exists='replace', index=False)

        cur = conn.cursor()
        cur.executescript('''
                        INSERT OR REPLACE INTO ipo_all
                        SELECT * FROM temp_ipo_all;
                        SELECT * FROM ipo_all
                        ORDER BY symbol ASC;
                        INSERT OR REPLACE INTO ipo_bio
                        SELECT * FROM temp_ipo_bio;
                        SELECT * FROM ipo_bio
                        ORDER BY symbol ASC;
                        ''')
        conn.commit()
        cur.close()
    except sqlite3.Error as error:
        print("Failed to connect to the ipo tables", error)  
    finally:
        if (conn):
            conn.close() 

ipo()

# Adding the new symbols to the biotech database
ipo_bio_list = sorted(ipo_bio_df.symbol.to_list())

try:
    conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")
    symbols_db = pd.read_sql_query("select * from biotech;", conn)['symbol'].tolist()
except sqlite3.Error as error:
    print("Failed to select from biotech", error)  
finally:
    if (conn):
        conn.close() 
        
diff = list(set(ipo_bio_list) - set(symbols_db))
diff = sorted(list(set(diff)))
diff
 
if not diff:
    print("No new symbols are found")
else:
    datetime.date.today()
    try:
        conn = sqlite3.connect("/Users/ralph/Biotech/BiotechDatabase.db")   
        cur = conn.cursor()

        for i in diff:
            values = (i,datetime.date.today())
            cur.execute("""
            INSERT OR IGNORE INTO biotech(symbol,[Last Updated]) VALUES(?,?)
            """, 
            values 
            )
        conn.commit()
        cur.close()
        print("The following symbols were added to the biotech database:")
        print(diff)
    except sqlite3.Error as error:
        print("Failed to add new symbols", error)    
    finally:
        if (conn):
            conn.close()  