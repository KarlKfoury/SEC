# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 16:39:45 2021

@author: marou
"""

import edgar
edgar.download_index("D:\EDGAR_2017_2020", 2017, skip_all_present_except_last=False)

from os import listdir
from os.path import isfile, join
import csv

mypath="D:/EDGAR_2017_2020"

filenames = [mypath+"/"+f for f in listdir(mypath) if isfile(join(mypath, f))]
print(filenames)
with open(mypath+"/master.tsv", 'w+') as outfile:
    for fname in filenames:
        with open(fname) as infile:
            for line in infile:
                outfile.write(line)
print("Finished creating master file")
tsv_file = open('D:/EDGAR_2017_2020/2017-QTR1.tsv')
read_tsv = csv.reader(tsv_file, delimiter="\t")
for row in read_tsv:
  print(row[0].split("|"))
  break